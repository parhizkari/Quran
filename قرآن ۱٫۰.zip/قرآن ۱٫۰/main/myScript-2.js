/*
By the name of Allah, the All-providing and the most Merciful God,
myQuran is a simple program based on web technology which works totally offline
and is suitable for browsing Quran together with several Persian and some English
translations, enhanced with the possibility to leave a comment for any of the verses
of Quran. The comments can be saved and loaded afterwards. A search engine, also,
makes possible to search through the Arabic text of Quran, and through each
individual translation of it, as well as through the comments already loaded.

Copyright (C) 2016  Owzhan Parhizkari (اوژن پرهیزکاری)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program: "gpl.txt".  If not, see <http://www.gnu.org/licenses/>.

Contact information: o.parhizkari@chmail.ir
*/




/* ---------------------------------------------------------- */
// to use localStorage of HTML5 for saving the "temporary" div on the fly, if the browser/tab is closed data will remain saved until the browser's cache is deleted ...


if (window.localStorage["TextEditorData"]) {
	document.getElementById("temporary").innerHTML = window.localStorage["TextEditorData"];	// retrieves the temporary div's content from the browser's cache even after the browser/tab is reopened
}






/* ---------------------------------------------------------- */
/* script for loading the data to be used hereafter, data will be reloaded only at page reload then, the selected parts of data will be shown by calling a specific function */


var editor, html=[""], commentCreateButtonValue, commentCreateButtonImage; //to create and destroy CKEditor instances on the fly / html[0]=""

var quran;
var ansarian, ayati, bahrampour, fooladvand, ghomshei, khorramdel, khorramshahi, makarem, moezzi, mojtabavi;
var sahih, yusufali; // sarwar, shakir, pickthall;

var commentsContent= ( $("#Openfile").val() != "" ) ? $("#Openfile").val() : "fakeCommentFileAddress.txt"; // the  fakeCommentFileAddress  is a fake file name for the string to be nonempty otherwise the page was not loaded properly

$.when(
	$.ajax({
		url: "main/data/quran-simple-enhanced.json",	 // path to file
		dataType: "text",	//force to handle it as "text", or select suitable type from (text, json, xml, etc)
		success: function (data) {
			quran = $.parseJSON(data);
		}
	}),
	$.ajax({
		url: "main/data/fa.ansarian.json",	 // path to file
		dataType: "text",	//force to handle it as "text", or select suitable type from (text, json, xml, etc)
		success: function (data) {
			ansarian = $.parseJSON(data);
		}
	}),
	$.ajax({
		url: "main/data/fa.ayati.json",	 // path to file
		dataType: "text",	//force to handle it as "text", or select suitable type from (text, json, xml, etc)
		success: function (data) {
			ayati = $.parseJSON(data);
		}
	}),
	$.ajax({
		url: "main/data/fa.bahrampour.json",	 // path to file
		dataType: "text",	//force to handle it as "text", or select suitable type from (text, json, xml, etc)
		success: function (data) {
			bahrampour = $.parseJSON(data);
		}
	}),
	$.ajax({
		url: "main/data/fa.fooladvand.json",	 // path to file
		dataType: "text",	//force to handle it as "text", or select suitable type from (text, json, xml, etc)
		success: function (data) {
			fooladvand = $.parseJSON(data);
		}
	}),
	$.ajax({
		url: "main/data/fa.ghomshei.json",	 // path to file
		dataType: "text",	//force to handle it as "text", or select suitable type from (text, json, xml, etc)
		success: function (data) {
			ghomshei = $.parseJSON(data);
		}
	}),
	$.ajax({
		url: "main/data/fa.khorramdel.json",	 // path to file
		dataType: "text",	//force to handle it as "text", or select suitable type from (text, json, xml, etc)
		success: function (data) {
			khorramdel = $.parseJSON(data);
		}
	}),
	$.ajax({
		url: "main/data/fa.khorramshahi.json",	 // path to file
		dataType: "text",	//force to handle it as "text", or select suitable type from (text, json, xml, etc)
		success: function (data) {
			khorramshahi = $.parseJSON(data);
		}
	}),
	$.ajax({
		url: "main/data/fa.makarem.json",	 // path to file
		dataType: "text",	//force to handle it as "text", or select suitable type from (text, json, xml, etc)
		success: function (data) {
			makarem = $.parseJSON(data);
		}
	}),
	$.ajax({
		url: "main/data/fa.moezzi.json",	 // path to file
		dataType: "text",	//force to handle it as "text", or select suitable type from (text, json, xml, etc)
		success: function (data) {
			moezzi = $.parseJSON(data);
		}
	}),
	$.ajax({
		url: "main/data/fa.mojtabavi.json",	 // path to file
		dataType: "text",	//force to handle it as "text", or select suitable type from (text, json, xml, etc)
		success: function (data) {
			mojtabavi = $.parseJSON(data);
		}
	}),
	$.ajax({
		url: "main/data/en.sahih.json",	 // path to file
		dataType: "text",	//force to handle it as "text", or select suitable type from (text, json, xml, etc)
		success: function (data) {
			sahih = $.parseJSON(data);
		}
	}),
	/*$.ajax({
		url: "main/data/en.sarwar.json",	 // path to file
		dataType: "text",	//force to handle it as "text", or select suitable type from (text, json, xml, etc)
		success: function (data) {
			sarwar = $.parseJSON(data);
		}
	}),
	$.ajax({
		url: "main/data/en.shakir.json",	 // path to file
		dataType: "text",	//force to handle it as "text", or select suitable type from (text, json, xml, etc)
		success: function (data) {
			shakir = $.parseJSON(data);
		}
	}),
	$.ajax({
		url: "main/data/en.pickthall.json",	 // path to file
		dataType: "text",	//force to handle it as "text", or select suitable type from (text, json, xml, etc)
		success: function (data) {
			pickthall = $.parseJSON(data);
		}
	}),*/
	$.ajax({
		url: "main/data/en.yusufali.json",	 // path to file
		dataType: "text",	//force to handle it as "text", or select suitable type from (text, json, xml, etc)
		success: function (data) {
			yusufali = $.parseJSON(data);
		}
	}),
	$("#temporary").load( commentsContent )	// this loads the last comment file selected to be loaded in the last session that the application was used before the present session
).then(function() {
	chooseTranslations();
	chooseSurah(1);	// this shows the default Surah at the beginning, now it is السورة الفاتحة
	// to show the loading div at the beginning of the application and then hide it after loading is completed
	/*(function(){
		//document.getElementById("loading").style.display = "none";
		//document.getElementById("main").style.display = "block";
		$('#main').fadeIn("slow");
		$("#loading").fadeOut("slow");
	})();*/
});
var translationFaList={ansarian:"ansarian", ayati:"ayati", bahrampour:"bahrampour", fooladvand:"fooladvand", ghomshei:"ghomshei", khorramdel:"khorramdel", khorramshahi:"khorramshahi", makarem:"makarem", moezzi:"moezzi", mojtabavi:"mojtabavi"};
var translationEnList={sahih:"sahih",  yusufali:"yusufali"};	// sarwar:"sarwar", shakir:"shakir", pickthall:"pickthall",


// Select the translations to be shown
var translationFaVal=[], translationFaText=[], translationEnVal=[], translationEnText=[];
$('#translationList').on('change', function(){	// to make the options functional while selecting an option
	chooseTranslations();
	//chooseSurah(1);	// this way, whenever a translation is added or removed Quran shows from begining
	showSelectedVerses( Number($("#chapterList").val()) , Number($("#verseNumList").val()) );
	return false;
});


function chooseTranslations(){
	//var selection=$('#translationList').val();	alert(selection);
	translationFaVal=[];
	translationFaText=[];
	translationEnVal=[];
	translationEnText=[];
	$('#translationList  option:selected').each(function(){
		if($(this).parent().attr('label')=="فارسی"){
			translationFaVal.push( $(this).val() );		// or   "\""+$(this).val()+"\""  ?
			translationFaText.push( $(this).text() );	// or   "\""+$(this).text()+"\""  ?
		}else{
			translationEnVal.push( $(this).val() );		// or   "\""+$(this).val()+"\""  ?
			translationEnText.push( $(this).text() );	// or   "\""+$(this).text()+"\""  ?
		}
	});
}




/* ---------------------------------------------------------- */
/* to generated the fixed list of Surahs  (#chapterList)  in the menu in <aside/> */




for(var i in surah_info){
	$("<option value="+i+" style=\"font-family:Neirizi; font-size:100%; color:black;\">").html(
		persianDigits[i]+'. '+surah_info[i]["nameAr"]
	).appendTo("#chapterList");
}
$('#chapterList')
	.find('option:nth-child(1)').prop('selected', true)	// nth-child(2) means the surah "الفاتحة"
	.end().trigger('chosen:updated');		// to update the chapterlist with the default option selected
$('#chapterList').on('change', function(){	// to make the options functional while selecting an option
	chooseSurah( Number($("#chapterList").val()) );
	return false;
});




/* ---------------------------------------------------------- */
/* the function to be triggered when a new surah is selected e.g. from menu  */




function chooseSurah(chapter){
	// let show the Surah from its beginning, that is, from its vey first ayah
	showSelectedVerses(chapter,1);
	// now we should wipe out the old (verseNumList) to produce a new list for the newly selected surah
	document.getElementById("verseNumList").innerHTML="";	// "<option value=\"\"></option>";
	for(var j=1; j<=surah_info[chapter]["numVerse"]; j++){
		$("<option value="+j+" style=\"font-family:Neirizi; font-size:100%; color:black;\">").html(
			persianDigits[j]
		).appendTo("#verseNumList");
	}
	$('#verseNumList')
		.find('option:nth-child(1)').prop('selected', true) //nth-child(2) is the verse "1", nth-child(1) is empty
		.end().trigger('chosen:updated'); // to update the verse number list with the default option selected
	$('#verseNumList').on('change', function(){    // to make the options functional while selecting an option
		showSelectedVerses(chapter, Number($("#verseNumList").val()) );	// I was expecting for the result of  $("#verseNumList").val()  to be a number but it was a string, so that if its value was 1 then its value plus 5 was  "1"+5=15  instead of simply  6 , so used the  Number()  function, but why is that so? Maybe the value of an <option> is always a string, no matter if it is setted as "1" or simply 1. Is that correct?
		return false;
	});
};




/* ---------------------------------------------------------- */
/* the function to show the selected verses of the selected surah  */




// first define a function that later can check if a div like  "#commentCKE-"+i  already exists or not ...
jQuery.fn.exists = function(){
	return this.length>0;
};

// this function is to be triggered whenever a request is made to show the verses after/around a selected verse of a selected surah
function showSelectedVerses(surah,verse){
	if(verse<=5){		// i.e. when the surah is already showing from its beginning
		$("#mainHeader").empty();
	}else{
		$("#mainHeader").html(
			'<input id="previousVerses" class="myButton" onclick="showSelectedVerses('+surah+','+Number(verse-5)+');" type="image" src="main/images/up.png" alt=""  title="مشاهده‌ی آیات پیشین!" align="center" width="35" height="35">'
		);
	}
	if(verse>=surah_info[surah]["numVerse"]-6){	// i.e. when the surah is already showing upto its end
		$("#mainFooter").empty();
	}else{
		$("#mainFooter").html(
			'<input id="nextVerses" class="myButton" onclick="showSelectedVerses('+surah+','+Number(verse+7)+');" type="image" src="main/images/down.png" alt=""  title="مشاهده‌ی آیات بعد!" align="center" width="35" height="35" style="margin-bottom:9px;">'
		);
	}

	// now we should wipe out the old (verseNumList) to produce a new list for the newly selected surah
	$('#mainBody').empty();
	
	$('#surahName').empty();		
	// to write the name of the selected Surah at the navigation bar at top of the page
	$("<div  style='font-family:Neirizi;'>").html('السُّورَةُ '+surah_info[surah]["nameAr"]+' ('+surah_info[surah]["revealedAr"]+')').appendTo("#surahName");

	// to write down the selected Verses of the selected Surah 
	for(var i in quran["quran-simple-enhanced"]){		// use obj[item]
		
		html.push("");	//this defines  html[i] initially assigned as an empty string	//should live outside any "if" conditional
		//html[i++]="";
		
		if(quran["quran-simple-enhanced"][i]["surah"]==surah
		    && quran["quran-simple-enhanced"][i]["ayah"]>=verse-4
		    && quran["quran-simple-enhanced"][i]["ayah"]<=verse+6){			
			
			if ($("#commentCKE-"+i).exists()){   //this "if" only controls the first demonstration of the "create" button's value
				html[i]=$("#commentCKE-"+i).html();
				commentCreateButtonValue="ویرایش یادداشت";
				commentCreateButtonImage="main/images/edit_comment.png";
			}else{
				commentCreateButtonValue="افزودن یادداشت";
				commentCreateButtonImage="main/images/new_comment.png";
			}
			
			$("<div  class='verse'  style='padding: 10px;'>").html(

'<div id="['+surah+':'+quran["quran-simple-enhanced"][i]["ayah"]+']" style="display:table; width:100%;">' // if I build all the div's corresponding to all the verses of quran, a periori, then I can show them by calling them using #[??:??] even at the web-browser's addressbar, I guess! However, now I can browse the verses this way only among those generated inside the present "for" loop
	+'<div style="display:table-row;">'
		+'<div style="display:table-cell; width:69%; border: 1px solid white; border-radius:10px; padding: 15px; vertical-align:top; background:rgba(255,255,255,0.3);">'
			+'<span style="color:black; text-shadow:2px 2px 4px yellow; font-family:Neirizi; font-size:100%; line-height: 200%;">'
				+quran["quran-simple-enhanced"][i]["verse"]
			+'</span>'
			+'<span style="color:red; text-shadow:1px 1px 1px white; font-family:Neirizi; font-size:120%">'
				+' ('
					+persianDigits[ quran["quran-simple-enhanced"][i]["ayah"] ]
					+':'
					+persianDigits[ quran["quran-simple-enhanced"][i]["surah"] ]
				+')'
			+'</span>'
			+'<div id="farsiTranslation-'+i+'"></div>'
			+'<div id="englishTranslation-'+i+'"></div>'
		+'</div>'		
		
		+'<div style="display:table-cell; width:1%;">'
			//empty cell as spacer
		+'</div>'		
		
		+'<div style="display:table-cell; width:30%; border: 1px solid white; border-radius:10px; padding: 15px; background:rgba(255,255,255,0.3);">'
			+'<div id="editorcontent'+i+'" style="max-height:300px; overflow-x:hidden; overflow-y:auto; color:black;">'+html[i]+'</div>'
			+'<div id="editor'+i+'"></div>'
			+'<p>'
				+'<input id="create'+i+'" onclick="createEditor('+i+');" type="image" src="'+commentCreateButtonImage+'" alt="" title="'+commentCreateButtonValue+'" align="center" width="30" height="30">'
				+'<input id="removeDontChange'+i+'" onclick="removeDontChangeEditor('+i+');" type="image" src="main/images/close.png" alt="" title="تغییرات داده شده را نادیده بگیر!" align="center" width="25" height="25" style="display:none">'
				+'<input id="remove'+i+'" onclick="removeEditor('+i+');" type="image" src="main/images/checkmark.png" alt="" title="با اعمال تغییرات موافقم!" align="center" width="25" height="25" style="display:none">'
			+'</p>'
		+'</div>'
	+'</div>'
+'</div>'

			).appendTo("#mainBody");
			
			
			for(fa in translationFaVal){
				for(key in translationFaList){
					if(translationFaList[key]==translationFaVal[fa]){
						//alert(translationFaList[key]);
						//alert(translationFaVal[fa]);
						$("<span>").html(						
							'<br>'
							+'<span style="color:Crimson; text-shadow:1px 1px 1px white; font-family:Neirizi; font-size:80%">('
								+translationFaText[fa]
							+')</span> '
							+'<span style="color:black; text-shadow:1px 1px 1px white; font-size:90%; line-height: 130%;"> '
								//+eval(translationFaVal[fa])["fa."+translationFaVal[fa]][i]["verse"]
								//+eval(translationFaList[key])["fa."+translationFaVal[fa]][i]["verse"]
								+window[translationFaList[key]]["fa."+translationFaVal[fa]][i]["verse"].replace(/0/g,"۰").replace(/1/g,"۱").replace(/2/g,"۲").replace(/3/g,"۳").replace(/4/g,"۴").replace(/5/g,"۵").replace(/6/g,"۶").replace(/7/g,"۷").replace(/8/g,"۸").replace(/9/g,"۹") // the digits are Persianized as some translations include numbers in English digits
							+'</span>'
						).appendTo('#farsiTranslation-'+i);
					}
				}
			}
			for(en in translationEnVal){
				for(key in translationEnList){
					if(translationEnList[key]==translationEnVal[en]){
						//alert(translationEnList[key]);
						//alert(translationEnVal[fa]);
						$("<span>").html(
							'<br>'
							+'<div style="text-align:left;" lang="en" dir="ltr">'
								+'<span style="color:Crimson; text-shadow:1px 1px 1px white; font-size:90%">('
									+translationEnText[en]
								+')</span> '
								+'<span style="color:black; text-shadow:1px 1px 1px white; font-size:80%; line-height: 200%;"> '
									//+eval(translationEnVal[en])["en."+translationEnVal[en]][i]["verse"]
									//+eval(translationEnList[key])["en."+translationEnVal[en]][i]["verse"]
									+window[translationEnList[key]]["en."+translationEnVal[en]][i]["verse"]
								+'</span>'
							+'</div>'
						).appendTo('#englishTranslation-'+i);
					}
				}
			}
			
			// let add a style for the div's containing the comments
			if($.trim(html[i])!=""){
				document.getElementById('editorcontent'+i).style="padding=10px 10px; max-height:300px; overflow-x:hidden; overflow-y:auto; color:black;";
			}
			
			
		}	// end of  "if"  conditional
	}	// end of  "for loop"
	
	
	// to scroll the page on load vertically to reach the vertical position of the selected verse
	location.replace("#["+surah+":"+verse+"]");
	window.scrollBy(0,-100);
	
	
};	// end of the definition of the function "showSelectedVerses()"



function createEditor(editorId){
	if(editor) return;
	// Create a new editor instance inside the <div id="editor1"> element,
	// setting its value to html[i].
	var config = {};
	editor = CKEDITOR.appendTo('editor'+editorId, config, html[editorId]);
	// Update button states.
	document.getElementById('removeDontChange'+editorId).style.display = '';
	document.getElementById('remove'+editorId).style.display = '';
	document.getElementById('create'+editorId).style.display = 'none';
	document.getElementById('editorcontent'+editorId).style.display = 'none';
	CKEDITOR.config.width = 570;
};
function removeEditor(editorId){
	if (!editor) return;
	// Retrieve the editor content. In an Ajax application this data would be
	// sent to the server or used in any other way.
	html[editorId] = editor.getData();
	// Update <div> with "Edited Content".
	document.getElementById('editorcontent'+editorId).innerHTML = html[editorId];
	// Update button states.
	document.getElementById('removeDontChange'+editorId).style.display = 'none';
	document.getElementById('remove'+editorId).style.display = 'none';
	document.getElementById('create'+editorId).style.display = '';
	document.getElementById('editorcontent'+editorId).style.display = '';
	if($.trim(html[editorId])==""){
		document.getElementById('create'+editorId).title="افزودن یادداشت";
		document.getElementById('create'+editorId).src="main/images/new_comment.png";
		$("#commentCKE-"+editorId).remove();
	}else{
		document.getElementById('create'+editorId).title="ویرایش یادداشت";
		document.getElementById('create'+editorId).src="main/images/edit_comment.png";
		document.getElementById('editorcontent'+editorId).style="padding=10px 10px; max-height:300px; overflow-x:hidden; overflow-y:auto; color:black;";
		
		html[editorId]=html[editorId].replace(new RegExp(CKEDITOR.basePath, 'g'), 'main/ckeditor/'); // to make the smiley addresses from "absolute" into "relative" form
		
		if ($("#commentCKE-"+editorId).exists()){
			$("#commentCKE-"+editorId).html(html[editorId]);
		} else{
			$('<div id="commentCKE-'+editorId+'">').html(html[editorId]).appendTo('#temporary');
		}
		
		window.localStorage["TextEditorData"] = document.getElementById("temporary").innerHTML;	// stores the temporary innerHTML in browser's cache
	}
	// Destroy the editor.
	editor.destroy();
	editor=null;
};
function removeDontChangeEditor(editorId){
	if (!editor) return;
	// Update button states.
	document.getElementById('removeDontChange'+editorId).style.display = 'none';
	document.getElementById('remove'+editorId).style.display = 'none';
	document.getElementById('create'+editorId).style.display = '';
	document.getElementById('editorcontent'+editorId).style.display = '';
	// Destroy the editor.
	editor.destroy();
	editor=null;
};




/* ---------------------------------------------------------- */
/* the js code for searching functionality */




// first let make possibe for user to trigger "search" also by pressing "Enter" instead of only clicking on its button
$('#searchterm').keypress(function(ev){
	if (ev.which === 13) mySearch();
});

var searchResultsArray=[];
var searchConditions;	// let define it globally to be able to simply avoid using  eval(searchConditions); -- But yet I couldn't get rid of it, what shall I do?

function mySearch(){
	searchResultsArray=[];
	var query=$('#searchterm').val();			//alert(query);
	query=query.toLowerCase().replace(/[ًٌٍَُِّْء]+/g, "").replace(/[ئيى]+/g, "ی").replace(/[اآأإ\u0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه").replace(/[ك]+/g,"ک"); //alert(query);  // \u0670 :الف مقصوره!
	
	/*query=query.split(/[\s\u00A0]+/);		//alert(query);		// \u00A0 is non-breaking-space (&nbsp;)
	for(var i in query){
		if(query[i]=="و"){query[i]="&&"}
		else if(query[i]=="یا"){query[i]="||"}
		else{query[i]="str.search(\"$&\")>=0"}
	}
	searchConditions=query.join().replace(/,+/g," ");*/
	searchConditions=query.replace(/\s*\+\s*/g,"&&").replace(/\s*\|\s*/g,"||").replace(/\s*\+!\s*/g,"&&!").replace(/[-\u0600-\u06FF\u0750–\u077F\u08A0–\u08FF \w]+/g, "(str.indexOf(\"$&\")!=-1)");	//alert(searchConditions);	// it works for Arabic & Persian by the set  \u0600-\u06FF\u0750–\u077F\u08A0–\u08FF , and works for English by  \w  ... it substitutes any word in Arabic|Farsi|English by    (str.search('word')>=0)    so that e.g. (a||b)&&c becomes ((str.search(a)>=0)||(str.search(b)>=0))&&(str.search(c)>=0)
	
	//str.indexOf(query)!=-1    /    str.contains(query)    /    str.search(query)!=-1     /     here:   !=-1  ~  >=0
	// for English searching use  /../gi  instead of  /../g  for case insensitivity, or use something like: str.toLowerCase().indexOf(query.toLowerCase())
	
	var searchSourceVal=$('#searchSourceList').val();					//alert(searchSourceVal);
	var searchSourceText=$('#searchSourceList  option:selected').text();	//alert(searchSourceText);
	
	$.when(
		$('#searchResults').html(
			'<span id="searchResultNumberFound"></span>'
			
			+'<div id="searchHeader" style="padding:10px; text-align:center;">'
				+'<input id="btn_prev" class="myButton" onclick="prevPage()" type="image" src="main/images/minus.png" alt=""  title="صفحه‌ی قبل" align="center" width="15" height="15" style="margin-bottom:9px; margin-left:5px;" /> '
				+' صفحه‌ی '
				+' <span id="page"></span>  '
				+' <input id="btn_next" class="myButton" onclick="nextPage()" type="image" src="main/images/plus.png" alt=""  title="صفحه‌ی بعد" align="center" width="15" height="15" style="margin-bottom:9px; margin-left:5px;" />'
			+'</div>'
			+'<div id="listingTable" style="background:rgba(255,255,255,0.3); border-radius:10px; padding: 15px;"></div>'	// this is where the results found are to be listed in several pages
			+'<br>'
			+'<div style="display:table; width:100%;">'
				+'<div style="display:table-row">'
					+'<div style="display:table-cell; width:30%; text-align:center"></div>'
					+'<div id="searchFooter" style="display:table-cell; width:30%; text-align:center"></div>'
					+'<div id="goToPageMaster" style="display:table-cell; width:30%; text-align:center">'
				+'برو به صفحه‌ی  '
						+'<input id="goToPage" type="text" placeholder="..." title="انتخاب صفحه" style="width:20px;" />'
					+'</div>'
				+'</div>'
			+'</div>'
			+'<br>'
		),
		$("#searchFooter").html( $("#searchHeader").html() )
	).then(function(){
		changePage(1);
		
		// inorder to show nothing extra if there is no results found!
		if(counter==0){
			$('#searchHeader').empty();
			$('#listingTable').empty();
			$('#searchFooter').empty();
			$('#goToPageMaster').empty();
		}
		/*if(counter<=2*records_per_page){
			$('#goToPageMaster').empty();   // I don't know why this unactivate the previous/next buttons? Maybe it is related to working with "innerHTML" as people say "innerHTML"  is evil as it will destroy all the events inside the element
		}*/
	});
	
	// let make possibe for user to trigger "search" also by pressing "Enter" instead of only clicking on its button
	$('#goToPage').keypress(function(ev){
		if (ev.which === 13){
			changePage( $('#goToPage').val().replace(/۰/g,"0").replace(/۱/g,"1").replace(/۲/g,"2").replace(/۳/g,"3").replace(/۴/g,"4").replace(/۵/g,"5").replace(/۶/g,"6").replace(/۷/g,"7").replace(/۸/g,"8").replace(/۹/g,"9") );     // nested replaces make it possible for user also to be able to input the page number in Farsi!
		}
	});
	
	if($('#searchSourceList  option:selected').parent().attr('label')=="قرآن"){
		//alert(1);
		var counter=0;
		var str, string;
		for(var i in quran["quran-simple-enhanced"]){
			string=quran["quran-simple-enhanced"][i]["verse"];
			str=string.replace(/[ًٌٍَُِّْء]+/g, "").replace(/[ئيى]+/g, "ی").replace(/[اآأإ\u0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه").replace(/[ك]+/g,"ک");	// \u0670 :الف مقصوره!
			
			if(eval(searchConditions)){
				counter++;
				if(counter>250){
					break;
				}else{
					// to highlight the matching phrases in colors
					string=highlightSearchResults(string,query);
					
					searchResultsArray.push(
					//$("<div style='padding:10px;'>").html(
						'<br>'
						+'<span style="color:black; text-shadow:1px 1px 1px darkGrey; font-family:Neirizi; font-size:120%; line-height: 170%; padding:5px;"> '
							+persianDigits[counter]+'. '+string
						+'</span>'
						+'<a href="javascript:showSelectedVerses('+quran["quran-simple-enhanced"][i]["surah"]+','+quran["quran-simple-enhanced"][i]["ayah"]+');" style="text-shadow:1px 1px 1px black;">'
							+' ('
							+surah_info[quran["quran-simple-enhanced"][i]["surah"]]["nameAr"]
							+':'
							+persianDigits[quran["quran-simple-enhanced"][i]["ayah"]]
							+')'
						+'</a>'
					//).appendTo('#searchResults');
					);
				}
			}
		}
	}else if($('#searchSourceList  option:selected').parent().attr('label')=="فارسی"){
		//alert(2);
		for(key in translationFaList){
			if(translationFaList[key]==searchSourceVal){
				var counter=0;
				var str, string;
				for(var i in quran["quran-simple-enhanced"]){
					string=window[translationFaList[key]]["fa."+searchSourceVal][i]["verse"].replace(/0/g,"۰").replace(/1/g,"۱").replace(/2/g,"۲").replace(/3/g,"۳").replace(/4/g,"۴").replace(/5/g,"۵").replace(/6/g,"۶").replace(/7/g,"۷").replace(/8/g,"۸").replace(/9/g,"۹"); // the digits are Persianized as some translations include numbers in English digits
					str=string.replace(/[ًٌٍَُِّْء]+/g, "").replace(/[ئيى]+/g, "ی").replace(/[اآأإ\u0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه").replace(/[ك]+/g,"ک");	// \u0670 :الف مقصوره!
					
					if(eval(searchConditions)){
						counter++;
						if(counter>250){
							break;
						}else{
							// to highlight the matching phrases in colors
							string=highlightSearchResults(string,query);
							
							searchResultsArray.push(						
							//$("<div style='padding:10px;'>").html(
								'<br>'
								+'<span style="color:black; text-shadow:1px 1px 1px darkGrey; font-family:Neirizi; font-size:120%; line-height: 170%;"> '
									+persianDigits[counter]+'. '+string
								+'</span>'									
								+'<a href="javascript:showSelectedVerses('+quran["quran-simple-enhanced"][i]["surah"]+','+quran["quran-simple-enhanced"][i]["ayah"]+');" style="text-shadow:1px 1px 1px black;">'
									+' ('
									+surah_info[quran["quran-simple-enhanced"][i]["surah"]]["nameAr"]
									+':'
									+persianDigits[quran["quran-simple-enhanced"][i]["ayah"]]
									+')'
								+'</a>'
							//).appendTo('#searchResults');
							);
						}
					}
				}
			}
		}
	}else if($('#searchSourceList  option:selected').parent().attr('label')=="انگلیسی"){
		//alert(3);
		for(key in translationEnList){
			if(translationEnList[key]==searchSourceVal){
				var counter=0;
				var str, string;
				for(var i in quran["quran-simple-enhanced"]){
					string=window[translationEnList[key]]["en."+searchSourceVal][i]["verse"];
					str=string.toLowerCase();	//.replace(/[ًٌٍَُِّْ\ء]+/g, "").replace(/[ئي]+/g, "ی").replace(/[اآأإu0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه");	// \u0670 :الف مقصوره!
					
					if(eval(searchConditions)){
						counter++;
						if(counter>250){
							break;
						}else{
							// to highlight the matching phrases in colors
							string=highlightSearchResults(string,query);
							
							searchResultsArray.push(
							//$("<div style='padding:10px; text-align:left;' lang='en' dir='ltr'>").html(
								'<div style="padding:10px; text-align:left;" lang="en" dir="ltr">'
									//'<br>'
									+'<span style="color:black; text-shadow:1px 1px 1px darkGrey; font-size:90%; line-height: 170%;"> '
										+counter+'. '+string
									+'</span>'									
									+'<a href="javascript:showSelectedVerses('+quran["quran-simple-enhanced"][i]["surah"]+','+quran["quran-simple-enhanced"][i]["ayah"]+');" style="text-shadow:1px 1px 1px black;">'
										+' ('
										+surah_info[quran["quran-simple-enhanced"][i]["surah"]]["nameAr"]
										+':'
										+persianDigits[quran["quran-simple-enhanced"][i]["ayah"]]
										+')'
									+'</a>'
								+'</div>'
							//).appendTo('#searchResults');
							);
						}
					}
				}
			}
		}
	}else{	// this is for searching through comments
		//alert(4);
		var counter=0;
		var str, string, commentID;
		$('#temporary').find('div').each(function(){
			commentID=$(this).attr('id').replace(/(commentCKE-)/,""); // it gets commentCKE-i and gives i
			//HTML is not a regular language and hence cannot be parsed by regular expressions. Regex queries are not equipped to break down HTML into its meaningful parts. So use instead:
			string=$('#commentCKE-'+commentID)[0].innerText
				    || $('#commentCKE-'+commentID)[0].textContent;		//alert(string);
			str=string.replace(/[ًٌٍَُِّْء]+/g, "").replace(/[ئيى]+/g, "ی").replace(/[اآأإ\u0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه").replace(/[ك]+/g,"ک").toLowerCase();	// \u0670 :الف مقصوره!
			if(eval(searchConditions)){
				counter++;
				if(counter>250){
					return false;
				}else{
					// to highlight the matching phrases in colors
					string=highlightSearchResults(string,query);
					
					searchResultsArray.push(
					//$("<div style='padding:10px;'>").html(
						'<br>'
						+'<span style="color:black; text-shadow:1px 1px 1px darkGrey; font-family:Neirizi; font-size:120%; line-height: 170%; padding:5px;"> '
							+persianDigits[counter]+'. '+string
						+'</span>'
						+'<a href="javascript:showSelectedVerses('+quran["quran-simple-enhanced"][commentID]["surah"]+','+quran["quran-simple-enhanced"][commentID]["ayah"]+');" style="text-shadow:1px 1px 1px black;">'
							+' ('
							+surah_info[quran["quran-simple-enhanced"][commentID]["surah"]]["nameAr"]
							+':'
							+persianDigits[quran["quran-simple-enhanced"][commentID]["ayah"]]
							+')'
						+'</a>'
					//).appendTo('#searchResults');
					);
				}
			}
		});			
	}
	
	/*if($('#searchSourceList  option:selected').parent().attr('label')=="انگلیسی"){
		if(counter>250){
			counter--;
			$('#searchResultNumberFound').html(
				'<p>'
				+'The number of the results found in [\"'+searchSourceText+'\"] is more than 250, here only the first 250 results are shown:'
				+'</p>'	
			);
			//alert("تنها تعداد ۲۵۰ یافته‌ی اول نمایش داده می‌شود");	// since a limited number of persian digits is defined by the array    persianDigits[}
		}else{
			$('#searchResultNumberFound').html(
				'<p>'
				+'The number of the results found in [\"'+searchSourceText+'\"]: '
				+'<span style="color:red">'+counter+'</span>'
				+'</p>'
			);
		}
		$('#searchResultNumberFound').css("text-align","left");	// .attr({lang:en,dir:ltr})
	}else{*/
		if(counter>250){
			counter--;
			$('#searchResultNumberFound').html(
				'<p style="text-shadow:1px 1px 1px black;">'
			+'نتایج جستجو در \"'+searchSourceText+'\":'
				+'<br>'
				+'<span style="color:orange;">(تعداد یافته‌ها از ۲۵۰ بیشتر است، در اینجا تنها ۲۵۰ یافته‌ی اول نمایش داده می‌شوند)</span>'
				+'</p>'	
			);
			//alert("تنها تعداد ۲۵۰ یافته‌ی اول نمایش داده می‌شود");	// since a limited number of persian digits is defined by the array    persianDigits[}
		}else{
			$('#searchResultNumberFound').html(
				'<p style="text-shadow:1px 1px 1px black;">'
			+'نتایج جستجو در \"'+searchSourceText+'\": '
				+'<span style="color:orange"> (تعداد یافته‌ها: '
					+'<span style="color:red">'+persianDigits[counter]+'</span>'
				+')</span>'
				+'</p>'
			);
		}
	//}
}

function highlightSearchResults(string,query){
	var stringArray=string.split(/\s+/g); //alert(stringArray); //an array that contains the "found" (approved with respect to the searchConditions) verse or its translation word by word
	var queryHighlight=query.split(/[\s+\|(+!)]+/);	//alert(queryHighlight);
	var highlightColorList=["Yellow", "LawnGreen", "DeepPink", "Aqua", "DarkOrange", "DodgerBlue", "Olive", "Crimson", "OrangeRed", "DarkOrchid"];
	
	for(var j in stringArray){
		for(var k in queryHighlight){
			if(stringArray[j].replace(/[ًٌٍَُِّْء]+/g, "").replace(/[ئيى]+/g, "ی").replace(/[اآأإ\u0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه").replace(/[ك]+/g,"ک").toLowerCase().indexOf( queryHighlight[k].replace(/[ًٌٍَُِّْء]+/g, "").replace(/[ئيى]+/g, "ی").replace(/[اآأإ\u0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه").replace(/[ك]+/g,"ک").toLowerCase() )!=-1){
				stringArray[j]="<span style='color:"+highlightColorList[k]+"; text-shadow:1px 1px 1px black;'>"+stringArray[j]+"</span>";
			}
		}
	}
	return string=stringArray.join().replace(/,/g," ");						
}




/* ---------------------------------------------------------- */
/* to browse the client's computer for finding and openning a file containing his last saved comments */


/*
function openFunction(){
	$('#Openfile').click();		// this opens the file browser dialog for selecting a file to open
	$('#Openfile').change(function(){
		//$('#temporary').empty();
		$.when(
			//alert($('#Openfile').val()),  // why does it alert almost as many times as the button is clicked? 
			$('#temporary').load( $('#Openfile').val() )	// $('#Openfile').val() contains path to the file
		).then(function(){
			showSelectedVerses( Number($("#chapterList").val()) , Number($("#verseNumList").val()) );
		});
	});		
	return;		
};
*/
var openFile=document.getElementById("Openfile");

function openFunction(){
	openFile.click();	// this opens the file browser dialog for selecting a file to open
	return;
};

openFile.addEventListener('change', function() {
	var fileToLoad=openFile.files[0];			// the selected file itself as an object?
	alert(openFile.value  .split('\\').pop());		// the name of the selected file
	
	if(fileToLoad){
		var reader=new FileReader();
		reader.readAsText(fileToLoad, "UTF-8");
		reader.onload=function(event){
			document.getElementById("temporary").innerHTML=event.target.result;
			showSelectedVerses( Number($("#chapterList").val()) , Number($("#verseNumList").val()) );
		};
		reader.onerror=function(event){
			document.getElementById("temporary").innerHTML="بارگذاری فایل انتخاب شده ناموفق بود!";
		};
	}	
});






/* ---------------------------------------------------------- */
/* to save a file containing the client's comments */


// -----------------------------------------------------------------------------
// first: for finding the present date in Persian Calendar, used for naming the file to save

function gregorian_to_jalali(gy,gm,gd){
	g_d_m=[0,31,59,90,120,151,181,212,243,273,304,334];
	jy=(gy<=1600)?0:979;
	gy-=(gy<=1600)?621:1600;
	gy2=(gm>2)?(gy+1):gy;
	days=(365*gy) +(parseInt((gy2+3)/4)) -(parseInt((gy2+99)/100)) +(parseInt((gy2+399)/400)) -80 +gd +g_d_m[gm-1];
	jy+=33*(parseInt(days/12053)); 
	days%=12053;
	jy+=4*(parseInt(days/1461));
	days%=1461;
	jy+=parseInt((days-1)/365);
 	if(days > 365)days=(days-1)%365;
	jm=(days < 186)?1+parseInt(days/31):7+parseInt((days-186)/30);
	jd=1+((days < 186)?(days%31):((days-186)%30));
	return [jy,jm,jd];
};
var persianMonth=["","فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"];
var morningAfternnon;
function persianDateTime(){
	d=new Date();
	g_y=d.getFullYear();
	g_m=d.getMonth()+1;
	g_d=d.getDate();
	shamsi=gregorian_to_jalali(g_y,g_m,g_d);
	H=d.getHours();
	//H=(H<10)?"0"+H:H;
	morningAfternnon= 
		(H==12)  ? "ظهر" : (
			(H!=0) ? (
				(H<12) ? "صبح" : (
					(H>=20) ? "شب" :  "بعد از ظهر"
				)
			)
			: "نیمه‌شب"
		);
	/*if(H==12){
		morningAfternnon="ظهر";
	}else if(H==0){
		morningAfternnon="نیمه‌شب";
	}else if(H<12 && H!=0){
		morningAfternnon="صبح";
	}else if(H>20){
		morningAfternnon="شب";
	}else{
		morningAfternnon="بعد از ظهر";
	}*/
	H= (H<=12)  ?  H  :  H-12;
	i=d.getMinutes();
	i=(i<10)?"0"+i:i;
	//s=d.getSeconds();
	//s=(s<10)?"0"+s:s;
	//return shamsi[0]+"-"+persianMonth[shamsi[1]]+"-"+shamsi[2]+"("+H+" "+i+")";
	return "("+shamsi[0]+"٫"+shamsi[1]+"٫"+shamsi[2]+" ساعت "+H+":"+i+" "+morningAfternnon+")";	// "نسخه‌ی "+shamsi[2]+" "+persianMonth[shamsi[1]]+" "+shamsi[0]+" ساعت "+H+" و "+i+" دقیقه‌ی "+morningAfternnon;
};
// now you can use the present date by calling the function  persianDateTime()

function saveFunctioin(){
	// If you  want to change the content of  "commentCKE-1"  when the save botton is clicked!
	//(function () {
	//	document.getElementById('#commentCKE-1').innerHTML = CKEDITOR.instances.CKE-1.getData();
	//})();		
	
	// ------- if using  download.js
	var today=persianDateTime().replace(/0/g,'۰').replace(/1/g,'۱').replace(/2/g,'۲').replace(/3/g,'۳').replace(/4/g,'۴').replace(/5/g,'۵').replace(/6/g,'۶').replace(/7/g,'۷').replace(/8/g,'۸').replace(/9/g,'۹').replace(/\:/g,"٫");
	download(document.getElementById("temporary").innerHTML, "یادداشت-"+today+".txt", "text/html");	
	// ------- if not using  download.js, but saving comment would be lame, e.g. colors are not saved and etc.
	//var a = document.body.appendChild(document.createElement("a"));
	//a.download = "myComments.txt";
	//a.href = "data:text/html," + document.getElementById("temporary").innerHTML;
	//a.click();
};




/* ---------------------------------------------------------- */
/* to ask the client if he is sure to leave the page (close the page or refresh it) if has not saved the file yet */




//$(window).bind('beforeunload', function(){
//	return 'شما در حال ترک نرم‌افزار هستید، آیا تمایل دارید یادداشت‌های خود را در صورت تغییر ذخیره نمایید؟';
//});	
window.onbeforeunload = function() {
	return "توصیه بر ذخیره‌ی داده‌ها پیش از حروج از نرم‌افزار است ... آیا اطمینان دارید می‌خواهید از نرم‌افزار خارج شوید؟!";
}	
//window.addEventListener("beforeunload", function(event) {
//	event.returnValue = "شما در حال ترک نرم‌افزار هستید، آیا تمایل دارید یادداشت‌های خود را در صورت تغییر ذخیره نمایید؟";
	//saveFunctioin();
//});