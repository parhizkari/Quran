/*
By the name of Allah, the All-providing and the most Merciful God,
myQuran is a simple program based on web technology which works totally offline
and is suitable for browsing Quran together with several Persian and some English
translations, enhanced with the possibility to leave a comment for any of the verses
of Quran. The comments can be saved and loaded afterwards. A search engine, also,
makes possible to search through the Arabic text of Quran, and through each
individual translation of it, as well as through the comments already loaded.

Copyright (C) 2016  Owzhan Parhizkari (اوژن پرهیزکاری)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program: "gpl.txt".  If not, see <http://www.gnu.org/licenses/>.

Contact information: o.parhizkari@chmail.ir
*/


/* ---------------------------------------------------------- */
/* script for the "toggle-wrap" action for openning and closing the side menus "aside" and "asideSearch" */


$(document).ready(function(){
	$('#toggle-wrap').on('click', function(){
		if ($('#toggle-wrap').hasClass('active')){
			$('#toggle-wrap').removeClass('active');
			$('aside').animate({width: 'toggle'}, 500);
			//alert(1);
		}else{
			$('#toggle-wrap').addClass('active');
			$('aside').animate({width: 'toggle'}, 500);
			//alert(2);
		}
	});
	$('#toggle-wrap-search').on('click', function(){
		if ($('#toggle-wrap-search').hasClass('active')){
			$('#toggle-wrap-search').removeClass('active');
			$('asideSearch').animate({width: 'toggle'}, 500);
			//alert(1);
		}else{
			$('#toggle-wrap-search').addClass('active');
			$('asideSearch').animate({width: 'toggle'}, 500);
			//alert(2);
		}
	});
	$('#main').on('click', function(){
		if ($('#toggle-wrap').hasClass('active')){
			$('#toggle-wrap').removeClass('active');
			$('aside').animate({width: 'toggle'}, 500);
			//alert(3);
		}
		if ($('#toggle-wrap-search').hasClass('active')){
			$('#toggle-wrap-search').removeClass('active');
			$('asideSearch').animate({width: 'toggle'}, 500);
			//alert(3);
		}
	});
});


/* ---------------------------------------------------------- */
/* script for pagination of the search results */


/* this file uses and is inspired by "http://stackoverflow.com/questions/25434813/simple-pagination-in-javascript"    and "https://www.script-tutorials.com/how-to-create-easy-pagination-with-jquery/" */
var current_page = 1;
var records_per_page = 10;

function prevPage(){
	if (current_page > 1){
		current_page--;
		changePage(current_page);
	}
}
function nextPage(){
	if (current_page < numPages()){
		current_page++;
		changePage(current_page);
	}
}

function changePage(page){
	// Validate page
	if (page < 1) page = 1;
	if (page > numPages()) page = numPages();    
	current_page=page;
	document.getElementById("listingTable").innerHTML = "";
	
	for (var i = (page-1) * records_per_page; i < (page * records_per_page) && i < searchResultsArray.length; i++){
		document.getElementById("listingTable").innerHTML+=searchResultsArray[i]+"<br>";
	}
	
	document.getElementById("page").innerHTML = persianDigits[page]+" از "+persianDigits[numPages()];
	
	if (page == 1) {document.getElementById("btn_prev").style.visibility = "hidden";}
	else{document.getElementById("btn_prev").style.visibility = "visible";}
	if (page == numPages()){document.getElementById("btn_next").style.visibility = "hidden";}
	else{document.getElementById("btn_next").style.visibility = "visible";}
	
	$("#searchFooter").html( $("#searchHeader").html() );
}
function numPages(){
	return Math.ceil(searchResultsArray.length / records_per_page);
}


/* ---------------------------------------------------------- */
/* script for providing the required information on the Surah's of Quran */


var surah_info = {
	1:  {nameAr:"الْفَاتِحَة", nameFa:"حمد", nameEn:"The Praise", numVerse:7, revealedAr:"مکّی", revealedEn:"Makki"},
	2:  {nameAr:"الْبَقَرَة", nameFa:"گاو", nameEn:"The Cow", numVerse:286, revealedAr:"مدنی", revealedEn:"Madani"},
	3:  {nameAr:"آلِ عِمْرَان", nameFa:"", nameEn:"", numVerse:200, revealedAr:"مدنی", revealedEn:""},
	4:  {nameAr:"النِّسَآء", nameFa:"", nameEn:"", numVerse:176, revealedAr:"مدنی", revealedEn:""},
	5:  {nameAr:"الْمَآئِدَة", nameFa:"", nameEn:"", numVerse:120, revealedAr:"مدنی", revealedEn:""},
	6:  {nameAr:"الْأَنْعَام", nameFa:"", nameEn:"", numVerse:165, revealedAr:"مکّی", revealedEn:""},
	7:  {nameAr:"الْأَعْرَاف", nameFa:"", nameEn:"", numVerse:206, revealedAr:"مکّی", revealedEn:""},
	8:  {nameAr:"الْأَنْفَال", nameFa:"", nameEn:"", numVerse:75, revealedAr:"مدنی", revealedEn:""},
	9:  {nameAr:"التَّوْبَة", nameFa:"", nameEn:"", numVerse:129, revealedAr:"مدنی", revealedEn:""},
	10:  {nameAr:"يُونُس", nameFa:"", nameEn:"", numVerse:109, revealedAr:"مکّی", revealedEn:""},
	11:  {nameAr:"هُود", nameFa:"", nameEn:"", numVerse:123, revealedAr:"مکّی", revealedEn:""},
	12:  {nameAr:"يُوسُف", nameFa:"", nameEn:"", numVerse:111, revealedAr:"مکّی", revealedEn:""},
	13:  {nameAr:"الرَّعْد", nameFa:"", nameEn:"", numVerse:43, revealedAr:"مدنی", revealedEn:""},
	14:  {nameAr:"إِبْرَاهِیم", nameFa:"", nameEn:"", numVerse:52, revealedAr:"مکّی", revealedEn:""},
	15:  {nameAr:"الْحِجْر", nameFa:"", nameEn:"", numVerse:99, revealedAr:"مکّی", revealedEn:""},
	16:  {nameAr:"النَّحْل", nameFa:"", nameEn:"", numVerse:128, revealedAr:"مکّی", revealedEn:""},
	17:  {nameAr:"الْإِسْرَآء", nameFa:"", nameEn:"", numVerse:111, revealedAr:"مکّی", revealedEn:""},
	18:  {nameAr:"الْكَهْف", nameFa:"", nameEn:"", numVerse:110, revealedAr:"مکّی", revealedEn:""},
	19:  {nameAr:"مَرْيَم", nameFa:"", nameEn:"", numVerse:98, revealedAr:"مکّی", revealedEn:""},
	20:  {nameAr:"طٰهٰ", nameFa:"", nameEn:"", numVerse:135, revealedAr:"مکّی", revealedEn:""},
	21:  {nameAr:"الْأَنْبِيَآء", nameFa:"", nameEn:"", numVerse:112, revealedAr:"مکّی", revealedEn:""},
	22:  {nameAr:"الْحَجّ", nameFa:"", nameEn:"", numVerse:78, revealedAr:"مدنی", revealedEn:""},
	23:  {nameAr:"الْمُؤْمِنُون", nameFa:"", nameEn:"", numVerse:118, revealedAr:"مکّی", revealedEn:""},
	24:  {nameAr:"النُّور", nameFa:"", nameEn:"", numVerse:64, revealedAr:"مدنی", revealedEn:""},
	25:  {nameAr:"الْفُرْقَان", nameFa:"", nameEn:"", numVerse:77, revealedAr:"مکّی", revealedEn:""},
	26:  {nameAr:"الشُّعَرَآء", nameFa:"", nameEn:"", numVerse:227, revealedAr:"مکّی", revealedEn:""},
	27:  {nameAr:"النَّمْل", nameFa:"", nameEn:"", numVerse:93, revealedAr:"مکّی", revealedEn:""},
	28:  {nameAr:"الْقَصَص", nameFa:"", nameEn:"", numVerse:88, revealedAr:"مکّی", revealedEn:""},
	29:  {nameAr:"الْعَنْكَبُوت", nameFa:"", nameEn:"", numVerse:69, revealedAr:"مکّی", revealedEn:""},
	30:  {nameAr:"الرُّوم", nameFa:"", nameEn:"", numVerse:60, revealedAr:"مکّی", revealedEn:""},
	31:  {nameAr:"لُقْمَان", nameFa:"", nameEn:"", numVerse:34, revealedAr:"مکّی", revealedEn:""},
	32:  {nameAr:"السَّجْدَة", nameFa:"", nameEn:"", numVerse:30, revealedAr:"مکّی", revealedEn:""},
	33:  {nameAr:"الْأَحْزَاب", nameFa:"", nameEn:"", numVerse:73, revealedAr:"مدنی", revealedEn:""},
	34:  {nameAr:"سَبَأ", nameFa:"", nameEn:"", numVerse:54, revealedAr:"مکّی", revealedEn:""},
	35:  {nameAr:"فَاطِر", nameFa:"", nameEn:"", numVerse:45, revealedAr:"مکّی", revealedEn:""},
	36:  {nameAr:"يٰسٓ", nameFa:"", nameEn:"", numVerse:83, revealedAr:"مکّی", revealedEn:""},
	37:  {nameAr:"الصَّافَّات", nameFa:"", nameEn:"", numVerse:182, revealedAr:"مکّی", revealedEn:""},
	38:  {nameAr:"صٓ", nameFa:"", nameEn:"", numVerse:88, revealedAr:"مکّی", revealedEn:""},
	39:  {nameAr:"الزُّمَر", nameFa:"", nameEn:"", numVerse:75, revealedAr:"مکّی", revealedEn:""},
	40:  {nameAr:"غَافِر", nameFa:"", nameEn:"", numVerse:85, revealedAr:"مکّی", revealedEn:""},
	41:  {nameAr:"فُصِّلَت", nameFa:"", nameEn:"", numVerse:54, revealedAr:"مکّی", revealedEn:""},
	42:  {nameAr:"الشُّورَىٰ", nameFa:"", nameEn:"", numVerse:53, revealedAr:"مکّی", revealedEn:""},
	43:  {nameAr:"الزُّخْرُف", nameFa:"", nameEn:"", numVerse:89, revealedAr:"مکّی", revealedEn:""},
	44:  {nameAr:"الدُّخَان", nameFa:"", nameEn:"", numVerse:59, revealedAr:"مکّی", revealedEn:""},
	45:  {nameAr:"الْجَاثِيَة", nameFa:"", nameEn:"", numVerse:37, revealedAr:"مکّی", revealedEn:""},
	46:  {nameAr:"الْأَحْقَاف", nameFa:"", nameEn:"", numVerse:35, revealedAr:"مکّی", revealedEn:""},
	47:  {nameAr:"مُحَمَّد", nameFa:"", nameEn:"", numVerse:38, revealedAr:"مدنی", revealedEn:""},
	48:  {nameAr:"الْفَتْح", nameFa:"", nameEn:"", numVerse:29, revealedAr:"مدنی", revealedEn:""},
	49:  {nameAr:"الْحُجُرَات", nameFa:"", nameEn:"", numVerse:18, revealedAr:"مدنی", revealedEn:""},
	50:  {nameAr:"قٓ", nameFa:"", nameEn:"", numVerse:45, revealedAr:"مکّی", revealedEn:""},
	51:  {nameAr:"الذَّارِيَات", nameFa:"", nameEn:"", numVerse:60, revealedAr:"مکّی", revealedEn:""},
	52:  {nameAr:"الطُّور", nameFa:"", nameEn:"", numVerse:49, revealedAr:"مکّی", revealedEn:""},
	53:  {nameAr:"النَّجْم", nameFa:"", nameEn:"", numVerse:62, revealedAr:"مکّی", revealedEn:""},
	54:  {nameAr:"الْقَمَر", nameFa:"", nameEn:"", numVerse:55, revealedAr:"مکّی", revealedEn:""},
	55:  {nameAr:"الرَّحْمَٰن", nameFa:"", nameEn:"", numVerse:78, revealedAr:"مدنی", revealedEn:""},
	56:  {nameAr:"الْوَاقِعَة", nameFa:"", nameEn:"", numVerse:96, revealedAr:"مکّی", revealedEn:""},
	57:  {nameAr:"الْحَدِید", nameFa:"", nameEn:"", numVerse:29, revealedAr:"مدنی", revealedEn:""},
	58:  {nameAr:"الْمُجَادَلَة", nameFa:"", nameEn:"", numVerse:22, revealedAr:"مدنی", revealedEn:""},
	59:  {nameAr:"الْحَشْر", nameFa:"", nameEn:"", numVerse:24, revealedAr:"مدنی", revealedEn:""},
	60:  {nameAr:"الْمُمْتَحِنَة", nameFa:"", nameEn:"", numVerse:13, revealedAr:"مدنی", revealedEn:""},
	61:  {nameAr:"الصَّفّ", nameFa:"", nameEn:"", numVerse:14, revealedAr:"مدنی", revealedEn:""},
	62:  {nameAr:"الْجُمُعَة", nameFa:"", nameEn:"", numVerse:11, revealedAr:"مدنی", revealedEn:""},
	63:  {nameAr:"الْمُنَافِقُون", nameFa:"", nameEn:"", numVerse:11, revealedAr:"مدنی", revealedEn:""},
	64:  {nameAr:"التَّغَابُن", nameFa:"", nameEn:"", numVerse:18, revealedAr:"مدنی", revealedEn:""},
	65:  {nameAr:"الطَّلَاق", nameFa:"", nameEn:"", numVerse:12, revealedAr:"مدنی", revealedEn:""},
	66:  {nameAr:"التَّحْرِیم", nameFa:"", nameEn:"", numVerse:12, revealedAr:"مدنی", revealedEn:""},
	67:  {nameAr:"الْمُلْك", nameFa:"", nameEn:"", numVerse:30, revealedAr:"مکّی", revealedEn:""},
	68:  {nameAr:"الْقَلَم", nameFa:"", nameEn:"", numVerse:52, revealedAr:"مکّی", revealedEn:""},
	69:  {nameAr:"الْحَاقَّة", nameFa:"", nameEn:"", numVerse:52, revealedAr:"مکّی", revealedEn:""},
	70:  {nameAr:"الْمَعَارِج", nameFa:"", nameEn:"", numVerse:44, revealedAr:"مکّی", revealedEn:""},
	71:  {nameAr:"نُوح", nameFa:"", nameEn:"", numVerse:28, revealedAr:"مکّی", revealedEn:""},
	72:  {nameAr:"الْجِنّ", nameFa:"", nameEn:"", numVerse:28, revealedAr:"مکّی", revealedEn:""},
	73:  {nameAr:"الْمُزَّمِّل", nameFa:"", nameEn:"", numVerse:20, revealedAr:"مکّی", revealedEn:""},
	74:  {nameAr:"الْمُدَّثِّر", nameFa:"", nameEn:"", numVerse:56, revealedAr:"مکّی", revealedEn:""},
	75:  {nameAr:"الْقِيَامَة", nameFa:"", nameEn:"", numVerse:40, revealedAr:"مکّی", revealedEn:""},
	76:  {nameAr:"الْإِنْسَان", nameFa:"", nameEn:"", numVerse:31, revealedAr:"مدنی", revealedEn:""},
	77:  {nameAr:"الْمُرْسَلَات", nameFa:"", nameEn:"", numVerse:50, revealedAr:"مکّی", revealedEn:""},
	78:  {nameAr:"النَّبَأ", nameFa:"", nameEn:"", numVerse:40, revealedAr:"مکّی", revealedEn:""},
	79:  {nameAr:"النَّازِعَات", nameFa:"", nameEn:"", numVerse:46, revealedAr:"مکّی", revealedEn:""},
	80:  {nameAr:"عَبَس", nameFa:"", nameEn:"", numVerse:42, revealedAr:"مکّی", revealedEn:""},
	81:  {nameAr:"التَّکْوِیر", nameFa:"", nameEn:"", numVerse:29, revealedAr:"مکّی", revealedEn:""},
	82:  {nameAr:"الْإِنْفِطَار", nameFa:"", nameEn:"", numVerse:19, revealedAr:"مکّی", revealedEn:""},
	83:  {nameAr:"الْمُطَفِّفِین", nameFa:"", nameEn:"", numVerse:36, revealedAr:"مکّی", revealedEn:""},
	84:  {nameAr:"الْإِنْشِقَاق", nameFa:"", nameEn:"", numVerse:25, revealedAr:"مکّی", revealedEn:""},
	85:  {nameAr:"الْبُرُوج", nameFa:"", nameEn:"", numVerse:22, revealedAr:"مکّی", revealedEn:""},
	86:  {nameAr:"الطَّارِق", nameFa:"", nameEn:"", numVerse:17, revealedAr:"مکّی", revealedEn:""},
	87:  {nameAr:"الْأَعْلَیٰ", nameFa:"", nameEn:"", numVerse:19, revealedAr:"مکّی", revealedEn:""},
	88:  {nameAr:"الْغَاشِيَة", nameFa:"", nameEn:"", numVerse:26, revealedAr:"مکّی", revealedEn:""},
	89:  {nameAr:"الْفَجْر", nameFa:"", nameEn:"", numVerse:30, revealedAr:"مکّی", revealedEn:""},
	90:  {nameAr:"الْبَلَد", nameFa:"", nameEn:"", numVerse:20, revealedAr:"مکّی", revealedEn:""},
	91:  {nameAr:"الشَّمْس", nameFa:"", nameEn:"", numVerse:15, revealedAr:"مکّی", revealedEn:""},
	92:  {nameAr:"اللَّيْل", nameFa:"", nameEn:"", numVerse:21, revealedAr:"مکّی", revealedEn:""},
	93:  {nameAr:"الضُّحَیٰ", nameFa:"", nameEn:"", numVerse:11, revealedAr:"مکّی", revealedEn:""},
	94:  {nameAr:"الشَّرْح", nameFa:"", nameEn:"", numVerse:8, revealedAr:"مکّی", revealedEn:""},
	95:  {nameAr:"التِّین", nameFa:"", nameEn:"", numVerse:8, revealedAr:"مکّی", revealedEn:""},
	96:  {nameAr:"الْعَلَق", nameFa:"", nameEn:"", numVerse:19, revealedAr:"مکّی", revealedEn:""},
	97:  {nameAr:"الْقَدْر", nameFa:"", nameEn:"", numVerse:5, revealedAr:"مکّی", revealedEn:""},
	98:  {nameAr:"الْبَيِّنَة", nameFa:"", nameEn:"", numVerse:8, revealedAr:"مدنی", revealedEn:""},
	99:  {nameAr:"الزَّلْزَلَة", nameFa:"", nameEn:"", numVerse:8, revealedAr:"مدنی", revealedEn:""},
	100:  {nameAr:"الْعَادِيَات", nameFa:"", nameEn:"", numVerse:11, revealedAr:"مکّی", revealedEn:""},
	101:  {nameAr:"الْقَارِعَة", nameFa:"", nameEn:"", numVerse:11, revealedAr:"مکّی", revealedEn:""},
	102:  {nameAr:"التَّكَاثُر", nameFa:"", nameEn:"", numVerse:8, revealedAr:"مکّی", revealedEn:""},
	103:  {nameAr:"الْعَصْر", nameFa:"", nameEn:"", numVerse:3, revealedAr:"مکّی", revealedEn:""},
	104:  {nameAr:"الْهُمَزَة", nameFa:"", nameEn:"", numVerse:9, revealedAr:"مکّی", revealedEn:""},
	105:  {nameAr:"الْفِیل", nameFa:"", nameEn:"", numVerse:5, revealedAr:"مکّی", revealedEn:""},
	106:  {nameAr:"قُرَيْش", nameFa:"", nameEn:"", numVerse:4, revealedAr:"مکّی", revealedEn:""},
	107:  {nameAr:"الْمَاعُون", nameFa:"", nameEn:"", numVerse:7, revealedAr:"مکّی", revealedEn:""},
	108:  {nameAr:"الْكَوْثَر", nameFa:"", nameEn:"", numVerse:3, revealedAr:"مکّی", revealedEn:""},
	109:  {nameAr:"الْكَافِرُون", nameFa:"", nameEn:"", numVerse:6, revealedAr:"مکّی", revealedEn:""},
	110:  {nameAr:"النَّصْر", nameFa:"", nameEn:"", numVerse:3, revealedAr:"مدنی", revealedEn:""},
	111:  {nameAr:"الْمَسَد", nameFa:"", nameEn:"", numVerse:5, revealedAr:"مکّی", revealedEn:""},
	112:  {nameAr:"الْإِخْلَاص", nameFa:"", nameEn:"", numVerse:4, revealedAr:"مکّی", revealedEn:""},
	113:  {nameAr:"الْفَلَق", nameFa:"", nameEn:"", numVerse:5, revealedAr:"مکّی", revealedEn:""},
	114:  {nameAr:"النَّاس", nameFa:"", nameEn:"", numVerse:6, revealedAr:"مکّی", revealedEn:""}		
};


/* ---------------------------------------------------------- */
/* script for defining some persian digits in an array ... maybe it was more effecient to use regex to change every english number by a persian one? I have done that for pagination of the search results (in GoToPage input box) */


var persianDigits = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹", "۱۰", "۱۱", "۱۲", "۱۳", "۱۴", "۱۵", "۱۶", "۱۷", "۱۸", "۱۹", "۲۰", "۲۱", "۲۲", "۲۳", "۲۴", "۲۵", "۲۶", "۲۷", "۲۸", "۲۹", "۳۰", "۳۱", "۳۲", "۳۳", "۳۴", "۳۵", "۳۶", "۳۷", "۳۸", "۳۹", "۴۰", "۴۱", "۴۲", "۴۳", "۴۴", "۴۵", "۴۶", "۴۷", "۴۸", "۴۹", "۵۰", "۵۱", "۵۲", "۵۳", "۵۴", "۵۵", "۵۶", "۵۷", "۵۸", "۵۹", "۶۰", "۶۱", "۶۲", "۶۳", "۶۴", "۶۵", "۶۶", "۶۷", "۶۸", "۶۹", "۷۰", "۷۱", "۷۲", "۷۳", "۷۴", "۷۵", "۷۶", "۷۷", "۷۸", "۷۹", "۸۰", "۸۱", "۸۲", "۸۳", "۸۴", "۸۵", "۸۶", "۸۷", "۸۸", "۸۹", "۹۰", "۹۱", "۹۲", "۹۳", "۹۴", "۹۵", "۹۶", "۹۷", "۹۸", "۹۹", "۱۰۰", "۱۰۱", "۱۰۲", "۱۰۳", "۱۰۴", "۱۰۵", "۱۰۶", "۱۰۷", "۱۰۸", "۱۰۹", "۱۱۰", "۱۱۱", "۱۱۲", "۱۱۳", "۱۱۴", "۱۱۵", "۱۱۶", "۱۱۷", "۱۱۸", "۱۱۹", "۱۲۰", "۱۲۱", "۱۲۲", "۱۲۳", "۱۲۴", "۱۲۵", "۱۲۶", "۱۲۷", "۱۲۸", "۱۲۹", "۱۳۰", "۱۳۱", "۱۳۲", "۱۳۳", "۱۳۴", "۱۳۵", "۱۳۶", "۱۳۷", "۱۳۸", "۱۳۹", "۱۴۰", "۱۴۱", "۱۴۲", "۱۴۳", "۱۴۴", "۱۴۵", "۱۴۶", "۱۴۷", "۱۴۸", "۱۴۹", "۱۵۰", "۱۵۱", "۱۵۲", "۱۵۳", "۱۵۴", "۱۵۵", "۱۵۶", "۱۵۷", "۱۵۸", "۱۵۹", "۱۶۰", "۱۶۱", "۱۶۲", "۱۶۳", "۱۶۴", "۱۶۵", "۱۶۶", "۱۶۷", "۱۶۸", "۱۶۹", "۱۷۰", "۱۷۱", "۱۷۲", "۱۷۳", "۱۷۴", "۱۷۵", "۱۷۶", "۱۷۷", "۱۷۸", "۱۷۹", "۱۸۰", "۱۸۱", "۱۸۲", "۱۸۳", "۱۸۴", "۱۸۵", "۱۸۶", "۱۸۷", "۱۸۸", "۱۸۹", "۱۹۰", "۱۹۱", "۱۹۲", "۱۹۳", "۱۹۴", "۱۹۵", "۱۹۶", "۱۹۷", "۱۹۸", "۱۹۹", "۲۰۰", "۲۰۱", "۲۰۲", "۲۰۳", "۲۰۴", "۲۰۵", "۲۰۶", "۲۰۷", "۲۰۸", "۲۰۹", "۲۱۰", "۲۱۱", "۲۱۲", "۲۱۳", "۲۱۴", "۲۱۵", "۲۱۶", "۲۱۷", "۲۱۸", "۲۱۹", "۲۲۰", "۲۲۱", "۲۲۲", "۲۲۳", "۲۲۴", "۲۲۵", "۲۲۶", "۲۲۷", "۲۲۸", "۲۲۹", "۲۳۰", "۲۳۱", "۲۳۲", "۲۳۳", "۲۳۴", "۲۳۵", "۲۳۶", "۲۳۷", "۲۳۸", "۲۳۹", "۲۴۰", "۲۴۱", "۲۴۲", "۲۴۳", "۲۴۴", "۲۴۵", "۲۴۶", "۲۴۷", "۲۴۸", "۲۴۹", "۲۵۰", "۲۵۱", "۲۵۲", "۲۵۳", "۲۵۴", "۲۵۵", "۲۵۶", "۲۵۷", "۲۵۸", "۲۵۹", "۲۶۰", "۲۶۱", "۲۶۲", "۲۶۳", "۲۶۴", "۲۶۵", "۲۶۶", "۲۶۷", "۲۶۸", "۲۶۹", "۲۷۰", "۲۷۱", "۲۷۲", "۲۷۳", "۲۷۴", "۲۷۵", "۲۷۶", "۲۷۷", "۲۷۸", "۲۷۹", "۲۸۰", "۲۸۱", "۲۸۲", "۲۸۳", "۲۸۴", "۲۸۵", "۲۸۶"]; // these digits are to count the numbers of surah's (1..114) and verses (1..286) in Persian


/* ---------------------------------------------------------- */
/* script for transional effects of the loading page at the application startup */


setTimeout(function(){
	//$('#initialLoadingText').hasClass('glow') ? $('#initialLoadingText').removeClass('glow') : $('#initialLoadingText').addClass('glow');
	$('#initialLoadingText').addClass('glow');	// starts at t=0.1 sec
}, 1000);
		
setTimeout(function(){
	$('#initialLoadingText2').fadeIn("slow");	// starts at t=1 sec, its duration is slow/ .fadeIn(1000);
}, 1000);
		
setTimeout(function(){
	$('#initialLoadingText3').fadeIn("slow");	// starts at t=3 sec, its duration is slow/ .fadeIn(1000);
}, 3000);
		
setTimeout(function(){
	$("#loading").fadeOut("slow");	// starts at t=6 sec, its duration is slow/ or use .fadeOut(2000);
}, 6000);
	
setTimeout(function(){
	$('#main').fadeIn("slow");		// starts at t=6 sec, its duration is slow/ or use .fadeIn(3500);
}, 6000);