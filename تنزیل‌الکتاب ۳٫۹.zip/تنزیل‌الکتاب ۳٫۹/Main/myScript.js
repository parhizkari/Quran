//=============  DEFINE THE VARIABLES  ==============//


/* all the foreign data are saved in the single datbase bundle "DB", which, in short, has the following data structure

var DB={
	"QuranNoor":		{"1:1":{}, ...}									originally from Noor database (modified a lot), revised & completed with the aid of all the other databases
	"rootsList":		{"key":"expla.", ...}							originally from Noor database (modified a lot), then updated by  Alfanous database
	"nathreTubaDict":	{"key":"expla.", ...}							originally from NathreTuba book (modified almost a lot before to prepare it as an HTML file)
	"faAnsarian":		{"1:1":"به نام خداوند ...", ...}							originally from Tanzil's database
		.
		.
		.
	"enYusufali":		{"1:1":"In the name of Allah ...", ...}			originally from Tanzil's database
	"alBurhanTrans":
	"surahInfo":														originally from Tanzil's database
	"licenseTanzil":	"..."											originally from Tanzil's database	
}
					
DB["QuranNoor"][surahNum:verseNum][wordCounter]={
	"w":	word														originally from Noor database (modified a lot), validated and modified using Tanzil's scripts
	"sw":	subWords Combination										originally from Noor database (almost not modified)
	"r":	root(s)  (a string)											originally from Noor database (modified a lot), then updated by  Alfanous database
	"wr":	role of the word in the sentence, noun, verb, etc.			originally from Alfanous database
	"sy":	synonymes (a string) 										originally from Alfanous database
	"m":	word Meaning and explantions								originally from Salam Dictionary
	//"sr":	Same-Root Words, with examples and meanings					originally from NathreTuba Dictionary
}

*/


var	QuranDiv=document.getElementById("Quran"),
	TafseerDiv=document.getElementById("Tafseer");

var enSearchWhere=DB["QuranNoor"],		faSearchWhere="متن قرآن",
	lastRootSelected="",
	firstVerse, lastVerse;


document.getElementById("searchWhere").value=faSearchWhere;

var stateConfig={
	"quran":[1, 1, 0, 0, 10],		// [SurahNumber, VerseNumber, scrollTop for Quran, scrollTop for Tafseer, selectNumVerseShown]
	"shownItemsInQuranDiv":["verseContent","faMojtabaviTransContent","commentsContent"],	// what to be shown the next time by default
	"comments":{}
};
// let add to "stateConfig.comments" a default comment for each Quran verse
for(var verse in DB["QuranNoor"]){
	stateConfig.comments[verse]="";
}




//=============  USE localStorage OF HTML5 TO RELOAD DATA FROM CACHE AT START  ==============//


if (window.localStorage["savedInCahe"]) {
	stateConfig = JSON.parse(window.localStorage["savedInCahe"]);	//retrieves the data from the browser's cache
}




//=============  DEFINE AND SET THE MAIN VARIABLES, WITH "stateConfig" UPDATED FROM WEB CACHE, OR JUST DEFINED ABOVE  ==============//


var	surahNumber=stateConfig.quran[0],
	verseNumber=stateConfig.quran[1],
	tempVerseNumber=verseNumber,
	tempQuranDivscrollTop=stateConfig.quran[2],
	tempTafseerDivscrollTop=stateConfig.quran[3],
	selectNumVerseShown=stateConfig.quran[4],
	shownItemsInQuranDiv=[];





//=============  USE localStorage OF HTML5 TO AUTOMATE SAVING OF DATA IN CACHE ==============//



function saveToCache(){
	window.localStorage["savedInCahe"] = JSON.stringify(stateConfig);	// stores the data to the browser's cache
}




//=================  TRANSFORM NUMBERS TO PERSIAN/ENGLISH  ==================



function toFa(textContainingEnglishNumbers){
	return textContainingEnglishNumbers.toString()
		.replace(/0/g,'۰').replace(/1/g,'۱').replace(/2/g,'۲').replace(/3/g,'۳').replace(/4/g,'۴')
		.replace(/5/g,'۵').replace(/6/g,'۶').replace(/7/g,'۷').replace(/8/g,'۸').replace(/9/g,'۹');
}
function toEn(persianNumbers){
	return persianNumbers.toString()
		.replace(/۰/g,'0').replace(/۱/g,'1').replace(/۲/g,'2').replace(/۳/g,'3').replace(/۴/g,'4')
		.replace(/۵/g,'5').replace(/۶/g,'6').replace(/۷/g,'7').replace(/۸/g,'8').replace(/۹/g,'9');
}
//alert(toFa("53 is 53 and not 78 !"));
//alert(toEn("۴۵")+2);




//=============  FIND THE PRESENT DATE IN THE PERSIAN CALENDAR  ==============//



function gregorian_to_jalali(gy,gm,gd){
	g_d_m=[0,31,59,90,120,151,181,212,243,273,304,334];
	jy=(gy<=1600)?0:979;
	gy-=(gy<=1600)?621:1600;
	gy2=(gm>2)?(gy+1):gy;
	days=(365*gy) +(parseInt((gy2+3)/4)) -(parseInt((gy2+99)/100)) +(parseInt((gy2+399)/400)) -80 +gd +g_d_m[gm-1];
	jy+=33*(parseInt(days/12053)); 
	days%=12053;
	jy+=4*(parseInt(days/1461));
	days%=1461;
	jy+=parseInt((days-1)/365);
 	if(days > 365)days=(days-1)%365;
	jm=(days < 186)?1+parseInt(days/31):7+parseInt((days-186)/30);
	jd=1+((days < 186)?(days%31):((days-186)%30));
	return [jy,jm,jd];
};
var persianMonth=["","فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"];
var morningAfternnon;
function persianDateTime(){
	d=new Date();
	g_y=d.getFullYear();
	g_m=d.getMonth()+1;
	g_d=d.getDate();
	shamsi=gregorian_to_jalali(g_y,g_m,g_d);
	H=d.getHours();
	//H=(H<10)?"0"+H:H;
	morningAfternnon= 
		(H==12)  ? "ظهر" : (
			(H!=0) ? (
				(H<12) ? "صبح" : (
					(H>=20) ? "شب" :  "بعد از ظهر"
				)
			)
			: "نیمه‌شب"
		);
		
	i = d.getMinutes();
	i = (i<10) ? "0"+i : i;
	var shortDate=shamsi[0]+"٫"+shamsi[1]+"٫"+shamsi[2]+" - "+H+":"+i;
	
	shortDate=toFa(shortDate.toString());
	
	return shortDate;
}; // now you can use the present date by calling the function  persianDateTime()




//========== TO GENERATE THE MENUS FROM WHICH SURAHS AND VERSES ARE SELECTED, & OTHER MENUS ==========//
// === MENUS



var	optionsSurahList="", optionsVerseList="", optionsRootsList="";

for(var i=1; i<=114; i++){
	var surahInfoSimplified=toFa(i)+'. '+DB["surahInfo"][i]["nameAr"]+' ('+DB["surahInfo"][i]["revealedAr"]+')';
	optionsSurahList +=	'<a>'
							+surahInfoSimplified.replace(/[ًٌٍَُِّْ\u0670]/g, "").replace(/[ي]/g, "ی").replace(/[أإ]/g, "ا").replace(/[ك]/g,"ک");  // \u0670 :الف مقصوره
						+'</a>';
}
for(var i in DB["rootsList"]){
	optionsRootsList +=	'<a>'+i+'</a>';
}
//console.log(optionsRootsList);

document.getElementById("surahNameListDropdown").innerHTML=optionsSurahList;
document.getElementById("surahNameList").value=document.getElementById("surahNameListDropdown").childNodes[surahNumber-1].text;
document.getElementById("verseNumberList").value=toFa(verseNumber);
document.getElementById("rootsListDropdown").innerHTML=optionsRootsList;


ComboBox = function(object_name){
	// Edit element cache 
	this.edit = document.getElementById(object_name);
	// Items Container 
	var ddl = document.getElementById(object_name).parentNode.getElementsByTagName('DIV');
	this.dropdownlist = ddl[0];
	// Current Item
	this.currentitem = null;
	// Current Item Index
	this.currentitemindex = null;
	// Visible Items Count
	this.visiblecount = 0;
	// Closure Object 
	var parobject = this;   
	// Picker
	//var pick = document.getElementById(object_name).parentNode.getElementsByTagName('SPAN');
	//pick[0].onclick =function () {
	//	parobject.edit.focus();
	//};
	// when input value is changed by typing (even if combined with mouseClick or with going Up&Down and pressing Enter?)
	this.edit.onchange = function () {
		if(object_name=="surahNameList"){
			//inputSurahName(parobject.edit.value);
			//document.getElementById("surahNameList").blur();
		}else if(object_name=="verseNumberList"){
			inputVerseNumber(parobject.edit.value);
			document.getElementById("verseNumberList").blur();
		}else if(object_name=="rootsList"){
			//console.log(0);
			selectRoot(parobject.edit.value);
			document.getElementById("rootsList").blur();
		}else if(object_name=="searchWhere"){
			//selectWhereToSearch(parobject.edit.value);
			//document.getElementById("searchWhere").blur();
		}
	};
	// Show Items when edit get focus
	this.edit.onfocus = function () {
		parobject.edit.value='';
		
		parobject.dropdownlist.style.display = 'block';
		for (var i=0, l=parobject.listitems.length; i<l; i++) {
			parobject.listitems[i].style.display = 'block';
			parobject.listitems[i].innerHTML =  parobject.listitems[i].innerHTML.replace(/\<span style\=\"color:crimson;\"\>/g, '').replace(/\<\/span\>/g, '');
		}
	};
	// Hide Items when edit lost focus
	this.edit.onblur = function () {
		if(object_name=="surahNameList"){
			parobject.edit.value=document.getElementById("surahNameListDropdown").childNodes[surahNumber-1].text;
		}else if(object_name=="verseNumberList"){
			parobject.edit.value=toFa(verseNumber);
		}else if(object_name=="rootsList"){
			parobject.edit.value=lastRootSelected;
		}else if(object_name=="searchWhere"){
			parobject.edit.value=faSearchWhere;
		}
		if(allowLoose)	setTimeout(function(){parobject.dropdownlist.style.display = 'none';}, 150);
	};
	var allowLoose=true;
	// IE fix
	parobject.dropdownlist.onmousedown = function(event) {
		allowLoose = false;
		return false;
	}
	parobject.dropdownlist.onmouseup = function(event) {
		setTimeout(function () {allowLoose = true;}, 150);
    	return false;
	}
	// Get Items
	this.listitems = this.dropdownlist.getElementsByTagName('A');
	for (var i=0; i < this.listitems.length; i++) {
		var t = i;
		// Binding Click Event
		this.listitems[i].onclick = function () {
			var upv = parobject.currentitem.innerHTML.replace(/\<span style\=\"color:crimson;\"\>/g, '').replace(/\<\/span\>/g, '');
			parobject.edit.value = upv;
			parobject.dropdownlist.style.display = 'none';
			if(object_name=="surahNameList"){
				inputSurahName(upv);
				document.getElementById("surahNameList").blur();
			}else if(object_name=="verseNumberList"){
				inputVerseNumber(upv);
				document.getElementById("verseNumberList").blur();
			}else if(object_name=="rootsList"){
				selectRoot(upv);
				document.getElementById("rootsList").blur();
			}else if(object_name=="searchWhere"){
				selectWhereToSearch(upv);
				document.getElementById("searchWhere").blur();
			}
			return false;
		}
		// Binding OnMouseOver Event
		this.listitems[i].onmouseover = function (e) {
			for (var i=0;i < parobject.listitems.length; i++) {
				if (this == parobject.listitems[i]) {
					if (parobject.currentitem) {
						parobject.currentitem.className = parobject.currentitem.className.replace(/light/g, '')
					}
					parobject.currentitem = parobject.listitems[i];
					parobject.currentitemindex = i;
					parobject.currentitem.className += ' light';
				}
			}
		}
	};
	// Binding OnKeyDown Event
	this.edit.onkeydown = function (e) {
		e = e || window.event;	
		// Move Selection Up
		if (e.keyCode == 38) {
			// up
			var cn =0;
			if (parobject.visiblecount > 0) {
				if (parobject.visiblecount == 1) {
					parobject.currentitemindex = parobject.listitems.length-1;
				};
				do {
					parobject.currentitemindex--;
					cn++;
				} 
				while (parobject.currentitemindex>0 && parobject.listitems[parobject.currentitemindex].style.display == 'none');
				if(parobject.currentitemindex < 0) parobject.currentitemindex = parobject.listitems.length-1;
				
				if (parobject.currentitem) {
					parobject.currentitem.className = parobject.currentitem.className.replace(/light/g, '')
				};
				parobject.currentitem = parobject.listitems[parobject.currentitemindex];
				parobject.currentitem.className += ' light';
				parobject.currentitem.scrollIntoView(false);
				//parobject.edit.value = parobject.currentitem.innerHTML.replace(/\<span style\=\"color:crimson;\"\>/g, '').replace(/\<\/span\>/g, '');
			};
			e.cancelBubble = true;
			if (navigator.appName != 'Microsoft Internet Explorer')	{
				e.preventDefault();
				e.stopPropagation();
			}
			return false;
		}
		// Move Selection Down
		else if (e.keyCode == 40){
			// down
			var ic=0;
			if (parobject.visiblecount > 0) {
				do {
					parobject.currentitemindex++;
				}
				while (parobject.currentitemindex < parobject.listitems.length && parobject.listitems[parobject.currentitemindex].style.display == 'none');
				if(parobject.currentitemindex >= parobject.listitems.length) parobject.currentitemindex = 0;
				
				if (parobject.currentitem) {
					parobject.currentitem.className = parobject.currentitem.className.replace(/light/g, '')
				}
				parobject.currentitem = parobject.listitems[parobject.currentitemindex];
				parobject.currentitem.className += ' light';
				parobject.currentitem.scrollIntoView(false);
				//parobject.edit.value = parobject.currentitem.innerHTML.replace(/\<span style\=\"color:crimson;\"\>/g, '').replace(/\<\/span\>/g, '');
			}
			e.cancelBubble = true;
			if (navigator.appName != 'Microsoft Internet Explorer')	{
				e.preventDefault();
				e.stopPropagation();
			}
			return false;
		}
		
	};
	this.edit.onkeyup = function (e) {
		e = e || window.event;
		
		if(object_name=="rootsList") parobject.edit.value=parobject.edit.value
									.replace(/[اآأإئؤ]/g,"ء").replace(/[ًٌٍَُِّْ]/g,"")
									.replace(/([^\.])(?<=)([^\.])(?!$.)/g,"$1.$2");	// to put a dot between each two characters, if there is no dot input
		
		if (e.keyCode == 13) {
			// enter
			if (parobject.visiblecount != 0) {
				var upv = parobject.currentitem.innerHTML.replace(/\<span style\=\"color:crimson;\"\>/g, '').replace(/\<\/span\>/g, '');
				parobject.edit.value = upv;
				//alert(upv);
				if(object_name=="surahNameList"){
					inputSurahName(upv);
					document.getElementById("surahNameList").blur();
				}else if(object_name=="verseNumberList"){
					inputVerseNumber(upv);
					document.getElementById("verseNumberList").blur();
				}else if(object_name=="rootsList"){
					selectRoot(upv);
					document.getElementById("rootsList").blur();
				}else if(object_name=="searchWhere"){
					selectWhereToSearch(upv);
					document.getElementById("searchWhere").blur();
				}
			};
			parobject.dropdownlist.style.display = 'none';
			e.cancelBubble = true;
			return false;
		} else {
			parobject.dropdownlist.style.display = 'block';
			parobject.visiblecount = 0;
			if (parobject.edit.value == '') {
				for (var i=0;i < parobject.listitems.length; i++) {
					parobject.listitems[i].style.display = 'block';
					parobject.visiblecount++;
					parobject.listitems[i].innerHTML =  parobject.listitems[i].innerHTML.replace(/\<span style\=\"color:crimson;\"\>/g, '').replace(/\<\/span\>/g, '');
				}
			}
			else {
				var re;
				//if(object_name=="rootsList"){
				//	re = new RegExp( '('+toFa(parobject.edit.value).replace(/\(/g,"\\(").replace(/\)/g,"\\)").replace(/ی/g, "ي").replace(/ا/g, "ء").replace(/ک/g,"ك") +')',"ig");
				//}else{
					re = new RegExp( '('+toFa(parobject.edit.value).replace(/\(/g,"\\(").replace(/\)/g,"\\)") +')',"ig");
				//}
				//alert(re);
				for (var i=0; i<parobject.listitems.length; i++) {
					var pv = parobject.listitems[i].innerHTML.replace(/\<span style\=\"color:crimson;\"\>/g, '').replace(/\<\/span\>/g, '');
							//.replace(/\(/g, '').replace(/\)/g, '');
					
					if ( re.test(pv) ) {
						parobject.listitems[i].style.display = 'block';
						parobject.visiblecount++;
						parobject.listitems[i].innerHTML = pv.replace(re, '<span style="color:crimson;">$1</span>');
					}
					else {
						parobject.listitems[i].style.display = 'none';
					}
				}
			}
		}
	}
}
var no = new ComboBox('surahNameList');		//activate the combobox corresponding to the list of surah names, once is enough as the list is static
var no = new ComboBox('verseNumberList');	//activate the combobox corresponding to the list of verses number in the selected surah, once is "not" enough as the list is not static
var no = new ComboBox('searchWhere');		//activate the combobox corresponding to the list of books to search within ..., once is enough as the list is static
var no = new ComboBox('rootsList');			//activate the combobox corresponding to the list of roots of Quranic Words in the search page ..., once is enough as the list is static

function inputSurahName(nu){
	var surahNumberInput=toEn(nu).toString().replace(/(\d+).*/,"$1");
    if(Number(surahNumberInput)>=1 && Number(surahNumberInput)<=114){
		stateConfig.quran[0]=surahNumber=surahNumberInput;
		stateConfig.quran[1]=verseNumber=1;
		QuranDiv.scrollTop=stateConfig.quran[2]=0;
		TafseerDiv.scrollTop=stateConfig.quran[3]=0;
		saveToCache();
		
		document.getElementById("surahNameList").value=document.getElementById("surahNameListDropdown").childNodes[surahNumber-1].text;
		document.getElementById("verseNumberList").value="۱";
		
		TafseerDiv.innerHTML=DB["alBurhanTrans"][surahNumber][0]["content"];
		
		optionsVerseList="";
		for(var i=1, l=Number(DB["surahInfo"][surahNumber]["numVerse"]); i<=l; i++){
			optionsVerseList += '<a>'+toFa(i)+'</a>';
		}
		document.getElementById("verseNumberListDropdown").innerHTML=optionsVerseList;
		var no = new ComboBox('verseNumberList');	//activate again the combobox corresponding to the new list of verses number
	
		
		jumptoSurahVerse();
	}else{
		alert("در این نرم‌افزار سوره از روی شماره‌ی آن انتخاب می‌گردد، لطفاً یا شماره‌ی درست سوره را به صورت \"*.\" در ابتدای ورودی خود وارد نمایید و یا سوره‌ی مورد نظر خود را از داخل فهرست کمکی انتخاب نمایید.");
	}
}
function inputVerseNumber(nu){
	if(Number(toEn(nu))>=1 && Number(toEn(nu))<=DB["surahInfo"][surahNumber]["numVerse"]){	
		verseNumber=toEn(nu);	stateConfig.quran[1]=verseNumber;	saveToCache();
		document.getElementById("verseNumberList").value=toFa(verseNumber);
		
		jumptoSurahVerse();
	}else{
		alert("شماره‌ی وارد شده در محدوده‌ی مجاز انتخاب آیه‌ها نمی‌باشد، لطفاً ورودی خود را تصحیح نمایید.");
	}
}




//=== TO SHOW/HIDE DIFFERENT ELEMENTS IN QURANDIV



var allShown=1, el;
function showOrNotShow(name){
	if(name=="ALL"){
		var els=document.querySelectorAll('[class$="Content"]');
		if(allShown){
			for(var i=0, l=els.length; i<l; i++){
				els[i].style.display="";
				
				el=document.getElementById(    els[i].className.toString().replace(/verseTranslationContent /,"").replace(/Content/,"")    );
				if(el.innerHTML.indexOf("✓")==-1)  el.innerHTML+=" <span style='display:inline; color:green;'>✓</span>";
				
			}
			shownItemsInQuranDiv=["verseContent","faAnsarianTransContent","faAyatiTransContent","faBahrampourTransContent",
									"faKhorramdelTransContent","faKhorramshahiTransContent","faFooladvandTransContent",
									"faGharaatiTransContent","faGhomsheiTransContent","faMakaremTransContent","faMojtabaviTransContent",
									"faMoezziTransContent","enSahihTransContent","enYusufaliTransContent","commentsContent"];
			allShown=0;
		}else{
			for(var i=0, l=els.length; i<l; i++){
				els[i].style.display="none";
				
				el=document.getElementById(    els[i].className.toString().replace(/verseTranslationContent /,"").replace(/Content/,"")     );
				if(el.innerHTML.indexOf("✓")!=-1)  el.innerHTML=el.innerHTML.replace(/ \<span style=\"display:inline; color:green;\"\>✓\<\/span\>/,"");
			}
			shownItemsInQuranDiv=[];
			allShown=1;
		}
	}else{
		var els=document.querySelectorAll('[class$="'+name+'Content"]');
		for(var i=0, l=els.length; i<l; i++){
			if(els[i].style.display=="none"){
				els[i].style.display="";
				
				el=document.getElementById(  name  );
				if(el.innerHTML.indexOf("✓")==-1)  el.innerHTML+=" <span style='display:inline; color:green;'>✓</span>";
				
				if(shownItemsInQuranDiv.indexOf(name+"Content") == -1){
					shownItemsInQuranDiv.push(name+"Content");
				}
			}else{
				els[i].style.display="none";
				
				el=document.getElementById(    name    );
				if(el.innerHTML.indexOf("✓")!=-1)  el.innerHTML=el.innerHTML.replace(/ \<span style=\"display:inline; color:green;\"\>✓\<\/span\>/,"");
				
				shownItemsInQuranDiv=shownItemsInQuranDiv.filter(function(e) { return e !== name+"Content"; });
			}
		}
	}
	stateConfig.shownItemsInQuranDiv=shownItemsInQuranDiv;
	saveToCache();
}




//======== FILL THE PAGE WITH VERSES (AND THEIR TRANSLATIONS ANS COMMENTS) WHICH LIE IN THE RANGE =======//



function jumptoSurahVerse(){
	// first let determine from which verses to begin and end on the page shown
	detFirstANDLastVerShown();
	
	
	// to handle the buttons for navigating to the previous page
	document.getElementById("prevPageButton").style.display='initial';
	if(firstVerse==1 && surahNumber==1){
		document.getElementById("prevPageButton").style.display='none';
	}else if(firstVerse==1){
		document.getElementById("prevPageButton").title="سوره‌ی قبل: "+DB["surahInfo"][Number(surahNumber)-1]["nameAr"]+" (↑+Ctrl)";
	}else if(firstVerse <= Number(selectNumVerseShown)){
		document.getElementById("prevPageButton").title="ابتدای سوره (↑+Ctrl)";
	}else{
		document.getElementById("prevPageButton").title="صفحه‌ی قبل (↑+Ctrl)";
	}
	// to handle the buttons for navigating to the next page
	document.getElementById("nextPageButton").style.display='initial';
	if(lastVerse==6 && surahNumber==114){
		document.getElementById("nextPageButton").style.display='none';
	}else if(lastVerse==DB["surahInfo"][surahNumber]["numVerse"]){
		document.getElementById("nextPageButton").title="سوره‌ی بعد: "+DB["surahInfo"][Number(surahNumber)+1]["nameAr"]+" (↓+Ctrl)";
	}else{
		document.getElementById("nextPageButton").title="صفحه‌ی بعد (↓+Ctrl)";
	}
	
	
	//now fill the QuranDivTable
	var QuranDivTableContent="", verseNumEn, verseNumFa,
		w, wExtraData, wExtraDataTemp, rootListPerWord, expln, explnTimer=null;
		quranVerseContentShown="";
		
	for(var verse in DB["QuranNoor"]){
		var sNumber=verse.replace(/(\d+)\:(\d+)/,"$1"),
			vNumber=verse.replace(/(\d+)\:(\d+)/,"$2");
		if(sNumber==surahNumber   &&   vNumber>=firstVerse   &&   vNumber<=lastVerse){	
			verseNumEn=vNumber;
			verseNumFa=' (<span class="verseNumbering">'+toFa(verseNumEn)+'</span>)';
			
			quranVerseContentShown="";
			for(var j=0, l=DB["QuranNoor"][verse].length; j<l; j++){
				w=DB["QuranNoor"][verse][j]["w"];
				
				wExtraData="<span class='w'>"+w+"</span> ";
				wExtraData+=(DB["QuranNoor"][verse][j]["wr"]!="")?	"<div class='wr'>("+DB["QuranNoor"][verse][j]["wr"]+") </div>"	:	" ";
				wExtraData+=(DB["QuranNoor"][verse][j]["r"]!="")?	"<div class='r'>[از ریشه‌ی «"+DB["QuranNoor"][verse][j]["r"]+"»] </div>"	:	" ";
				wExtraData+=": ";
				wExtraData+=(DB["QuranNoor"][verse][j]["sw"]!="")?	"<div class='sw'>"+DB["QuranNoor"][verse][j]["sw"]+"</div>"	:	"";
				wExtraData+=(DB["QuranNoor"][verse][j]["sy"]!="")?	"<br style='margin-bottom:30px;'>👪 هم‌خانواده‌های معنایی:<span class='sy'>"+DB["QuranNoor"][verse][j]["sy"]+"</span>"	:	"";
				wExtraData+=(DB["QuranNoor"][verse][j]["m"]!="")?	"<br style='margin-bottom:30px;'>📔 معنا: <span class='m'>"+toFa(DB["QuranNoor"][verse][j]["m"])+"</span>"	:	"";
				
				wExtraDataTemp=wExtraData;
				wExtraData+="<br style='margin-bottom:30px;'>🌳 برخی کلمات هم‌ریشه:";
				rootListPerWord=DB["QuranNoor"][verse][j]["r"].split("/");
				for(var k=0, len=rootListPerWord.length; k<l; k++){
					if(DB["nathreTubaDict"][rootListPerWord[k]]!=undefined){
						wExtraData+= "<br><div class='r'>"+rootListPerWord[k]+"</div><div class='sr'>"+ DB["nathreTubaDict"][rootListPerWord[k]] +"</div>";
					}
				}
				if(wExtraData == wExtraDataTemp+"<br style='margin-bottom:30px;'>🌳 برخی کلمات هم‌ریشه:")	wExtraData=wExtraDataTemp;
				
				quranVerseContentShown+='<span class="wInVerse" onmouseover="expln=document.getElementById(\'expln-'+verse+'-'+j+'\'); positionExpln(this,expln);" onmouseout="hideExpln(expln);">'
											+ w +'<div id="expln-'+verse+'-'+j+'" class="wExtraData">'+wExtraData+'</div>'
										+'</span> ';
				
				
				
			}
			
			QuranDivTableContent+=
				'<tr id="['+verse+']">'
					+'<td class="verseTableCell" ondblclick="inputVerseNumber('+verseNumEn+');">'
						+'<div class="verseContent">'
							+quranVerseContentShown
							+verseNumFa
						+'</div>'
						+'<ul>'
							+'<li class="verseTranslationContent faAnsarianTransContent" title="ترجمه‌ی انصاریان" >'
								+DB["faAnsarian"][verse]
								+verseNumFa
							+'</li>'
							+'<li class="verseTranslationContent faAyatiTransContent" title="ترجمه‌ی آیتی">'
								+DB["faAyati"][verse]
								+verseNumFa
							+'</li>'
							+'<li class="verseTranslationContent faBahrampourTransContent" title="ترجمه‌ی بهرام‌پور">'
								+DB["faBahrampour"][verse]
								+verseNumFa
							+'</li>'
							+'<li class="verseTranslationContent faKhorramdelTransContent" title="ترجمه‌ی خرّمدل">'
								+toFa(DB["faKhorramdel"][verse])
								+verseNumFa
							+'</li>'
							+'<li class="verseTranslationContent faKhorramshahiTransContent" title="ترجمه‌ی خرّمشاهی">'
								+DB["faKhorramshahi"][verse]
								+verseNumFa
							+'</li>'
							+'<li class="verseTranslationContent faFooladvandTransContent" title="ترجمه‌ی فولادوند">'
								+DB["faFooladvand"][verse]
								+verseNumFa
							+'</li>'
							+'<li class="verseTranslationContent faGharaatiTransContent" title="ترجمه‌ی قرائتی">'
								+DB["faGharaati"][verse]
								+verseNumFa
							+'</li>'
							+'<li class="verseTranslationContent faGhomsheiTransContent" title="ترجمه‌ی قمشه‌ای">'
								+DB["faGhomshei"][verse]
								+verseNumFa
								+'</li>'
							+'<li class="verseTranslationContent faMakaremTransContent" title="ترجمه‌ی مکارم">'
								+DB["faMakarem"][verse]
								+verseNumFa
							+'</li>'
							+'<li class="verseTranslationContent faMojtabaviTransContent" title="ترجمه‌ی مجتبوی">'
								+DB["faMojtabavi"][verse]
								+verseNumFa
							+'</li>'
							+'<li class="verseTranslationContent faMoezziTransContent" title="ترجمه‌ی معزی">'
								+DB["faMoezzi"][verse]
								+verseNumFa
							+'</li>'
							+'<li class="verseTranslationContent enSahihTransContent" title="Sahih International Translation" dir="ltr">'
								+DB["enSahih"][verse]
								+toEn(verseNumFa)
							+'</li>'
							+'<li class="verseTranslationContent enYusufaliTransContent" title="Yusuf Ali\'s Translation" dir="ltr">'
								+DB["enYusufali"][verse]
								+toEn(verseNumFa)
							+'</li>'
						+'</ul>'
					+'</td>'
					+'<td class="commentsContent">'
						+'<textarea  style="display:none;" id="commentsTextarea'+verseNumEn+'"  placeholder="✍" '
								+'onkeyup="saveComment('+verseNumEn+',this.value);" '
								+'onblur="commentsTextareaOnBlur('+verseNumEn+',this.value);">'
							+stateConfig.comments[verse]
						+'</textarea>'
						+'<div id="commentsOutput'+verseNumEn+'" ondblclick="commentsTextareaActivate('+verseNumEn+');" style="cursor:pointer;"></div>'
					+'</td>'
				+'</tr>';
		}
	}
	
	document.getElementById("QuranDivTable").innerHTML=QuranDivTableContent;
	
	
	var commentsContentOnThePage=document.getElementsByClassName("commentsContent");
	for(var i=0, l=commentsContentOnThePage.length; i<l; i++){
		compile(commentsContentOnThePage[i].children[1], commentsContentOnThePage[i].children[0].value);
	}
	
	
	
	var notShownChildren,	//	,	commentsShown=(shownItemsInQuranDiv.indexOf("commentsContent")!=-1)? 1 : 0;
			allitemsShowable=["verseContent","faAnsarianTransContent","faAyatiTransContent","faBahrampourTransContent",
									"faKhorramdelTransContent","faKhorramshahiTransContent","faFooladvandTransContent",
									"faGharaatiTransContent","faGhomsheiTransContent","faMakaremTransContent","faMojtabaviTransContent",
									"faMoezziTransContent","enSahihTransContent","enYusufaliTransContent","commentsContent"];
	for(var i=0, l=allitemsShowable.length; i<l; i++){
		if(shownItemsInQuranDiv.indexOf(allitemsShowable[i])==-1){
			notShownChildren=document.getElementsByClassName( allitemsShowable[i] );
			for(var j=0, ll=notShownChildren.length; j<ll; j++){
				notShownChildren[j].style.display="none";
				
				el=document.getElementById(    allitemsShowable[i].replace(/Content/,"")    );
				if(el.innerHTML.indexOf("✓")!=-1)  el.innerHTML=el.innerHTML.replace(/ \<span style=\"display:inline; color:green;\"\>✓\<\/span\>/,"");
			}
		}
	}
	
	
	
	if(verseNumber!=1){
		document.getElementById ("["+surahNumber+':'+verseNumber+"]").scrollIntoView(true);
	}else{
		QuranDiv.scrollTop=0;
	}
}


function detFirstANDLastVerShown(){
	//document.getElementById("selectNumVerseShown").value=selectNumVerseShown;
	var numVersesShownBeforeMainVerse={1:0, 5:1, 10:2, 20:4, 50:5, 100:5};
	
	
	if(selectNumVerseShown=="ALL"){
		firstVerse=1;
		lastVerse=Number(DB["surahInfo"][surahNumber]["numVerse"]);
	}else{
		if(Number(verseNumber) > numVersesShownBeforeMainVerse[selectNumVerseShown]){
			firstVerse=Number(verseNumber) - numVersesShownBeforeMainVerse[selectNumVerseShown];
		}else{
			firstVerse=1;
		}
		lastVerse= Number(verseNumber) + Number(selectNumVerseShown) - 1;
		if(Number(lastVerse) > Number(DB["surahInfo"][surahNumber]["numVerse"])){
			lastVerse=Number(DB["surahInfo"][surahNumber]["numVerse"]);
		}
	}
}

function positionExpln(div,el){
	explnTimer=setTimeout(function(){
		el.style.display='block';
		
		var divRect=div.getBoundingClientRect(), t=divRect.top, l=divRect.left, r=divRect.right, b=divRect.bottom, w=divRect.width, //h=divRect.height,
			elRect=el.getBoundingClientRect(), elw=elRect.width, //elh=elRect.height,
			H=innerHeight, W=window.innerWidth;
		
		if(t <= Math.floor(H/2) && l < Math.floor(W/3)){			// place el at  "bottomRight"  of div
			el.style.left = l+"px";
			el.style.top = b+"px";
		}else if(t <= Math.floor(H/2) && l > Math.floor(2*W/3)){	// place el at  "bottomLeft"  of div
			el.style.right = (W-r)+"px";
			el.style.top = b+"px";
		}else  if(t <= Math.floor(H/2)){							// place el at  "bottom"  of div
			el.style.left = (r - Math.floor((w+elw)/2))+"px";
			el.style.top = b+"px";
		}
		
		else if(t > Math.floor(H/2) && l < Math.floor(W/3)){		// place el at  "topRight"  of div
			el.style.left = l+"px";
			el.style.bottom = (H-t)+"px";
		}else if(t > Math.floor(H/2) && l > Math.floor(2*W/3)){		// place el at  "topLeft"  of div
			el.style.right = (W-r)+"px";
			el.style.bottom = (H-t)+"px";
		}else{														// place el at  "top"  of div
			el.style.left = (r - Math.floor((w+elw)/2))+"px";
			el.style.bottom = (H-t)+"px";
		}
	}, 1000);
}
function hideExpln(el){
	clearInterval(explnTimer);
	if(el.matches(':hover')){				// so if the user still hover over the "el", do not hide it!
		el.style.display='block';
	}else{
		setTimeout(function(){
			el.style.display='none';
		}, 200);
	}
}





//===================== FUNCTIONS TO SHOW AND JUMP TO PREVIOUS OR NEXT VERSES =======================//


function prevVerses(){
	if(firstVerse==1 && surahNumber==1){
		return false;
	}else if(firstVerse==1){
		surahNumber--;
		inputSurahName(surahNumber);
	}else if(firstVerse <= Number(selectNumVerseShown)){
		inputVerseNumber(1);
	}else{
		verseNumber-=Number(selectNumVerseShown);
		inputVerseNumber(verseNumber);
	}
}
function nextVerses(){
	if(lastVerse==6 && surahNumber==114){
		return false;
	}else if(lastVerse==DB["surahInfo"][surahNumber]["numVerse"]){
		surahNumber++;
		inputSurahName(surahNumber);
	}else{
		verseNumber=Number(lastVerse)+1;
		inputVerseNumber(verseNumber);
	}
}





//===================== COMMENTS MANIPULATION =======================//




function commentsTextareaOnBlur(v,txt){
	document.getElementById('commentsTextarea'+v).style.display="none";
	document.getElementById('commentsOutput'+v).style.display="block";
	
	compile(document.getElementById('commentsOutput'+v), txt);
	saveComment(v,txt);
}

function commentsTextareaActivate(v){
	document.getElementById('commentsOutput'+v).style.display="none";
	document.getElementById('commentsTextarea'+v).style.display="block";
	document.getElementById('commentsTextarea'+v).focus();
}

var inactivityPeriod;
function saveComment(v,txt){
	clearTimeout(inactivityPeriod);				// resets "inactivityPeriod" because a change has been captured
	inactivityPeriod = setTimeout(function() {	// Runs 1s (1000 ms) after the last change
		stateConfig.comments[surahNumber+":"+v]=txt;
		saveToCache();
		setTimeout(function() {
			document.getElementById('save-log').style.display = 'inline-block';	// Runs 1s (1000 ms) after the last change
		}, 1000);
		setTimeout(function() {
			document.getElementById('save-log').style.display = 'none';		// Runs 1s (1000 ms) after the last change
		}, 2000);
	}, 1000);
}

function refreshComments(){
	if(stateConfig){
		if(!confirm('با این کار تمام یادداشت‌های ذخیره‌نشده‌ی فعلی از دست می‌روند، آیا با این حال ادامه می‌دهید؟')){
			return false;
		}
	}
	// let re-assign to "stateConfig.comments" an empty default comment for each Quran verse
	for(var verse in DB["QuranNoor"]){
		stateConfig.comments[verse]="";
	}
	saveToCache();
	/*setTimeout(function() {
		document.getElementById('save-log').style.display = 'inline-block';	// Runs 1s (1000 ms) after the last change
	}, 1000);
	setTimeout(function() {
		document.getElementById('save-log').style.display = 'none';		// Runs 1s (1000 ms) after the last change
	}, 2000);*/
	
	var commentsShown=document.querySelectorAll("[id^='commentsOutput']");
	for(var i=0, l=commentsShown.length; i<l; i++){
		commentsShown[i].innerHTML="✍";
	}
}


function compile(obj,txt){
	if(txt.replace(/\s/g,"") == ""){
		obj.innerHTML="✍";
		return false;
	}
	
	var nestedListLevel=0;
	obj.innerHTML=txt.replace(/(\×\×)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<strong>$2</strong>")
			.replace(/(\×)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<em>$2</em>")
			.replace(/(\/ـ\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<u>$2</u>")
			.replace(/(\/-\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<s>$2</s>")
			
			.replace(/(\/ق\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:crimson'>$2</span>")
			.replace(/(\/آ\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:RoyalBlue;'>$2</span>")
			.replace(/(\/س\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:Olive;'>$2</span>")
			.replace(/(\/زرد\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='background-color:yellow;'>$2</span>")
			
			.replace(/(\(بسمله۱\))/g,"<span style='font-family:sardar;'>‌ا</span>")
			.replace(/(\(بسمله۲\))/g,"<span style='font-family:sardar;'>‌ب</span>")
			.replace(/(\(بسمله۳\))/g,"<span style='font-family:sardar;'>‌پ</span>")
			.replace(/(\(بسمله۴\))/g,"<span style='font-family:sardar;'>‌ت</span>")
			.replace(/(\(بسمله۵\))/g,"<span style='font-family:sardar;'>‌ث</span>")
			
			.replace(/(\(جل\))/g,"<span style='font-family:sardar'>ح</span>")
			.replace(/(\(ص\))/g,"<span style='font-family:sardar'>ج</span>")
			.replace(/(\(ص\-\))/g,"<span style='font-family:sardar'>ط</span>")
			.replace(/(\(علیه\))/g,"<span style='font-family:sardar'>خ</span>")
			.replace(/(\(علیها\))/g,"<span style='font-family:sardar'>د</span>")
			.replace(/(\(علیهما\))/g,"<span style='font-family:sardar'>ذ</span>")
			.replace(/(\(علیهم\))/g,"<span style='font-family:sardar'>ر</span>")
			.replace(/(\(عج\))/g,"<span style='font-family:sardar'>ظ</span>")
			.replace(/(\(عج\-\))/g,"<span style='font-family:sardar'>ی</span>")
			.replace(/(\(رحمه\))/g,"<span style='font-family:sardar'>ز</span>")
			.replace(/(\(رحمها\))/g,"<span style='font-family:sardar'>س</span>")
			.replace(/(\(رحمهما\))/g,"<span style='font-family:sardar'>ش</span>")
			.replace(/(\(رحمهم\))/g,"<span style='font-family:sardar'>ص</span>")
			
			.replace(/(\/قرآن\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-size:110%; color:darkGreen;'>$2</span>")
			.replace(/(\/حدیث\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:darkBlue;'>$2</span>")
			.replace(/(\/ترجمه\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:darkRed;'>$2</span>")
			
			.replace(/(\/ltr\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span dir='ltr'>$2</span>")
			.replace(/[ \t]*\n{0,1}(\/ltrp\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1\n{0,1}/g,"<p dir='ltr' style='text-align:justify;'>$2</p>")
			
			.replace(/(\/ن\/)[ \t\n]*([\S\s]*?)[ \t\n]*\1/g,"<blockquote>$2</blockquote>")
			
			.replace(/[ \t]*\n{0,1}(\/=.\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1\n{0,1}/g,"<p style='text-align:left; margin:0;'>$2</p>")
			.replace(/[ \t]*\n{0,1}(\/.=\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1\n{0,1}/g,"<p style='text-align:right; margin:0;'>$2</p>")
			.replace(/[ \t]*\n{0,1}(\/=.=\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1\n{0,1}/g,"<p style='text-align:center; margin:0;'>$2</p>")
			
			.replace(/[ \t]*(\/----\/)[ \t]*/g,"<hr>")
			.replace(/[ \t]*(\/====\/)[ \t]*/g,"<hr style='border:0px; border-top:5px double #8c8c8c;'>")
			
			
			
			// for capturing tables
			.replace(/(?:\/جدول.ش\*\/)(?:\[کلاس:[ \t]*(.*?)[ \t]*\])?/g, "<table class='$1'>")
			.replace(/(?:\/ردیف\/)[\t\n\r ]*(.*?)[\t\n\r ]*(?=\/ردیف\/|\/جدول\.پ\/|\r|\n|\t)/g,"<tr>$1</tr>")
			.replace(/(?:\|\|)([^\|\r\n\t]*)/g, "<td style='vertical-align:middle; text-align:center;'>$1</td>")
			.replace(/(?:\|ر\|)([^\|\r\n\t]*)/g, "<td style='vertical-align:middle; text-align:right'>$1</td>")
			.replace(/(?:\|ر.ب\|)([^\|\r\n\t]*)/g, "<td style=\"vertical-align:top; text-align:right;\">$1</td>")
			.replace(/(?:\|ر.پ\|)([^\|\r\n\t]*)/g, "<td style=\"vertical-align:bottom; text-align:right;\">$1</td>")
			.replace(/(?:\|چ\|)([^\|\r\n\t]*)/g, "<td style='vertical-align:middle; text-align:left'>$1</td>")
			.replace(/(?:\|چ.ب\|)([^\|\r\n\t]*)/g, "<td style=\"vertical-align:top; text-align:left;\">$1</td>")
			.replace(/(?:\|چ.پ\|)([^\|\r\n\t]*)/g, "<td style=\"vertical-align:bottom; text-align:left;\">$1</td>")
			.replace(/(?:\|ب\|)([^\|\r\n\t]*)/g, "<td style='vertical-align:top; text-align:center;'>$1</td>")
			.replace(/(?:\|پ\|)([^\|\r\n\t]*)/g, "<td style='vertical-align:bottom; text-align:center;'>$1</td>")
			.replace(/[ \t\n]*(?:\/جدول.پ\/)/g,"</table>")
			// for capturing new styles defined by the user, to be considered as lying in the header of the HTML file
			.replace(/(\/استایل\/)[ \t\n]*(?=\S)([^\r]*?\S[*_]*)[ \t\n]*\1/g,  function(x,y1,y2){
				var style = document.createElement('style');
				style.type = 'text/css';
				style.innerHTML = y2;
				document.getElementsByTagName('head')[0].appendChild(style);
				return "";		// if it was not added, an "undefined" text was written in its place!
			})
			
			
			
			.replace(/(?:\()[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*(?:\))/g,"(<span style='color:Olive'>$1</span>)")
			
			
			
			.replace(/(?:\s*\/پ([۰۱۲۳۴۵۶۷۸۹\d\-\+]+)(\%|\٪)?\/\s*)/g, function(x,y1,y2){
				var inEn=toEn(y1);
				var marginTop = (y2!=undefined)? inEn+"vh" : inEn+"px";
				return "<div style='display:block!important; margin-top:"+marginTop+";'></div>";
			})
			.replace(/(?:\s*\/ج([۰۱۲۳۴۵۶۷۸۹\d\-\+]+)\/\s*)/g, function(x,y){
				return " <span style='margin-right:"+toEn(y)+"px;'></span>";
			})
			.replace(/(?:\/ج\/)[ \t]*(.+)\n/g, function(x,y){
				var temp=1, yt=y, ytt="";
				while(temp){
					ytt=yt.replace(/(?:\/ج\/)[ \t]*(.+)/g, "<div style='position:relative; margin:0 40px 0 0;'>$1</div>");
					if(ytt==yt){temp=0;}
					yt=ytt;
				}
				return "<div style='position:relative; margin:0 40px 0 0;'>"+ytt+"</div>";
			})
			
			
			
			//for capturing links ...	   //use as   /لینک{متن}{http://www.address.com}[عنوان]
			.replace(/(?:\/لینک)(?:\{[ \t]*([^\}]*)[ \t]*\})[ \t]*(?:\{[ \t]*([^\}]*)[ \t]*\})[ \t]*(?:\[([^\]]*)\])?/g,"<a href='$2' title='$3' style='cursor:pointer;'>$1</a>")
			
			//for capturing links to a Quran Verse ...	   //use as   /آیه{شماره‌سوره:شماره‌آیه}
			.replace(/(?:\/آیه)(?:\{[ \t]*([\d۰-۹]+)[ \t]*\:[ \t]*([\d۰-۹]+)[ \t]*\})/g, function(x,y1,y2){
				return "<span style='cursor:pointer;' onclick='inputSurahName("+toEn(y1)+"); inputVerseNumber("+toEn(y2)+");' title='["+DB["surahInfo"][toEn(y1)]["nameAr"]+": "+toFa(y2)+"]'>["+DB["surahInfo"][toEn(y1)]["nameAr"]+": "+toFa(y2)+"]</span>";
			})
			
			
			
			// to define lists		// In this program, putting a dot before + or + does nothing and is ignored!
			.replace(/^[ \t]*(\+|\*)[ \t]*(.+)/gm, function(x,y2,y3){
				var i=1;	if(i > nestedListLevel){nestedListLevel=i;}
				y3=(y2=="+")? "<ol><li>"+y3+"</li></ol>" : "<ul><li>"+y3+"</li></ul>";
				var temp=1, yt=y3, ytt="";
				while(temp){
					ytt=yt	.replace(/\<li\>(?:\+)[ \t]*(.+)\<\/li\>/, "<ol><li>$1</li></ol>")
							.replace(/\<li\>(?:\*)[ \t]*(.+)\<\/li\>/, "<ul><li>$1</li></ul>");
					if(ytt==yt){
						temp=0;		// so the loop is terminated
						i--;
						
						// to let change the bullet fot this item and its following of the same level
						ytt=ytt.replace(/(?:\<ul\>\<li\>)(?:\[(.*)\])?/, function(x,y){
							return (y!=undefined)? "<ul style='list-style:\" "+y+" \" outside;'><li>" : "<ul><li>";
						});
					}
					yt=ytt;
					i++; if(i > nestedListLevel){nestedListLevel=i;}
				}
				return yt;
			})
			
			
			
			.replace(/(\s*\/خ\/\s*)/g,"<br>")
			.replace(/\n/g,"<br>")
			.replace(/(\<hr[^\>]+\>)\<br\>/g,"$1")
			.replace(/(\<\/[ou]l\>)\<br\>/g,"$1");
	

	// to take care of lists and nested lists
	while(nestedListLevel){
		obj.innerHTML=obj.innerHTML
						.replace(/\<\/ol\>(?:\<br\>)?\<ol\>/g,"")
						.replace(/\<\/ul\>(?:\<br\>)?\<ul\>/g,"")
						.replace(/\<\/li\>\<ol\>/g,"\<ol\>")
						.replace(/\<\/li\>\<ul\>/g,"\<ul\>");
		nestedListLevel--;
	}
}



//=============  SAVE SCROLL POSITION (IN TAFSIR BLOCK) TO THE CACHE ==============//



var isScrolling1, isScrolling2;
function percentReadQuranDiv(){
	isScrolling1 = setTimeout(function(){				// Set a timeout to run after scrolling ends
		stateConfig.quran[2] = QuranDiv.scrollTop / (QuranDiv.scrollHeight - QuranDiv.clientHeight);
		saveToCache();
	}, 500);
}
function percentReadTafseerDiv(){
	isScrolling2 = setTimeout(function(){				// Set a timeout to run after scrolling ends
		stateConfig.quran[3] = TafseerDiv.scrollTop / (TafseerDiv.scrollHeight - TafseerDiv.clientHeight);
		saveToCache();
	}, 500);
}



//=============  CHANGE THE LOOK OF THE APP BETWEEN DAY & NIGHT  ==============



function toNight(){
	document.getElementById("toNight").style.display="none";
	document.getElementById("toDay").style.display="";
	
	//document.getElementById("body").style.backgroundColor="rgb(75, 62, 09)";
	QuranDiv.style.backgroundColor="rgba(255,218,185,0.3)";
	//QuranDiv.style.boxShadow = "inset 0px 0px 20px 30vw rgba(0,0,0,0.3)";
	TafseerDiv.style.backgroundColor="rgba(222,184,135,0.4)";
	//TafseerDiv.style.boxShadow = "inset 0px 0px 20px 30vw rgba(0,0,0,0.3)";
	
	QuranDiv.style.color=TafseerDiv.style.color="#FAEBD7";
}
function toDay(){
	document.getElementById("toDay").style.display="none";
	document.getElementById("toNight").style.display="";
	
	//document.getElementById("body").style.backgroundColor="rgb(135, 112, 69)";
	QuranDiv.style.backgroundColor="rgb(255,218,185)";
	//QuranDiv.style.boxShadow = "";
	TafseerDiv.style.backgroundColor="rgb(222,184,135)";
	//TafseerDiv.style.boxShadow = "";
	
	QuranDiv.style.color=TafseerDiv.style.color="black";
}






//=============  CLOSE POPUPS BY PRESSING 'ESC' OR CLICKING OUTSIDE THE POPUPS, AND OTHER SHORTCUTS  ==============



document.addEventListener("keydown", function(e){
	if (e.keyCode == 27) { window.location.href='#'; }	// checks if Esc key is pressed
	
	if (e.ctrlKey && e.keyCode === 38){					// to handle the buttons for navigating to the previous page
		e.preventDefault();
		prevVerses();
	}else if (e.ctrlKey && e.keyCode === 40){			// add the shortcut "ctrl+down" for page change to NEXT
		e.preventDefault();
		nextVerses();
	}
});

document.onclick = function(e){
	//check if the dark backgrounds of the popups are clicked ...
	if(e.target.id == 'popupSearch' || e.target.id == 'popupAbout' || e.target.id == 'popupHelp'){
		window.location.href='#';
	}
}




//=============  TRIGGER THE SEARCH ACTION BY ALSO PRESSING ENTER  ==============



document.getElementById("search").onkeyup = function (e) {
	e = e || window.event;	
	if (e.keyCode == 13) { search(); }	// checks if Enter key is pressed
};




//================ DEFINE THE SEARCH ACTIONS ================//




var searchResultsArray=[];
var searchConditions;	// let define it globally to be able to simply avoid using  eval(searchConditions); -- But yet I couldn't get rid of it, what shall I do?
function selectWhereToSearch(faName){
	faSearchWhere=faName;
	switch(faName) {
		case "متن قرآن":
			enSearchWhere = DB["QuranNoor"];
			break;
		case "ترجمه‌ی انصاریان":
			enSearchWhere = DB["faAnsarian"];
			break;
		case "ترجمه‌ی آیتی":
			enSearchWhere = DB["faAyati"];
			break;
		case "ترجمه‌ی بهرام‌پور":
			enSearchWhere = DB["faBahrampour"];
			break;
		case "ترجمه‌ی فولادوند":
			enSearchWhere = DB["faFooladvand"];
			break;
		case "ترجمه‌ی قرائتی":
			enSearchWhere = DB["faGharaati"];
			break;
		case "ترجمه‌ی قمشه‌ای":
			enSearchWhere = DB["faGhomshei"];
			break;
		case "ترجمه‌ی خرّم‌دل":
			enSearchWhere = DB["faKhorramdel"];
			break;
		case "ترجمه‌ی خرّمشاهی":
			enSearchWhere = DB["faKhorramshahi"];
			break;
		case "ترجمه‌ی مکارم":
			enSearchWhere = DB["faMakarem"];
			break;
		case "ترجمه‌ی معزّی":
			enSearchWhere = DB["faMoezzi"];
			break;
		case "ترجمه‌ی مجتبوی":
			enSearchWhere = DB["faMojtabavi"];
			break;
		case "Sahih International's Translation":
			enSearchWhere = DB["enSahih"];
			break;
		case "Yusuf Ali's Translation":
			enSearchWhere = DB["enYusufali"];
			break;
		default:
			faSearchWhere="متن قرآن";
			enSearchWhere = DB["QuranNoor"];
	}
}
function search(){
	searchResultsArray=[];
	
	var queryOriginal=document.getElementById("search").value,
		query=queryOriginal.toLowerCase().replace(/[ًٌٍَُِْ]/g,"").replace(/ي/g,"ی").replace(/ك/g,"ک").replace(/[آأإؤئٰ]/g,"ا").replace(/[ة]/g,"ت");

	searchConditions=query.replace(/\s*\+\!\s*/g," &&! ")
							.replace(/\s*\+\s*/g," && ")
							.replace(/\s*\|\s*/g," || ")
							.replace(/\s*([^\(\)\|\&\!]+)\s*/g," (str.indexOf(\"$1\")!=-1) ");
					//e.g     a + b | c     =>    (str.indexOf(a)!=-1) && (str.indexOf(b)!=-1) || (str.indexOf(c)!=-1)
	
	document.getElementById("searchResults").innerHTML=
		'<div id="searchResultNumberFound" style="text-align:right;"></div>'
		
		+'<div id="searchHeader">'
			+'<span id="btn_prev" class="myButton" onclick="prevPage()" title="صفحه‌ی قبل" style="font-size:15px; color:green; cursor:pointer; margin:-2px 0px 2px 5px;">▶</span>'
				+'صفحه‌ی '
			+' <span id="page"></span> '
			+'<span id="btn_next" class="myButton" onclick="nextPage()" title="صفحه‌ی بعد" style="font-size:15px; color:green; cursor:pointer; margin:-2px 0px 2px 5px;">◀</span>'
		+'</div>'
		+'<div id="listingTable" style="background:rgba(255,255,255,0.3); border-radius:10px; padding:15px; text-align:right;"></div>'	// the search results will be listed here in several pages
		+'<br>'
		+'<div style="width:100%; text-align:center;">'
			+'<div id="searchFooter"></div>'
			+'<div  id="goToPageMaster">'
				+'برو به صفحه‌ی  '
				+'<input id="goToPage" type="text" placeholder="..." title="انتخاب صفحه" style="width:20px;" />'
			+'</div>'
		+'</div>'
		+'<br>'
	
	document.getElementById("searchFooter").innerHTML=document.getElementById("searchHeader").innerHTML;
	
	
	// let make possibe for user to trigger "changepage" by pressing the "Enter" key
	document.getElementById("goToPage").onkeyup = function (e) {
		e = e || window.event;	
		if (e.keyCode == 13) {	// checks if Enter key is pressed
			changePage( toEn(document.getElementById("goToPage").value));
		}
	};
	
	
	var className=(faSearchWhere=="متن قرآن")? "verseContent" : "verseTranslationContent",
		exStyle=(faSearchWhere=="Sahih International's Translation" || faSearchWhere=="Yusuf Ali's Translation")? 
				" style=\"padding:5px; text-align:left; margin-right:20px;\" lang=\"en\" dir=\"ltr\"" 
				: "style=\"margin-right:20px;\"";
	var counter=0;
	var str, string; //wExtraData;
	
	if(enSearchWhere == DB["QuranNoor"]){
		for(var i in DB["QuranNoor"]){
			string="";
			for(var j=0, l=DB["QuranNoor"][i].length; j<l; j++){
				/*wExtraData="";
				wExtraData+=(DB["QuranNoor"][i][j]["r"]!="")?	"[از ریشه‌ی «"+DB["QuranNoor"][i][j]["r"]+"»]\n"	:	"";
				wExtraData+=(DB["QuranNoor"][i][j]["sy"]!="")?	"هم‌خانواده‌های معنایی: "+DB["QuranNoor"][i][j]["sy"]+"\n"	:	"";
				//wExtraData+=(DB["QuranNoor"][i][j]["m"]!="")?	"معنا: "+toFa(DB["QuranNoor"][i][j]["m"])	:	"";
				if(wExtraData!=""){ string+='<span title="'+wExtraData+'">'+	DB["QuranNoor"][i][j]["w"]	+'</span> ';	}
				else{ string+=DB["QuranNoor"][i][j]["w"] +" ";	}
				*/
				string+=DB["QuranNoor"][i][j]["w"] +" ";
			}
			
			str=string.toLowerCase().replace(/[ًٌٍَُِْ]/g,"").replace(/ي/g,"ی").replace(/ك/g,"ک").replace(/[آأإؤئٰ]/g,"ا").replace(/[ة]/g,"ت");
			
			if(eval(searchConditions)){
				counter++;
				
				// to highlight the matching phrases in colors
				string=highlightSearchResults(string,query);
				
				var s=Number(i.replace(/(\d+)\:\d+/,"$1")), v=Number(i.replace(/\d+\:(\d+)/,"$1"));
				searchResultsArray.push(
					'<p class="'+className+'"'+exStyle+'>'
						+toFa(counter)+'. '+string
						+'<span onclick="inputSurahName('+s+'); inputVerseNumber('+v+'); window.location.href=\'#\';" style="cursor:pointer; color:crimson;">'
							+' ('+DB["surahInfo"][s]["nameAr"]+': '+toFa(v)+')'
						+'</span>'
					+'</p>'
				);
			}
		}
	}else{
		for(var i in enSearchWhere){
			string=(faSearchWhere=="Sahih International's Translation" || faSearchWhere=="Yusuf Ali's Translation")? 	enSearchWhere[i]	:	 toFa(enSearchWhere[i]);
			str=string.toLowerCase().replace(/[ًٌٍَُِْ]/g,"").replace(/ي/g,"ی").replace(/[ك]/g,"ک").replace(/[آأإؤئٰ]/g,"ا").replace(/[ة]/g,"ت");	//.replace(/\s/g,"");
			
			if(eval(searchConditions)){
				counter++;
				
				// to highlight the matching phrases in colors
				string=highlightSearchResults(string,query);
				
				
				var s=Number(i.replace(/(\d+)\:\d+/,"$1")),
					v=(faSearchWhere=="Sahih International's Translation" || faSearchWhere=="Yusuf Ali's Translation")? 
						Number(i.replace(/\d+\:(\d+)/,"$1"))
						: toFa(Number(i.replace(/\d+\:(\d+)/,"$1")));
				
				
				searchResultsArray.push(
					'<p class="'+className+'"'+exStyle+'>'
						+toFa(counter)+'. '+string
						+'<span onclick="inputSurahName('+s+'); inputVerseNumber('+toEn(v)+'); window.location.href=\'#\';" style="cursor:pointer; color:crimson;">'
							+' ('+DB["surahInfo"][s]["nameAr"]+': '+v+')'
						+'</span>'
					+'</p>'
				);
			}
		}
	}
	
	
	document.getElementById("searchResultNumberFound").innerHTML=
		'<p style="text-shadow:1px 1px 1px black;">'
			+'نتایج جستجوی «'+queryOriginal+'» در «'+faSearchWhere+'» : '
			+'<span style="color:orange"> (تعداد آیات یافت شده: '
				+'<span style="color:red">'+toFa(counter)+'</span>'
			+')</span>'
		+'</p>'
	
	changePage(1);
	
	// inorder to show nothing extra if there is no results found!
	if(counter==0){
		document.getElementById("searchHeader").outerHTML="";
		document.getElementById("listingTable").outerHTML="";
		document.getElementById("searchFooter").outerHTML="";
		document.getElementById("goToPageMaster").outerHTML="";
	}
	else if(counter<=2*records_per_page){
		document.getElementById("goToPageMaster").outerHTML="";
	}
}
function highlightSearchResults(string,query){
	var stringArray=string.split(/\s+/g); //an array that contains "word by word" of the "found" verse or its translation, based on the searchConditions
	var queryHighlight=query.replace(/^\s+/m,"").replace(/\s+$/m,"").split(/[\s+\|(+!)]+/);
	var highlightColorList=["Yellow", "LawnGreen", "DeepPink", "Aqua", "DarkOrange", "DodgerBlue", "Olive", "Crimson", "OrangeRed", "DarkOrchid"];
	
	for(var j in stringArray){
		for(var k in queryHighlight){
			if(stringArray[j].toLowerCase().replace(/[ًٌٍَُِْ]/g,"").replace(/ي/g,"ی").replace(/ك/g,"ک").replace(/[آأإؤئٰ]/g,"ا").replace(/[ة]/g,"ت")
				.indexOf(queryHighlight[k].toLowerCase().replace(/[ًٌٍَُِْ]/g,"").replace(/ي/g,"ی").replace(/ك/g,"ک").replace(/[آأإؤئٰ]/g,"ا").replace(/[ة]/g,"ت") )!=-1){
				stringArray[j]="<span style='color:"+highlightColorList[k]+"; text-shadow:1px 1px 1px black; margin-right:2px;'>"+stringArray[j]+"</span>";
			}
		}
	}
	return string=stringArray.join(" ");
}
function selectRoot(root){
	if(DB["rootsList"][root]!=undefined) {document.getElementById("rootsList").value=lastRootSelected=root;}
	else{return false;}
	
	searchResultsArray=[];
	document.getElementById("searchResults").innerHTML=
		'<div id="searchResultNumberFound" style="text-align:right;"></div>'
		
		+'<div id="searchHeader">'
			+'<span id="btn_prev" class="myButton" onclick="prevPage()" title="صفحه‌ی قبل" style="font-size:15px; color:green; cursor:pointer; margin:-2px 0px 2px 5px;">▶</span>'
				+'صفحه‌ی '
			+' <span id="page"></span> '
			+'<span id="btn_next" class="myButton" onclick="nextPage()" title="صفحه‌ی بعد" style="font-size:15px; color:green; cursor:pointer; margin:-2px 0px 2px 5px;">◀</span>'
		+'</div>'
		+'<div id="listingTable" style="background:rgba(255,255,255,0.3); border-radius:10px; padding:15px; text-align:right;"></div>'	// the search results will be listed here in several pages
		+'<br>'
		+'<div style="width:100%; text-align:center;">'
			+'<div id="searchFooter"></div>'
			+'<div  id="goToPageMaster">'
				+'برو به صفحه‌ی  '
				+'<input id="goToPage" type="text" placeholder="..." title="انتخاب صفحه" style="width:20px;" />'
			+'</div>'
		+'</div>'
		+'<br>'
	
	document.getElementById("searchFooter").innerHTML=document.getElementById("searchHeader").innerHTML;
	
	
	// let make possibe for user to trigger "changepage" by pressing the "Enter" key
	document.getElementById("goToPage").onkeyup = function (e) {
		e = e || window.event;	
		if (e.keyCode == 13) {	// checks if Enter key is pressed
			changePage( toEn(document.getElementById("goToPage").value));
		}
	};
	
	
	var string;
	var len=DB["rootsList"][root].length;		// number of verses containing the specified root
	for(var i=0; i<len; i++){
		string="";
		var index=DB["rootsList"][root][i];		// SurahNumber:VerseNumber
		for(var j=0, l=DB["QuranNoor"][index].length; j<l; j++){
			if(DB["QuranNoor"][index][j]["r"]==root){
				// to highlight the matching phrases in colors
				string+=" <span style='color:PaleVioletRed; text-shadow:1px 1px 1px black; margin-right:2px;'>"+DB["QuranNoor"][index][j]["w"]+"</span> ";
			}
			else{
				string+=DB["QuranNoor"][index][j]["w"]+" ";
			}
		}
		
		var s=Number(index.replace(/(\d+)\:\d+/,"$1")), v=Number(index.replace(/\d+\:(\d+)/,"$1"));
		searchResultsArray.push(
			'<p class="verseContent">'
				+toFa(Number(i)+1)+'. '+string
				+'<span onclick="inputSurahName('+s+'); inputVerseNumber('+v+'); window.location.href=\'#\';" style="cursor:pointer; color:crimson;">'
					+' ('+DB["surahInfo"][s]["nameAr"]+': '+toFa(v)+')'
				+'</span>'
			+'</p>'
		);
	}
	
	
	document.getElementById("searchResultNumberFound").innerHTML=
		'<p style="text-shadow:1px 1px 1px black;">'
		+'نتایج جستجوی ریشه‌ی «'+root+'» در متن قرآن : '
			+'<span style="color:orange"> (تعداد آیات یافت شده: '
				+'<span style="color:red">'+toFa(len)+'</span>'
			+')</span>'
		+'</p>'
	
	changePage(1);
	
	if(len<=2*records_per_page){
		document.getElementById("goToPageMaster").outerHTML="";
	}
}




/* ---------------------------------------------------------- */
/* script for pagination of the search results */


/* this file uses and is inspired by "http://stackoverflow.com/questions/25434813/simple-pagination-in-javascript" and "https://www.script-tutorials.com/how-to-create-easy-pagination-with-jquery/" */
var current_page = 1;
var records_per_page = 10;

function prevPage(){
	if (current_page > 1){
		current_page--;
		changePage(current_page);
	}
}
function nextPage(){
	if (current_page < numPages()){
		current_page++;
		changePage(current_page);
	}
}

function changePage(page){
	// Validate page
	if (page < 1) page = 1;
	if (page > numPages()) page = numPages();    
	current_page=page;
	document.getElementById("listingTable").innerHTML = "";
	
	for (var i = (page-1) * records_per_page; i < (page * records_per_page) && i < searchResultsArray.length; i++){
		document.getElementById("listingTable").innerHTML+=searchResultsArray[i]+"<br>";
	}
	
	document.getElementById("page").innerHTML = toFa(page)+" از "+toFa(numPages());
	
	if (page == 1) {document.getElementById("btn_prev").style.display = "none";}
	else{document.getElementById("btn_prev").style.display = "";}
	if (page == numPages()){document.getElementById("btn_next").style.display = "none";}
	else{document.getElementById("btn_next").style.display = "";}
	
	document.getElementById("searchFooter").innerHTML=document.getElementById("searchHeader").innerHTML;
}
function numPages(){
	return Math.ceil(searchResultsArray.length / records_per_page);
}







// -----------------------------------------------------------------------------
// defining function for resizing the "Quran" and "Tafseer" divs, interactively ...


dragElement(document.getElementById("draggablePaneSeparator"));
function dragElement(el){
	el.onmousedown = function(ev){
		ev = ev || window.event;
		ev.preventDefault();
		
		document.onmouseup = function(){	// stop moving when mouse button is released
			document.onmouseup = null;
			document.onmousemove = null;
		};
		document.onmousemove =  function(e){
			e = e || window.event;
			e.preventDefault();
			
			if(e.screenX<=10){
				QuranDiv.style.display =  'initial';
				el.style.left = '3px';
				QuranDiv.style.width =  'calc(100% - 5px)';
				TafseerDiv.style.display =  'none';
			}else if(e.screenX>=(window.innerWidth-25)){
				TafseerDiv.style.display =  'initial';
				el.style.left = (window.innerWidth-10)+'px';
				TafseerDiv.style.width =  'calc(100% - 5px)';
				QuranDiv.style.display =  'none';
			}else{
				QuranDiv.style.display =  'initial';
				TafseerDiv.style.display =  'initial';
				el.style.left = 'calc('+ (e.screenX) +'px)';
				TafseerDiv.style.width =  'calc('+ el.style.left +' - 5px)';
				QuranDiv.style.width =  'calc(100% - '+ (TafseerDiv.style.width) +' - 5px)';
			}
			
			
		};
	};
}





//====================  OPEN A NEW FILE  =====================


var openFile=document.getElementById("Openfile");

function openFunction(){
	if(stateConfig){
		if(!confirm('با باز کردن فایل جدید تنظیمات و یادداشت‌های ذخیره‌نشده‌ی فعلی از دست می‌روند، آیا با این حال ادامه می‌دهید؟')){
			return false;
		}
	}
	openFile.click();	// this opens the file browser dialog for selecting a file to open
	return;
};

openFile.addEventListener('change', function() {
	var fileToLoad=openFile.files[0];			// the selected file itself as an object?
	var fileToLoadAddress=openFile.value;		// the relative or absolute address of the selected file
	
	document.getElementById("fileName").innerHTML="<span style='color:rgb(238,232,170);'>فایل: </span>"
													+fileToLoadAddress.split('\\').pop()  .replace(/(.txt)/,"").replace(/\./g,":");
	
	if(fileToLoad){
		var reader=new FileReader();
		reader.readAsText(fileToLoad, "UTF-8");
		reader.onload=function(event){
			stateConfig = JSON.parse(event.target.result);
			
			surahNumber=stateConfig.quran[0];
			tempVerseNumber=verseNumber=stateConfig.quran[1];
			tempQuranDivscrollTop=stateConfig.quran[2];
			tempTafseerDivscrollTop=stateConfig.quran[3];
			selectNumVerseShown=stateConfig.quran[4];
			shownItemsInQuranDiv=[];
			for(var i=0, l=stateConfig.shownItemsInQuranDiv.length; i<l; i++){
				shownItemsInQuranDiv.push(stateConfig.shownItemsInQuranDiv[i]);
			}
			
			inputSurahName(surahNumber);
			inputVerseNumber(tempVerseNumber);	// as "inputSurahName()" above, sets "verseNumber=1"
			
			QuranDiv.scrollTop = (QuranDiv.scrollHeight - QuranDiv.clientHeight)*Number(tempQuranDivscrollTop);
			TafseerDiv.scrollTop = (TafseerDiv.scrollHeight - TafseerDiv.clientHeight)*Number(tempTafseerDivscrollTop);
		}
		reader.onerror=function(event){
			alert("بارگذاری فایل انتخابی ناموفق بود!");
		}
	}
});



// -----------------------------------------------------------------------------
// Drag&Drop text file into the siurce textarea to open the file's content there
// got the inspiration from "http://devjs.eu/en/drag-multiple-text-files-to-your-web-application-with-html5-and-javascript/"


document.getElementById("Quran").addEventListener('dragover', dragOver);
document.getElementById("Quran").addEventListener('dragend', dragEnd);
document.getElementById("Quran").addEventListener('drop', readText, false);

function dragOver(e){
	e.stopPropagation(); // for some browsers stop redirecting
	e.preventDefault();
	//e.dataTransfer.effectAllowed = "move";		// when the curser changed, the file can be dropped!
	return false;
}
function dragEnd(e){
	e.stopPropagation(); // for some browsers stop redirecting
	e.preventDefault();
	return false;
}
function readText(e){
	e.stopPropagation(); // for some browsers stop redirecting
	e.preventDefault();
	
	var fileData, reader, file=e.dataTransfer.files[0];
	if (!file) {return false;}
	
	if(stateConfig){
		if(!confirm('با باز کردن فایل جدید تنظیمات و یادداشت‌های ذخیره‌نشده‌ی فعلی از دست می‌روند، آیا با این حال ادامه می‌دهید؟')){
			return false;
		}
	}
    
    //to read the content of the file
    reader=new FileReader();
	reader.readAsText(file, "UTF-8");
	reader.onload=function(event){
		stateConfig = JSON.parse(event.target.result);
		
		surahNumber=stateConfig.quran[0];
		tempVerseNumber=verseNumber=stateConfig.quran[1];
		tempQuranDivscrollTop=stateConfig.quran[2];
		tempTafseerDivscrollTop=stateConfig.quran[3];
		selectNumVerseShown=stateConfig.quran[4];
		shownItemsInQuranDiv=[];
		for(var i=0, l=stateConfig.shownItemsInQuranDiv.length; i<l; i++){
			shownItemsInQuranDiv.push(stateConfig.shownItemsInQuranDiv[i]);
		}
		
		inputSurahName(surahNumber);
		inputVerseNumber(tempVerseNumber);	// as "inputSurahName()" above, sets "verseNumber=1"
		
		QuranDiv.scrollTop = (QuranDiv.scrollHeight - QuranDiv.clientHeight)*Number(tempQuranDivscrollTop);
		TafseerDiv.scrollTop = (TafseerDiv.scrollHeight - TafseerDiv.clientHeight)*Number(tempTafseerDivscrollTop);
	}
	reader.onerror=function(event){ alert("بارگذاری فایل انتخاب شده ناموفق بود!"); };
	
	
	document.getElementById("fileName").innerHTML="<span style='color:rgb(238,232,170);'>فایل: </span>"
													+file.name.split('\\').pop()  .replace(/(.txt)/,"").replace(/\./g,":");
}




//====================  SAVE TO A FILE (PERMANENT BACKUP)  =====================




function saveData(){
	if(stateConfig){
		// ------- if using  download.js
		download(  JSON.stringify(stateConfig)	,	"یادداشت‌ها ("+persianDateTime().replace(/\:/g,".")+").txt"	,	"text/html");
	}else{
		alert("هنوز تنظیماتی انجام نشده و یادداشتی گذاشته نشده است که که ذخیره گردند!");
	}
}



//=============  NOW INITIALIZE THE PROGRAM  ==============//


(function(){
	for(var i=0, l=stateConfig.shownItemsInQuranDiv.length; i<l; i++){
		shownItemsInQuranDiv.push(stateConfig.shownItemsInQuranDiv[i]);
	}
	
	inputSurahName(surahNumber);
	inputVerseNumber(tempVerseNumber);	// as "inputSurahName()" above, sets "verseNumber=1"
	
	QuranDiv.scrollTop = (QuranDiv.scrollHeight - QuranDiv.clientHeight)*Number(tempQuranDivscrollTop);
	TafseerDiv.scrollTop = (TafseerDiv.scrollHeight - TafseerDiv.clientHeight)*Number(tempTafseerDivscrollTop);
})();
