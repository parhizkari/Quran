/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function( config ) {
	config.language = 'fa';	// en
	//config.uiColor = '#AADC6E';
	config.skin = 'office2013';
	//config.startupFocus = true;
	config.toolbarGroups = [
		{ name: 'document', groups: [ 'document', 'mode', 'doctools' ] },
		{ name: 'editing', groups: [ 'find', 'selection', 'spellchecker', 'editing' ] },
		{ name: 'forms', groups: [ 'forms' ] },
		{ name: 'styles', groups: [ 'styles' ] },
		{ name: 'colors', groups: [ 'colors' ] },
		{ name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ] },
		{ name: 'clipboard', groups: [ 'clipboard', 'undo' ] },
		'/',
		{ name: 'paragraph', groups: [ 'list', 'indent', 'blocks', 'align', 'bidi', 'paragraph' ] },
		{ name: 'links', groups: [ 'links' ] },
		{ name: 'insert', groups: [ 'insert' ] },
		{ name: 'tools', groups: [ 'tools' ] },
		{ name: 'others', groups: [ 'others' ] },
		{ name: 'about', groups: [ 'about' ] }
	];
	config.removeButtons =	'Source,Save,NewPage,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteFromWord,Find,Replace,SelectAll,Scayt,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,RemoveFormat,CreateDiv,Language,Anchor,Flash,PageBreak,Iframe,Styles,Maximize,ShowBlocks,About';
	//config.removePlugins = 'elementspath,save,font';
	config.font_names =
		//'HM XNiloofar;IranNastaliq;Neirizi;A Hakim Ghazali;HM XSols;Arial;Tahoma;Zapfino;Callahan';
		'Neirizi;A Hakim Ghazali';
	//config.colorButton_colors = 'CF5D4E,454545,FFF,CCC,DDD,CCEAEE,66AB16';
	config.smiley_path=CKEDITOR.basePath+'plugins/smiley/images/';	// '/ckeditor/plugins/smiley/images/';
	config.smiley_columns = 7;
	config.smiley_images=[
		'1.png', '2.png', '3.png', '4.png', '5.png', '6.png', '7.png', '8.png', '9.png', '10.png', '11.png', '12.png', '13.png', '14.png', '15.png', '16.png', '17.png', '18.png', '19.png', '20.gif', '21.gif', '22.gif', '23.gif', '24.gif', 's1.gif', 's2.gif', 's3.gif', 's4.gif', 's5.gif', 's6.gif', 's7.gif', 's8.gif', 's9.gif', 's10.gif', 's11.gif', 's12.gif', 's13.gif', 's14.gif', 's15.gif', 's16.gif', 's17.gif', 's18.gif', 's19.gif'
	];
	config.smiley_descriptions = [
		'(الله)','(محمد)','(علی)','(جل)','(ص)','(علیه)','(علیها)','(علیهما)','(علیهم)','(عج)','(رحمه)', '(رحمهما)', '(رحمهم)', '(سره)', '(سرهما)', '(سرهم)', '(دام)', '','','','','','','','','','','','','','','','','','','','','','','','','',''
	];
	// //Add extra plugins here:
	// // "confighelper" plugin lets adding placeholder when the comment area is empty
	config.extraPlugins = 'confighelper';	// "confighelper" useful for using inline instances of CkEditor
	//config.allowedContent = true;
};