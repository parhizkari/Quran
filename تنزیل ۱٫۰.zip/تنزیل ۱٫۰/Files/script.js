//=================  TRANSFORM NUMBERS TO PERSIAN/ENGLISH  ==================



function toFa(textContainingEnglishNumbers){
	return textContainingEnglishNumbers.toString()
		.replace(/0/g,'۰').replace(/1/g,'۱').replace(/2/g,'۲').replace(/3/g,'۳').replace(/4/g,'۴')
		.replace(/5/g,'۵').replace(/6/g,'۶').replace(/7/g,'۷').replace(/8/g,'۸').replace(/9/g,'۹');
}
function toEn(persianNumbers){
	return persianNumbers.toString()
		.replace(/۰/g,'0').replace(/۱/g,'1').replace(/۲/g,'2').replace(/۳/g,'3').replace(/۴/g,'4')
		.replace(/۵/g,'5').replace(/۶/g,'6').replace(/۷/g,'7').replace(/۸/g,'8').replace(/۹/g,'9');
}
//alert(toFa("53 is 53 and not 78 !"));
//alert(toEn("۴۵")+2);




//=============  DEFINE THE VARIABLES  ==============//



var	container1=document.getElementById("container1"),
	container2=document.getElementById("container2"),
	container3=document.getElementById("container3"),
	
	size1_1=40,	size1_2=30,	size1_3=30,
	size2_1=50,	size2_2=50,	size2_3=50,
	size3_1=40,	size3_2=30,	size3_3=30,
	
	div1=document.getElementById("div1"),
	div2=document.getElementById("div2"),
	div3=document.getElementById("div3"),
	div4=document.getElementById("div4"),
	div5=document.getElementById("div5"),
	div6=document.getElementById("div6"),
	
	content1=document.getElementById("content1"),
	content2=document.getElementById("content2"),
	content3=document.getElementById("content3"),
	content4=document.getElementById("content4"),
	content5=document.getElementById("content5"),
	content6=document.getElementById("content6"),
	
	instanceSplit123, instanceSplit145, instanceSplit45, instanceSplit146,
	
	Quran, Translations, Interpretation,
	
	translationShown="mojtabavi",
	
	surahNumber=1, verseNumber=1,
	
	enSearchWhere="quran", faSearchWhere="متن قرآن",
	lastAlphabetSelected="أ", lastDictSelected="majmaulBahrainDict";




//=============  USE localStorage OF HTML5 TO RELOAD DATA FROM CACHE AT START  ==============//



var stateConfig={
	"state":1,
	"size":{
		1:[40,30,30],
		2:[50,50,50],
		3:[40,30,30]
	},
	"quran":[1,1,0],       //  stateConfig.quran[2]  stands for scrollTop IN PERCENT in Tafseer section
	"trans":"mojtabavi"
};

if (window.localStorage["savedInCahe"]) {
	stateConfig = JSON.parse(window.localStorage["savedInCahe"]);	//retrieves the data from the browser's cache even after the browser/tab is reopened
	
	if(stateConfig.state==1){
		container2.style.display="";
		container3.style.display="";
		div6.scrollTop = (div6.scrollHeight - div6.clientHeight)*Number(stateConfig.quran[2]);
	}else if(stateConfig.state==2){
		container2.style.display="";
		container3.style.display="none";
        document.getElementById('button4').style.display="";
        div5.scrollTop = (div5.scrollHeight - div5.clientHeight)*Number(stateConfig.quran[2]);
	}else{
		container2.style.display="none";
		container3.style.display="none";
        div3.scrollTop = (div3.scrollHeight - div3.clientHeight)*Number(stateConfig.quran[2]);
	}
	
	size1_1=stateConfig.size["1"][0];	size1_2=stateConfig.size["1"][1];	size1_3=stateConfig.size["1"][2];
	size2_1=stateConfig.size["2"][0];	size2_2=stateConfig.size["2"][1];	size2_3=stateConfig.size["2"][2];
	size3_1=stateConfig.size["3"][0];	size3_2=stateConfig.size["3"][1];	size3_3=stateConfig.size["3"][2];
	
	translationShown=stateConfig.trans;
	surahNumber=stateConfig.quran[0];
	verseNumber=stateConfig.quran[1];
	
	//alert(JSON.stringify(stateConfig));
}




//=============  USE localStorage OF HTML5 TO AUTOMATE SAVING OF DATA IN CACHE ==============//



function saveToCache(){
	window.localStorage["savedInCahe"] = JSON.stringify(stateConfig);	// stores the data to the browser's cache
	//alert(JSON.stringify(stateConfig));
}




//=== GENERATE CONTENT OF VARIBLES "Quran", "Translations" AND "Interpretation" TO FEED THEM LATER ===//



var 	quranSurahs=[],
	mojtabaviSurahs=[],
	moezziSurahs=[],
	makaremSurahs=[],
	khorramshahiSurahs=[],
	khorramdelSurahs=[],
	ghomsheiSurahs=[],
	fooladvandSurahs=[],
	bahrampourSurahs=[],
	ayatiSurahs=[],
	ansarianSurahs=[],
	yusufaliSurahs=[],
	sahihSurahs=[],
	verseID=0;

for(var surah=1; surah<=114; surah++){
	var 	quranSurahContent="",
		mojtabaviSurahContent="",
		moezziSurahContent="",
		makaremSurahContent="",
		khorramshahiSurahContent="",
		khorramdelSurahContent="",
		ghomsheiSurahContent="",
		fooladvandSurahContent="",
		bahrampourSurahContent="",
		ayatiSurahContent="",
		ansarianSurahContent="",
		yusufaliSurahContent="",
		sahihSurahContent="";
	
	for(var verse=1, surahLength=surahInfo[surah]["numVerse"]; verse<=surahLength; verse++){
		verseID++;
		quranSurahContent+=
			'<span id="['+surah+':'+verse+']" class="verseContent" onclick="clickOnVerse('+verse+')">'
				+quranSimpleEnhanced[verseID]["verse"]
				+'(<span class="verseNumbering">'+toFa(quranSimpleEnhanced[verseID]["ayah"])+'</span>) '
			+'</span>';
		mojtabaviSurahContent+=
			'<span id="mojtabavi['+surah+':'+verse+']" class="verseTranslationContent" onclick="clickOnVerse('+verse+')">'
				+faMojtabavi[verseID]["verse"]
				+'(<span class="verseNumbering">'+toFa(quranSimpleEnhanced[verseID]["ayah"])+'</span>) '
			+'</span>';
		moezziSurahContent+=
			'<span id="moezzi['+surah+':'+verse+']" class="verseTranslationContent" onclick="clickOnVerse('+verse+')">'
				+faMoezzi[verseID]["verse"]
				+'(<span class="verseNumbering">'+toFa(quranSimpleEnhanced[verseID]["ayah"])+'</span>) '
			+'</span>';
		makaremSurahContent+=
			'<span id="makarem['+surah+':'+verse+']" class="verseTranslationContent" onclick="clickOnVerse('+verse+')">'
				+faMakarem[verseID]["verse"]
				+'(<span class="verseNumbering">'+toFa(quranSimpleEnhanced[verseID]["ayah"])+'</span>) '
			+'</span>';
		khorramshahiSurahContent+=
			'<span id="khorramshahi['+surah+':'+verse+']" class="verseTranslationContent" onclick="clickOnVerse('+verse+')">'
				+faKhorramshahi[verseID]["verse"]
				+'(<span class="verseNumbering">'+toFa(quranSimpleEnhanced[verseID]["ayah"])+'</span>) '
			+'</span>';
		khorramdelSurahContent+=
			'<span id="khorramdel['+surah+':'+verse+']" class="verseTranslationContent" onclick="clickOnVerse('+verse+')">'
				+faKhorramdel[verseID]["verse"]
				+'(<span class="verseNumbering">'+toFa(quranSimpleEnhanced[verseID]["ayah"])+'</span>) '
			+'</span>';
		ghomsheiSurahContent+=
			'<span id="ghomshei['+surah+':'+verse+']" class="verseTranslationContent" onclick="clickOnVerse('+verse+')">'
				+faGhomshei[verseID]["verse"]
				+'(<span class="verseNumbering">'+toFa(quranSimpleEnhanced[verseID]["ayah"])+'</span>) '
			+'</span>';
		fooladvandSurahContent+=
			'<span id="fooladvand['+surah+':'+verse+']" class="verseTranslationContent" onclick="clickOnVerse('+verse+')">'
				+faFooladvand[verseID]["verse"]
				+'(<span class="verseNumbering">'+toFa(quranSimpleEnhanced[verseID]["ayah"])+'</span>) '
			+'</span>';
		bahrampourSurahContent+=
			'<span id="bahrampour['+surah+':'+verse+']" class="verseTranslationContent" onclick="clickOnVerse('+verse+')">'
				+faBahrampour[verseID]["verse"]
				+'(<span class="verseNumbering">'+toFa(quranSimpleEnhanced[verseID]["ayah"])+'</span>) '
			+'</span>';
		ayatiSurahContent+=
			'<span id="ayati['+surah+':'+verse+']" class="verseTranslationContent" onclick="clickOnVerse('+verse+')">'
				+faAyati[verseID]["verse"]
				+'(<span class="verseNumbering">'+toFa(quranSimpleEnhanced[verseID]["ayah"])+'</span>) '
			+'</span>';
		ansarianSurahContent+=
			'<span id="ansarian['+surah+':'+verse+']" class="verseTranslationContent" onclick="clickOnVerse('+verse+')">'
				+faAnsarian[verseID]["verse"]
				+'(<span class="verseNumbering">'+toFa(quranSimpleEnhanced[verseID]["ayah"])+'</span>) '
			+'</span>';
		yusufaliSurahContent+=
			'<span id="yusufali['+surah+':'+verse+']" class="verseTranslationContent" onclick="clickOnVerse('+verse+')">'
				+enYusufali[verseID]["verse"]
				+'(<span class="verseNumbering">'+toFa(quranSimpleEnhanced[verseID]["ayah"])+'</span>) '
			+'</span>';
		sahihSurahContent+=
			'<span id="sahih['+surah+':'+verse+']" class="verseTranslationContent" onclick="clickOnVerse('+verse+')">'
				+enSahih[verseID]["verse"]
				+'(<span class="verseNumbering">'+toFa(quranSimpleEnhanced[verseID]["ayah"])+'</span>) '
			+'</span>';
	}
	
	quranSurahs.push({
		"surahTitle": toFa(surah)+'. '+surahInfo[surah]["nameAr"]+' ('+surahInfo[surah]["revealedAr"]+')',
		"content":     quranSurahContent
	});
	mojtabaviSurahs.push(mojtabaviSurahContent);
	moezziSurahs.push(moezziSurahContent);
	makaremSurahs.push(makaremSurahContent);
	khorramshahiSurahs.push(khorramshahiSurahContent);
	khorramdelSurahs.push(khorramdelSurahContent);
	ghomsheiSurahs.push(ghomsheiSurahContent);
	fooladvandSurahs.push(fooladvandSurahContent);
	bahrampourSurahs.push(bahrampourSurahContent);
	ayatiSurahs.push(ayatiSurahContent);
	ansarianSurahs.push(ansarianSurahContent);
	yusufaliSurahs.push(yusufaliSurahContent);
	sahihSurahs.push(sahihSurahContent);
}




//========== TO GENERATE THE MENUS FROM WHICH SURAHS AND VERSES ARE SELECTED ==========//
//======= AND FEED THE VARIABLES "Quran", "Translations" AND "Interpretation" ACCORDINGLY =======//


// === MENUS

var	optionsSurahList="",
	optionsVerseList="";

for(var i=0; i<114; i++){
	var surahInfoSimplified=quranSurahs[i]["surahTitle"]
		.replace(/[ًٌٍَُِّْ\u0670]+/g, "").replace(/[ي]+/g, "ی").replace(/[أإ]+/g, "ا").replace(/[ك]+/g,"ک");	// \u0670 :الف مقصوره
	optionsSurahList += '<a>'+surahInfoSimplified+'</a>';
}
//for(var i=0; i<7; i++){
//	optionsVerseList += '<option value="'+toFa(i)+'">'+toFa(i)+'</option>';
//}
document.getElementById("header1").innerHTML=
	'<div class="combobox">'
		+'<input type="text" id="surahNameList" placeholder="سوره" title="انتخاب سوره" size="15" value="'+quranSurahs[surahNumber-1]["surahTitle"]+'">'
		//+'<span></span>'	//+'<span>▼</span>'
		+'<div class="dropdownlist" id="surahNameListDropdown">'
			+optionsSurahList
		+'</div>'
	+'</div>'
	+'<div class="combobox">'
		+'<input type="text" id="verseNumberList" placeholder="آیه" title="انتخاب آیه" size="3" value="'+toFa(verseNumber)+'">'
		//+'<span></span>'	//+'<span>▼</span>'
		+'<div class="dropdownlist" id="verseNumberListDropdown"></div>'
	+'</div>';


ComboBox = function(object_name){
	// Edit element cache 
	this.edit = document.getElementById(object_name);
	// Items Container 
	var ddl = document.getElementById(object_name).parentNode.getElementsByTagName('DIV');
	this.dropdownlist = ddl[0];
	// Current Item
	this.currentitem = null;
	// Current Item Index
	this.currentitemindex = null;
	// Visible Items Count
	this.visiblecount = 0;
	// Closure Object 
	var parobject = this;   
	// Picker
	//var pick = document.getElementById(object_name).parentNode.getElementsByTagName('SPAN');
	//pick[0].onclick =function () {
	//	parobject.edit.focus();
	//};
	// when input value is changed in either way, by typing or by mouse click on an item?
	this.edit.onchange = function () {
		if(object_name=="surahNameList"){
			//inputSurahName(parobject.edit.value);
			//document.getElementById("surahNameList").blur();
		}else if(object_name=="verseNumberList"){
			inputVerseNumber(parobject.edit.value);
			document.getElementById("verseNumberList").blur();
		}else if(object_name=="alphabetList"){
			selectAlphabet(parobject.edit.value);
			document.getElementById("alphabetList").blur();
		}else{
			//selectWhereToSearch(parobject.edit.value);
			//document.getElementById("searchWhere").blur();
		}
	};
	// Show Items when edit get focus
	this.edit.onfocus = function () {
		parobject.edit.value='';
		
		parobject.dropdownlist.style.display = 'block';
		for (var i=0, l=parobject.listitems.length; i<l; i++) {
			parobject.listitems[i].style.display = 'block';
			parobject.listitems[i].innerHTML =  parobject.listitems[i].innerHTML.replace(/\<span style\=\"color:crimson;\"\>/g, '').replace(/\<\/span\>/g, '');
		}
	};
	// Hide Items when edit lost focus
	this.edit.onblur = function () {
		if(object_name=="surahNameList"){
			parobject.edit.value=quranSurahs[surahNumber-1]["surahTitle"];
		}else if(object_name=="verseNumberList"){
			parobject.edit.value=toFa(verseNumber);
		}else if(object_name=="alphabetList"){
			parobject.edit.value=lastAlphabetSelected;
		}else{
			parobject.edit.value=faSearchWhere;
		}
		if(allowLoose)	setTimeout(function(){parobject.dropdownlist.style.display = 'none';}, 150);
	};
	var allowLoose=true;
	// IE fix
	parobject.dropdownlist.onmousedown = function(event) {
		allowLoose = false;
    return false;
	}
	parobject.dropdownlist.onmouseup = function(event) {
		setTimeout(function () {allowLoose = true;}, 150);
    return false;
	}
	// Get Items
	this.listitems = this.dropdownlist.getElementsByTagName('A');
	for (var i=0;i < this.listitems.length; i++) {
		var t = i;
		// Binding Click Event
		this.listitems[i].onclick = function () {
			var upv = parobject.currentitem.innerHTML.replace(/\<span style\=\"color:crimson;\"\>/g, '').replace(/\<\/span\>/g, '');
			parobject.edit.value = upv;
			parobject.dropdownlist.style.display = 'none';
			if(object_name=="surahNameList"){
				inputSurahName(upv);
				document.getElementById("surahNameList").blur();
			}else if(object_name=="verseNumberList"){
				inputVerseNumber(upv);
				document.getElementById("verseNumberList").blur();
			}else if(object_name=="alphabetList"){
				selectAlphabet(upv);
				document.getElementById("alphabetList").blur();
			}else{
				selectWhereToSearch(upv);
				document.getElementById("searchWhere").blur();
			}
			return false;
		}
		// Binding OnMouseOver Event
		this.listitems[i].onmouseover = function (e) {
			for (var i=0;i < parobject.listitems.length; i++) {
				if (this == parobject.listitems[i]) {
					if (parobject.currentitem) {
						parobject.currentitem.className = parobject.currentitem.className.replace(/light/g, '')
					}
					parobject.currentitem = parobject.listitems[i];
					parobject.currentitemindex = i;
					parobject.currentitem.className += ' light';
				}
			}
		}
	};
	// Binding OnKeyDown Event
	this.edit.onkeydown = function (e) {
		e = e || window.event;	
		// Move Selection Up
		if (e.keyCode == 38) {
			// up
			var cn =0;
			if (parobject.visiblecount > 0) {
				if (parobject.visiblecount == 1) {
					parobject.currentitemindex = parobject.listitems.length-1;
				};
				do {
					parobject.currentitemindex--;
					cn++;
				} 
				while (parobject.currentitemindex>0 && parobject.listitems[parobject.currentitemindex].style.display == 'none');
				if(parobject.currentitemindex < 0) parobject.currentitemindex = parobject.listitems.length-1;
				
				if (parobject.currentitem) {
					parobject.currentitem.className = parobject.currentitem.className.replace(/light/g, '')
				};
				parobject.currentitem = parobject.listitems[parobject.currentitemindex];
				parobject.currentitem.className += ' light';
				parobject.currentitem.scrollIntoView(false);
				//parobject.edit.value = parobject.currentitem.innerHTML.replace(/\<span style\=\"color:crimson;\"\>/g, '').replace(/\<\/span\>/g, '');
			};
			e.cancelBubble = true;
			if (navigator.appName != 'Microsoft Internet Explorer')	{
				e.preventDefault();
				e.stopPropagation();
			}
			return false;
		}
		// Move Selection Down
		else if (e.keyCode == 40){
			// down
			var ic=0;
			if (parobject.visiblecount > 0) {
				do {
					parobject.currentitemindex++;
				}
				while (parobject.currentitemindex < parobject.listitems.length && parobject.listitems[parobject.currentitemindex].style.display == 'none');
				if(parobject.currentitemindex >= parobject.listitems.length) parobject.currentitemindex = 0;
				
				if (parobject.currentitem) {
					parobject.currentitem.className = parobject.currentitem.className.replace(/light/g, '')
				}
				parobject.currentitem = parobject.listitems[parobject.currentitemindex];
				parobject.currentitem.className += ' light';
				parobject.currentitem.scrollIntoView(false);
				//parobject.edit.value = parobject.currentitem.innerHTML.replace(/\<span style\=\"color:crimson;\"\>/g, '').replace(/\<\/span\>/g, '');
			}
			e.cancelBubble = true;
			if (navigator.appName != 'Microsoft Internet Explorer')	{
				e.preventDefault();
				e.stopPropagation();
			}
			return false;
		}
		
	};
	this.edit.onkeyup = function (e) {
		e = e || window.event;	
		if (e.keyCode == 13) {
			// enter
			if (parobject.visiblecount != 0) {
				var upv = parobject.currentitem.innerHTML.replace(/\<span style\=\"color:crimson;\"\>/g, '').replace(/\<\/span\>/g, '');
				parobject.edit.value = upv;
				//alert(upv);
				if(object_name=="surahNameList"){
					inputSurahName(upv);
					document.getElementById("surahNameList").blur();
				}else if(object_name=="verseNumberList"){
					inputVerseNumber(upv);
					document.getElementById("verseNumberList").blur();
				}else if(object_name=="alphabetList"){
					selectAlphabet(upv);
					document.getElementById("alphabetList").blur();
				}else{
					selectWhereToSearch(upv);
					document.getElementById("searchWhere").blur();
				}
			};
			parobject.dropdownlist.style.display = 'none';
			e.cancelBubble = true;
			return false;
		} else {
			parobject.dropdownlist.style.display = 'block';
			parobject.visiblecount = 0;
			if (parobject.edit.value == '') {
				for (var i=0;i < parobject.listitems.length; i++) {
					parobject.listitems[i].style.display = 'block';
					parobject.visiblecount++;
					parobject.listitems[i].innerHTML =  parobject.listitems[i].innerHTML.replace(/\<span style\=\"color:crimson;\"\>/g, '').replace(/\<\/span\>/g, '');
				}
			}
			else {
				var re = new RegExp( '('+parobject.edit.value.replace(/\(/g,"\\(").replace(/\)/g,"\\)") +')',"ig");
				for (var i=0; i<parobject.listitems.length; i++) {
					var pv = parobject.listitems[i].innerHTML.replace(/\<span style\=\"color:crimson;\"\>/g, '').replace(/\<\/span\>/g, '');
							//.replace(/\(/g, '').replace(/\)/g, '');
					if ( re.test(pv) ) {
						parobject.listitems[i].style.display = 'block';
						parobject.visiblecount++;
						parobject.listitems[i].innerHTML = pv.replace(re, '<span style="color:crimson;">$1</span>');
					}
					else {
						parobject.listitems[i].style.display = 'none';
					}
				}
			}
		}
	}
}
var no = new ComboBox('surahNameList');		//activate the combobox corresponding to the list of surah names, once is enough as the list is static
var no = new ComboBox('verseNumberList');	//activate the combobox corresponding to the list of verses number in the selected surah, once is not enough as the list is not static
var no = new ComboBox('searchWhere');		//activate the combobox corresponding to the list of books to search within ..., once is enough as the list is static
var no = new ComboBox('alphabetList');	//activate the combobox corresponding to the list of alphabets to call dictionary for ..., once is enough as the list is static

function inputSurahName(nu){
	var surahNumberInput=toEn(nu).toString().replace(/(\d+).*/,"$1");
    //alert(surahNumberInput);
	if(Number(surahNumberInput)>=1 && Number(surahNumberInput)<=114){
		surahNumber=surahNumberInput;	
		verseNumber=1;
		if(stateConfig.state==1){
			div6.scrollTop = 0;
		}else if(stateConfig.state==2){
	        div5.scrollTop = 0;
		}else{
			div3.scrollTop = 0;
		}
        stateConfig.quran[0]=surahNumber;		stateConfig.quran[1]=verseNumber;		stateConfig.quran[2]=0;		saveToCache();
        
		document.getElementById("surahNameList").value=quranSurahs[surahNumber-1]["surahTitle"];
		document.getElementById("verseNumberList").value="۱";
		
		showSurah();
		
		//let avoid using "href" for url addressbar to remain almost intact
		document.getElementById ("["+surahNumber+':'+verseNumber+"]").scrollIntoView(true);
		div1.scrollTop -= 40;	// to offset the scroll action above!
		document.getElementById (translationShown+"["+surahNumber+':'+verseNumber+"]").scrollIntoView(true);
		if(stateConfig.state==3){
			div2.scrollTop -= 40;	// to offset the scroll action above!
		}else{
			div4.scrollTop -= 40;	// to offset the scroll action above!
		}
	}else{
		alert("در این نرم‌افزار سوره از روی با شماره‌ی آن انتخاب می‌گردد، لطفاً یا شماره‌ی درست سوره را به صورت \"*.\" در ابتدای ورودی خود وارد نمایید و یا سوره‌ی مورد نظر خود را از داخل فهرست کمکی انتخاب نمایید.");
	}
}
function inputVerseNumber(nu){
	verseNumber=toEn(nu);	stateConfig.quran[1]=verseNumber;	saveToCache();
	//alert("["+surahNumber+":"+verseNumber+"]");
	if(Number(verseNumber)>=1 && Number(verseNumber)<=surahInfo[surahNumber]["numVerse"]){	
		document.getElementById("verseNumberList").value=toFa(verseNumber);
		
		//let avoid using "href" for url addressbar to remain almost intact
		document.getElementById ("["+surahNumber+':'+verseNumber+"]").scrollIntoView(true);
		div1.scrollTop -= 40;	// to offset the scroll action above!
		document.getElementById (translationShown+"["+surahNumber+':'+verseNumber+"]").scrollIntoView(true);
		if(stateConfig.state==3){
			div2.scrollTop -= 40;	// to offset the scroll action above!
		}else{
			div4.scrollTop -= 40;	// to offset the scroll action above!
		}
	}else{
		alert("شماره‌ی وارد شده در محدوده‌ی مجاز انتخاب آیه‌ها نمی‌باشد، لطفاً ورودی خود را تصحیح نمایید.");
	}
}


// === THE VERSES AND THEIR TRANSLATIONS ARE CLICKABLE, USEFUL TO SYNC TOGETHER QURAN AND TRANSLATION, AND TO SAVE IN CACHE THE LAST VERSE THAT IS READ ...

function clickOnVerse(verse){
	verseNumber=verse;	stateConfig.quran[1]=verseNumber;	saveToCache();
	
	document.getElementById("verseNumberList").value=toFa(verseNumber);
		
	//let avoid using "href" for url addressbar to remain almost intact
	document.getElementById ("["+surahNumber+':'+verseNumber+"]").scrollIntoView(true);
	div1.scrollTop -= 40;	// to offset the scroll action above!
	document.getElementById (translationShown+"["+surahNumber+':'+verseNumber+"]").scrollIntoView(true);
	if(stateConfig.state==3){
		div2.scrollTop -= 40;	// to offset the scroll action above!
	}else{
		div4.scrollTop -= 40;	// to offset the scroll action above!
	}
}


// === FEED THE VARIABLES AND SHOW THE SURAH CONTENT ...

function showSurah(){
	optionsVerseList="";
	for(var i=1, l=surahInfo[surahNumber]["numVerse"]; i<=l; i++){
		optionsVerseList += '<a>'+toFa(i)+'</a>';
	}
	document.getElementById("verseNumberListDropdown").innerHTML=optionsVerseList;
	var no = new ComboBox('verseNumberList');	//activate again the combobox corresponding to the new list of verses number
	
	Quran=quranSurahs[surahNumber-1]["content"];
	content1.innerHTML=Quran;
	showSurahTranslations(surahNumber-1);
    Interpretation=alBurhanTrans[surahNumber][0]["content"];
	
	if(window.instanceSplit123){instanceSplit123.destroy();}
	else if(window.instanceSplit145){instanceSplit145.destroy(); instanceSplit45.destroy();}
	else if(window.instanceSplit146){instanceSplit146.destroy();}
	orderTheDivs();
	whichTranslation(translationShown);
}
function showSurahTranslations(number){
	Translations=
	'<div id="mojtabavi" class="tabcontent">'+mojtabaviSurahs[number]+'</div>'
	+'<div id="moezzi" class="tabcontent">'+moezziSurahs[number]+'</div>'
	+'<div id="makarem" class="tabcontent">'+makaremSurahs[number]+'</div>'
	+'<div id="khorramshahi" class="tabcontent">'+khorramshahiSurahs[number]+'</div>'
	+'<div id="khorramdel" class="tabcontent">'+khorramdelSurahs[number]+'</div>'
	+'<div id="ghomshei" class="tabcontent">'+ghomsheiSurahs[number]+'</div>'
	+'<div id="fooladvand" class="tabcontent">'+fooladvandSurahs[number]+'</div>'
	+'<div id="bahrampour" class="tabcontent">'+bahrampourSurahs[number]+'</div>'
	+'<div id="ayati" class="tabcontent">'+ayatiSurahs[number]+'</div>'
	+'<div id="ansarian" class="tabcontent">'+ansarianSurahs[number]+'</div>'
	+'<div id="yusufali" class="tabcontent" dir="ltr">'+toEn(yusufaliSurahs[number])+'</div>'
	+'<div id="sahih" class="tabcontent" dir="ltr">'+toEn(sahihSurahs[number])+'</div>';
}




//================ SWITCH BETWEEN DIFFERENT TRANSLATIONS ================//



function whichTranslation(translationName) {
	var tabcontents = document.getElementsByClassName("tabcontent");
	for (var i=0, len=tabcontents.length; i < len; i++) {
		tabcontents[i].style.display = "none";
	}
	
	translationShown=translationName;	stateConfig.trans=translationShown;	saveToCache();
	
	document.getElementById(translationName).style.display = "block";
	document.getElementById(translationName).parentNode.parentNode.style.backgroundColor
			= document.getElementById(translationName+"TabButton").style.backgroundColor;
	
	var translationTitle=document.getElementById(translationName+"TabButton").textContent.replace(/[ \t]/g,"");
	
	//let avoid using "href" for url addressbar to remain almost intact
	document.getElementById (translationShown+"["+surahNumber+':'+verseNumber+"]").scrollIntoView(true);
	if(stateConfig.state==3){
		div2.scrollTop -= 40;	// to offset the scroll action above!
	}else{
		div4.scrollTop -= 40;	// to offset the scroll action above!
	}
}




//=============== TO SYNC SCROLLBAR BETWEEN QURAN AND ITS TRANSLATION ===============//



var scrollTimer;
div1.onscroll=function(){
	clearTimeout(scrollTimer);
	scrollTimer = window.setTimeout("div1ScrollFinished()", 250);
}
function div1ScrollFinished(){
	for(var i=1, l=surahInfo[surahNumber]["numVerse"]; i<l; i++){
		var y1=document.getElementById("["+surahNumber+':'+i+"]").offsetTop;
		var y2=document.getElementById("["+surahNumber+':'+(i+1)+"]").offsetTop;
		var top=div1.scrollTop;
		if(y1<=top && top<=y2){
			document.getElementById (translationShown+"["+surahNumber+':'+i+"]").scrollIntoView(true);
			//div2.scrollTop -= 40;	// to offset the scroll action above!
		}
	}
}
/* // if div1 is also synchronized to div2 and div4, then e.g. with each scroll in any of the two divs div1 and div4, the other will also move and so the former moves again and the latter moves again accordingly and the changes go on and go on ...

div2.onscroll=function(){
	clearTimeout(scrollTimer);
	scrollTimer = window.setTimeout("div2ScrollFinished()", 250);
}
function div2ScrollFinished(){
	for(var i=1, l=surahInfo[surahNumber]["numVerse"]; i<l; i++){
		var y1=document.getElementById(translationShown+"["+surahNumber+':'+i+"]").offsetTop;
		var y2=document.getElementById(translationShown+"["+surahNumber+':'+(i+1)+"]").offsetTop;
		var top=div2.scrollTop;
		if(y1<=top && top<=y2){
			document.getElementById ("["+surahNumber+':'+i+"]").scrollIntoView(true);
			//div1.scrollTop -= 40;	// to offset the scroll action above!
		}
	}
}
div4.onscroll=function(){
	clearTimeout(scrollTimer);
	scrollTimer = window.setTimeout("div4ScrollFinished()", 250);
}
function div4ScrollFinished(){
	for(var i=1, l=surahInfo[surahNumber]["numVerse"]; i<l; i++){
		var y1=document.getElementById(translationShown+"["+surahNumber+':'+i+"]").offsetTop;
		var y2=document.getElementById(translationShown+"["+surahNumber+':'+(i+1)+"]").offsetTop;
		var top=div4.scrollTop;
		if(y1<=top && top<=y2){
			document.getElementById ("["+surahNumber+':'+i+"]").scrollIntoView(true);
			//div1.scrollTop -= 40;	// to offset the scroll action above!
		}
	}
}
*/




//================== DEFINE THE SPLITTER ACTION ==================//



function orderTheDivs(){
	if(stateConfig.state==3){
		div1.style.display="";
		div2.style.display="";
		div3.style.display="";
		
		div1.style.width="calc(100vw - 16px)";
		div2.style.width="100%";
		div3.style.width="100%";
		
		instanceSplit123 = Split(['#div1', '#div2', '#div3'], {
			direction: 'vertical',
			sizes:[size3_1, size3_2, size3_3],
			minSize:0,
			gutterSize: 8,
			cursor: 'row-resize',
			onDragEnd: function () {
				//alert(instanceSplit123.getSizes());
				size3_1=instanceSplit123.getSizes()[0];
				size3_2=instanceSplit123.getSizes()[1];
				size3_3=instanceSplit123.getSizes()[2];
				stateConfig.size["3"]=[size3_1,size3_2,size3_3];		saveToCache();
				
				//let avoid using "href" for url addressbar to remain almost intact
				document.getElementById ("["+surahNumber+':'+verseNumber+"]").scrollIntoView(true);
				div1.scrollTop -= 40;	// to offset the scroll action above!
				document.getElementById (translationShown+"["+surahNumber+':'+verseNumber+"]").scrollIntoView(true);
				div2.scrollTop -= 40;	// to offset the scroll action above!
				
				div3.scrollTop = (div3.scrollHeight - div3.clientHeight)*Number(stateConfig.quran[2]);
			}
		});
		
		content1.innerHTML=Quran;
		content2.innerHTML=Translations;
		content3.innerHTML=Interpretation;
		content4.innerHTML=""; content5.innerHTML=""; content6.innerHTML="";
	}else if(stateConfig.state==2){
		div2.style.display="none";
		div3.style.display="none";
		div1.style.height="100%";
		
		instanceSplit145 = Split(['#container2', '#container1'], {
			sizes: [(100 - size2_1), size2_1],
			minSize:0,
			gutterSize: 8,
			cursor: 'col-resize',
			onDragEnd: function () {
				//alert(instanceSplit145.getSizes());
				size2_1=instanceSplit145.getSizes()[1];
				
				//let avoid using "href" for url addressbar to remain almost intact
				document.getElementById ("["+surahNumber+':'+verseNumber+"]").scrollIntoView(true);
				div1.scrollTop -= 40;	// to offset the scroll action above!
			}
		});
		instanceSplit45 = Split(['#div4', '#div5'], {
			direction: 'vertical',
			sizes: [size2_2, size2_3],
			minSize:0,
			gutterSize: 8,
			cursor: 'row-resize',
			onDragEnd: function () {
				//alert(instanceSplit45.getSizes());
				size2_2=instanceSplit45.getSizes()[0];
				size2_3=instanceSplit45.getSizes()[1];
				stateConfig.size["2"]=[size2_1,size2_2,size2_3];		saveToCache();
				
				//let avoid using "href" for url addressbar to remain almost intact
				document.getElementById (translationShown+"["+surahNumber+':'+verseNumber+"]").scrollIntoView(true);
				div4.scrollTop -= 40;	// to offset the scroll action above!
				
				div5.scrollTop = (div5.scrollHeight - div5.clientHeight)*Number(stateConfig.quran[2]);
			}
		});
		
		content1.innerHTML=Quran;
		content4.innerHTML=Translations;
		content5.innerHTML=Interpretation;
		content2.innerHTML=""; content3.innerHTML=""; content6.innerHTML="";
	}else{
		div2.style.display="none";
		div3.style.display="none";
		div5.style.display="none";
		
		div1.style.height="100%";
		div4.style.height="100%";
		div6.style.height="100%";
		
		instanceSplit146 = Split(['#container3', '#container2', '#container1'], {
			sizes: [size1_3, size1_2, size1_1],
			minSize:0,
			gutterSize: 8,
			cursor: 'col-resize',
			onDragEnd: function () {
				//alert(instanceSplit146.getSizes());
				size1_3=instanceSplit146.getSizes()[0];
				size1_2=instanceSplit146.getSizes()[1];
				size1_1=instanceSplit146.getSizes()[2];
				stateConfig.size["1"]=[size1_1,size1_2,size1_3];		saveToCache();
				
				//let avoid using "href" for url addressbar to remain almost intact
				document.getElementById ("["+surahNumber+':'+verseNumber+"]").scrollIntoView(true);
				div1.scrollTop -= 40;	// to offset the scroll action above!
				document.getElementById (translationShown+"["+surahNumber+':'+verseNumber+"]").scrollIntoView(true);
				div4.scrollTop -= 40;	// to offset the scroll action above!
				
				div6.scrollTop = (div6.scrollHeight - div6.clientHeight)*Number(stateConfig.quran[2]);
			}
		});
		
		content1.innerHTML=Quran;
		content4.innerHTML=Translations;
		content6.innerHTML=Interpretation;
		content2.innerHTML=""; content3.innerHTML=""; content5.innerHTML="";
	}
	
	whichTranslation(translationShown);
	
	//let avoid using "href" for url addressbar to remain almost intact
	document.getElementById ("["+surahNumber+':'+verseNumber+"]").scrollIntoView(true);
	div1.scrollTop -= 40;	// to offset the scroll action above!
	document.getElementById (translationShown+"["+surahNumber+':'+verseNumber+"]").scrollIntoView(true);
	if(stateConfig.state==3){
		div2.scrollTop -= 40;	// to offset the scroll action above!
		div3.scrollTop = (div3.scrollHeight - div3.clientHeight)*Number(stateConfig.quran[2]);
	}else if(stateConfig.state==2){
		div4.scrollTop -= 40;	// to offset the scroll action above!
		div5.scrollTop = (div5.scrollHeight - div5.clientHeight)*Number(stateConfig.quran[2]);
	}else{
		div6.scrollTop = (div6.scrollHeight - div6.clientHeight)*Number(stateConfig.quran[2]);
	}
	
	
}




//================== DEFINE THE REORDERING BUTTONS ACTION ==================//



function onclick2(){
	container2.style.display="";
	document.getElementById('button4').style.display="";
	div2.style.display="none";
	div3.style.display="none";
	
	stateConfig.state=2;	saveToCache();
	
	instanceSplit123.destroy();
	div1.style.width="";
	
	orderTheDivs();
}
function onclick4(){
	container2.style.display="none";
	div1.style.display="";
	div2.style.display="";
	div3.style.display="";
	
	stateConfig.state=3;	saveToCache();
	
	instanceSplit145.destroy();
	instanceSplit45.destroy();
	orderTheDivs();
}
function onclick5(){
	container3.style.display="";
	div5.style.display="none";
	document.getElementById('button4').style.display="none";
	
	stateConfig.state=1;	saveToCache();
	
	instanceSplit145.destroy();
	instanceSplit45.destroy();
	orderTheDivs();
}
function onclick6(){
	container3.style.display="none";
	div5.style.display="";
	document.getElementById('button4').style.display="";
	
	stateConfig.state=2;	saveToCache();
	
	instanceSplit146.destroy();
	orderTheDivs();
}




//=============  SAVE SCROLL POSITION (IN TAFSIR BLOCK) TO THE CACHE ==============//



var isScrolling;										// Setup isScrolling variable
function percentReadDIV3(){
	isScrolling = setTimeout(function(){				// Set a timeout to run after scrolling ends
		stateConfig.quran[2] = div3.scrollTop / (div3.scrollHeight - div3.clientHeight);
		saveToCache();
	}, 500);
}
function percentReadDIV5(){
	isScrolling = setTimeout(function(){				// Set a timeout to run after scrolling ends
		stateConfig.quran[2] = div5.scrollTop / (div5.scrollHeight - div5.clientHeight);
		saveToCache();
	}, 500);
}
function percentReadDIV6(){
	isScrolling = setTimeout(function(){				// Set a timeout to run after scrolling ends
		stateConfig.quran[2] = div6.scrollTop / (div6.scrollHeight - div6.clientHeight);
		saveToCache();
	}, 500);
}




//=============  CHANGE THE LOOK OF THE APP BETWEEN DAY & NIGHT  ==============



function toNight(){
	document.getElementById("toNight").style.display="none";
	document.getElementById("toDay").style.display="";
	div1.style.boxShadow = "inset 0px 0px 20px 30vw rgba(0,0,0,0.3)";	content1.style.color="#FAEBD7";
	div2.style.boxShadow = "inset 0px 0px 20px 30vw rgba(0,0,0,0.3)";	content2.style.color="#FAEBD7";
	div3.style.boxShadow = "inset 0px 0px 20px 30vw rgba(0,0,0,0.3)";	content3.style.color="#FAEBD7";
	div4.style.boxShadow = "inset 0px 0px 20px 30vw rgba(0,0,0,0.3)";	content4.style.color="#FAEBD7";
	div5.style.boxShadow = "inset 0px 0px 20px 30vw rgba(0,0,0,0.3)";	content5.style.color="#FAEBD7";
	div6.style.boxShadow = "inset 0px 0px 20px 30vw rgba(0,0,0,0.3)";	content6.style.color="#FAEBD7";
	var tabs = document.getElementsByClassName("tabButton");
	for(var i=0, len=tabs.length; i<len; i++) {
		tabs[i].style.boxShadow = "inset 0px 0px 20px 20px rgba(0,0,0,0.3)";	tabs[i].style.color="#FAEBD7";
	}
}
function toDay(){
	document.getElementById("toDay").style.display="none";
	document.getElementById("toNight").style.display="";
	div1.style.boxShadow = "";	content1.style.color="black";
	div2.style.boxShadow = "";	content2.style.color="black";
	div3.style.boxShadow = "";	content3.style.color="black";
	div4.style.boxShadow = "";	content4.style.color="black";
	div5.style.boxShadow = "";	content5.style.color="black";
	div6.style.boxShadow = "";	content6.style.color="black";
	var tabs = document.getElementsByClassName("tabButton");
	for(var i=0, len=tabs.length; i<len; i++) {
		tabs[i].style.boxShadow = "";	tabs[i].style.color="black";
	}
}




//=============  CLOSE POPUPS BY PRESSING 'ESC' OR CLICKING OUTSIDE THE POPUPS  ==============



document.addEventListener("keydown", function(e){
	if (e.keyCode == 27) { window.location.href='#'; }	// checks if Esc key is pressed
});
document.onclick = function(e){
	//check if the dark backgrounds of the popups are clicked ...
	if(e.target.id == 'popupSearch' || e.target.id == 'popupDict' || e.target.id == 'popupAbout'){
		window.location.href='#';
	}
}




//=============  TRIGGER THE SEARCH ACTION BY ALSO PRESSING ENTER  ==============



document.getElementById("search").onkeyup = function (e) {
	e = e || window.event;	
	if (e.keyCode == 13) { search(); }	// checks if Enter key is pressed
};




//================ DEFINE THE SEARCH ACTIONS ================//




var searchResultsArray=[];
var searchConditions;	// let define it globally to be able to simply avoid using  eval(searchConditions); -- But yet I couldn't get rid of it, what shall I do?
function selectWhereToSearch(faName){
	faSearchWhere=faName;
	switch(faName) {
		case "متن قرآن":
			enSearchWhere = "quran";
			break;
		case "انصاریان":
			enSearchWhere = "ansarian";
			break;
		case "آیتی":
			enSearchWhere = "ayati";
			break;
		case "بهرام‌پور":
			enSearchWhere = "bahrampour";
			break;
		case "فولادوند":
			enSearchWhere = "fooladvand";
			break;
		case "قمشه‌ای":
			enSearchWhere = "ghomshei";
			break;
		case "خرّم‌دل":
			enSearchWhere = "khorramdel";
			break;
		case "خرّمشاهی":
			enSearchWhere = "khorramshahi";
			break;
		case "مکارم":
			enSearchWhere = "makarem";
			break;
		case "معزّی":
			enSearchWhere = "moezzi";
			break;
		case "مجتبوی":
			enSearchWhere = "mojtabavi";
			break;
		case "Sahih International":
			enSearchWhere = "sahih";
			break;
		case "Yusuf Ali":
			enSearchWhere = "yusufali";
			break;
		default:
			enSearchWhere = "quran";
			document.getElementById("searchWhere").value="متن قرآن";
			alert("انتخاب محل جستجو درست انجام نگرفته است!");
	}
}
function search(){
	searchResultsArray=[];
	
	var query=document.getElementById("search").value
		.toLowerCase()
		.replace(/[ًٌٍَُِّْء]+/g, "").replace(/[ئيى]+/g, "ی").replace(/[اآأإ\u0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه").replace(/[ك]+/g,"ک");	// \u0670 :الف مقصوره!
	
	searchConditions=query
		.replace(/\s*\+\s*/g,"&&").replace(/\s*\|\s*/g,"||").replace(/\s*\+!\s*/g,"&&!").replace(/[-\u0600-\u06FF\u0750–\u077F\u08A0–\u08FF \w]+/g, "(str.indexOf(\"$&\")!=-1)");	// it works for Arabic & Persian by the set  \u0600-\u06FF\u0750–\u077F\u08A0–\u08FF , and works for English by  \w  ... it substitutes any word in Arabic|Farsi|English by    (str.indexOf('word')!=-1)    so that e.g. (a||b)&&c becomes ((str.indexOf(a)!=-1)||(str.indexOf(b)!=-1))&&(str.indexOf(c)!=-1)
		// for English searching use  /../gi  instead of  /../g  for case insensitivity, or use something like: str.toLowerCase().indexOf(query.toLowerCase())
	
	document.getElementById("searchResults").innerHTML=
		'<div id="searchResultNumberFound" style="text-align:right;"></div>'
		
		+'<div id="searchHeader">'
			+'<input id="btn_prev" class="myButton" onclick="prevPage()" type="image" src="Files/images/minus.png" alt=""  title="صفحه‌ی قبل" align="center" width="15" height="15" style="margin-bottom:9px; margin-left:5px;" /> '
				+' صفحه‌ی '
			+' <span id="page"></span>  '
			+' <input id="btn_next" class="myButton" onclick="nextPage()" type="image" src="Files/images/plus.png" alt=""  title="صفحه‌ی بعد" align="center" width="15" height="15" style="margin-bottom:9px; margin-left:5px;" />'
		+'</div>'
		+'<div id="listingTable" style="background:rgba(255,255,255,0.3); border-radius:10px; padding:15px; text-align:right;"></div>'	// the search results will be listed here in several pages
		+'<br>'
		+'<div style="width:100%; text-align:center;">'
			+'<div id="searchFooter"></div>'
			+'<div  id="goToPageMaster">'
				+'برو به صفحه‌ی  '
				+'<input id="goToPage" type="text" placeholder="..." title="انتخاب صفحه" style="width:20px;" />'
			+'</div>'
		+'</div>'
		+'<br>'
	
	document.getElementById("searchFooter").innerHTML=document.getElementById("searchHeader").innerHTML;
	
	
	// let make possibe for user to trigger "changepage" by pressing the "Enter" key
	document.getElementById("goToPage").onkeyup = function (e) {
		e = e || window.event;	
		if (e.keyCode == 13) {	// checks if Enter key is pressed
			changePage( toEn(document.getElementById("goToPage").value));
		}
	};
	
	
	var counter=0;
	var str, string;
	if(enSearchWhere=="quran"){
		for(var i in quranSimpleEnhanced){
			string=quranSimpleEnhanced[i]["verse"];
			str=string.replace(/[ًٌٍَُِّْء]+/g, "").replace(/[ئيى]+/g, "ی").replace(/[اآأإ\u0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه").replace(/[ك]+/g,"ک");	// \u0670 :الف مقصوره!
			
			if(eval(searchConditions)){
				counter++;
				
				// to highlight the matching phrases in colors
				string=highlightSearchResults(string,query);
				
				searchResultsArray.push(
					'<br>'
					+'<span class="verseContent"> '
						+toFa(counter)+'. '+string
					+'</span>'
					+'<a href="javascript: linkFromSearchResults('+quranSimpleEnhanced[i]["surah"]+','+quranSimpleEnhanced[i]["ayah"]+');" style="color:crimson; text-decoration:none;">'
						+' ('
						+surahInfo[quranSimpleEnhanced[i]["surah"]]["nameAr"]
						+': '
						+toFa(quranSimpleEnhanced[i]["ayah"])
						+')'
					+'</a>'
				);
			}
		}
	}else if(enSearchWhere=="ansarian"){
		translationShown="ansarian";
		for(var i in quranSimpleEnhanced){
			string=faAnsarian[i]["verse"];
			str=string.replace(/[ًٌٍَُِّْء]+/g, "").replace(/[ئيى]+/g, "ی").replace(/[اآأإ\u0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه").replace(/[ك]+/g,"ک");	// \u0670 :الف مقصوره!
			
			if(eval(searchConditions)){
				counter++;
				
				// to highlight the matching phrases in colors
				string=highlightSearchResults(string,query);
				
				searchResultsArray.push(
					'<br>'
					+'<span class="verseTranslationContent"> '
						+toFa(counter)+'. '+string
					+'</span>'
					+'<a href="javascript: linkFromSearchResults('+quranSimpleEnhanced[i]["surah"]+','+quranSimpleEnhanced[i]["ayah"]+');" style="color:crimson; text-decoration:none;">'
						+' ('
						+surahInfo[quranSimpleEnhanced[i]["surah"]]["nameAr"]
						+': '
						+toFa(quranSimpleEnhanced[i]["ayah"])
						+')'
					+'</a>'
				);
			}
		}
	}else if(enSearchWhere=="ayati"){
		translationShown="ayati";
		for(var i in quranSimpleEnhanced){
			string=faAyati[i]["verse"];
			str=string.replace(/[ًٌٍَُِّْء]+/g, "").replace(/[ئيى]+/g, "ی").replace(/[اآأإ\u0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه").replace(/[ك]+/g,"ک");	// \u0670 :الف مقصوره!
			
			if(eval(searchConditions)){
				counter++;
				
				// to highlight the matching phrases in colors
				string=highlightSearchResults(string,query);
				
				searchResultsArray.push(
					'<br>'
					+'<span class="verseTranslationContent"> '
						+toFa(counter)+'. '+string
					+'</span>'
					+'<a href="javascript: linkFromSearchResults('+quranSimpleEnhanced[i]["surah"]+','+quranSimpleEnhanced[i]["ayah"]+');" style="color:crimson; text-decoration:none;">'
						+' ('
						+surahInfo[quranSimpleEnhanced[i]["surah"]]["nameAr"]
						+': '
						+toFa(quranSimpleEnhanced[i]["ayah"])
						+')'
					+'</a>'
				);
			}
		}
	}else if(enSearchWhere=="bahrampour"){
		translationShown="bahrampour";
		for(var i in quranSimpleEnhanced){
			string=faBahrampour[i]["verse"];
			str=string.replace(/[ًٌٍَُِّْء]+/g, "").replace(/[ئيى]+/g, "ی").replace(/[اآأإ\u0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه").replace(/[ك]+/g,"ک");	// \u0670 :الف مقصوره!
			
			if(eval(searchConditions)){
				counter++;
				
				// to highlight the matching phrases in colors
				string=highlightSearchResults(string,query);
				
				searchResultsArray.push(
					'<br>'
					+'<span class="verseTranslationContent"> '
						+toFa(counter)+'. '+string
					+'</span>'
					+'<a href="javascript: linkFromSearchResults('+quranSimpleEnhanced[i]["surah"]+','+quranSimpleEnhanced[i]["ayah"]+');" style="color:crimson; text-decoration:none;">'
						+' ('
						+surahInfo[quranSimpleEnhanced[i]["surah"]]["nameAr"]
						+': '
						+toFa(quranSimpleEnhanced[i]["ayah"])
						+')'
					+'</a>'
				);
			}
		}
	}else if(enSearchWhere=="fooladvand"){
		translationShown="fooladvand";
		for(var i in quranSimpleEnhanced){
			string=faFooladvand[i]["verse"];
			str=string.replace(/[ًٌٍَُِّْء]+/g, "").replace(/[ئيى]+/g, "ی").replace(/[اآأإ\u0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه").replace(/[ك]+/g,"ک");	// \u0670 :الف مقصوره!
			
			if(eval(searchConditions)){
				counter++;
				
				// to highlight the matching phrases in colors
				string=highlightSearchResults(string,query);
				
				searchResultsArray.push(
					'<br>'
					+'<span class="verseTranslationContent"> '
						+toFa(counter)+'. '+string
					+'</span>'
					+'<a href="javascript: linkFromSearchResults('+quranSimpleEnhanced[i]["surah"]+','+quranSimpleEnhanced[i]["ayah"]+');" style="color:crimson; text-decoration:none;">'
						+' ('
						+surahInfo[quranSimpleEnhanced[i]["surah"]]["nameAr"]
						+': '
						+toFa(quranSimpleEnhanced[i]["ayah"])
						+')'
					+'</a>'
				);
			}
		}
	}else if(enSearchWhere=="ghomshei"){
		translationShown="ghomshei";
		for(var i in quranSimpleEnhanced){
			string=faGhomshei[i]["verse"];
			str=string.replace(/[ًٌٍَُِّْء]+/g, "").replace(/[ئيى]+/g, "ی").replace(/[اآأإ\u0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه").replace(/[ك]+/g,"ک");	// \u0670 :الف مقصوره!
			
			if(eval(searchConditions)){
				counter++;
				
				// to highlight the matching phrases in colors
				string=highlightSearchResults(string,query);
				
				searchResultsArray.push(
					'<br>'
					+'<span class="verseTranslationContent"> '
						+toFa(counter)+'. '+string
					+'</span>'
					+'<a href="javascript: linkFromSearchResults('+quranSimpleEnhanced[i]["surah"]+','+quranSimpleEnhanced[i]["ayah"]+');" style="color:crimson; text-decoration:none;">'
						+' ('
						+surahInfo[quranSimpleEnhanced[i]["surah"]]["nameAr"]
						+': '
						+toFa(quranSimpleEnhanced[i]["ayah"])
						+')'
					+'</a>'
				);
			}
		}
	}else if(enSearchWhere=="khorramdel"){
		translationShown="khorramdel";
		for(var i in quranSimpleEnhanced){
			string=faKhorramdel[i]["verse"];
			str=string.replace(/[ًٌٍَُِّْء]+/g, "").replace(/[ئيى]+/g, "ی").replace(/[اآأإ\u0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه").replace(/[ك]+/g,"ک");	// \u0670 :الف مقصوره!
			
			if(eval(searchConditions)){
				counter++;
				
				// to highlight the matching phrases in colors
				string=highlightSearchResults(string,query);
				
				searchResultsArray.push(
					'<br>'
					+'<span class="verseTranslationContent"> '
						+toFa(counter)+'. '+string
					+'</span>'
					+'<a href="javascript: linkFromSearchResults('+quranSimpleEnhanced[i]["surah"]+','+quranSimpleEnhanced[i]["ayah"]+');" style="color:crimson; text-decoration:none;">'
						+' ('
						+surahInfo[quranSimpleEnhanced[i]["surah"]]["nameAr"]
						+': '
						+toFa(quranSimpleEnhanced[i]["ayah"])
						+')'
					+'</a>'
				);
			}
		}
	}else if(enSearchWhere=="khorramshahi"){
		translationShown="khorramshahi";
		for(var i in quranSimpleEnhanced){
			string=faKhorramshahi[i]["verse"];
			str=string.replace(/[ًٌٍَُِّْء]+/g, "").replace(/[ئيى]+/g, "ی").replace(/[اآأإ\u0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه").replace(/[ك]+/g,"ک");	// \u0670 :الف مقصوره!
			
			if(eval(searchConditions)){
				counter++;
				
				// to highlight the matching phrases in colors
				string=highlightSearchResults(string,query);
				
				searchResultsArray.push(
					'<br>'
					+'<span class="verseTranslationContent"> '
						+toFa(counter)+'. '+string
					+'</span>'
					+'<a href="javascript: linkFromSearchResults('+quranSimpleEnhanced[i]["surah"]+','+quranSimpleEnhanced[i]["ayah"]+');" style="color:crimson; text-decoration:none;">'
						+' ('
						+surahInfo[quranSimpleEnhanced[i]["surah"]]["nameAr"]
						+': '
						+toFa(quranSimpleEnhanced[i]["ayah"])
						+')'
					+'</a>'
				);
			}
		}
	}else if(enSearchWhere=="makarem"){
		translationShown="makarem";
		for(var i in quranSimpleEnhanced){
			string=faMakarem[i]["verse"];
			str=string.replace(/[ًٌٍَُِّْء]+/g, "").replace(/[ئيى]+/g, "ی").replace(/[اآأإ\u0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه").replace(/[ك]+/g,"ک");	// \u0670 :الف مقصوره!
			
			if(eval(searchConditions)){
				counter++;
				
				// to highlight the matching phrases in colors
				string=highlightSearchResults(string,query);
				
				searchResultsArray.push(
					'<br>'
					+'<span class="verseTranslationContent"> '
						+toFa(counter)+'. '+string
					+'</span>'
					+'<a href="javascript: linkFromSearchResults('+quranSimpleEnhanced[i]["surah"]+','+quranSimpleEnhanced[i]["ayah"]+');" style="color:crimson; text-decoration:none;">'
						+' ('
						+surahInfo[quranSimpleEnhanced[i]["surah"]]["nameAr"]
						+': '
						+toFa(quranSimpleEnhanced[i]["ayah"])
						+')'
					+'</a>'
				);
			}
		}
	}else if(enSearchWhere=="moezzi"){
		translationShown="moezzi";
		for(var i in quranSimpleEnhanced){
			string=faMoezzi[i]["verse"];
			str=string.replace(/[ًٌٍَُِّْء]+/g, "").replace(/[ئيى]+/g, "ی").replace(/[اآأإ\u0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه").replace(/[ك]+/g,"ک");	// \u0670 :الف مقصوره!
			
			if(eval(searchConditions)){
				counter++;
				
				// to highlight the matching phrases in colors
				string=highlightSearchResults(string,query);
				
				searchResultsArray.push(
					'<br>'
					+'<span class="verseTranslationContent"> '
						+toFa(counter)+'. '+string
					+'</span>'
					+'<a href="javascript: linkFromSearchResults('+quranSimpleEnhanced[i]["surah"]+','+quranSimpleEnhanced[i]["ayah"]+');" style="color:crimson; text-decoration:none;">'
						+' ('
						+surahInfo[quranSimpleEnhanced[i]["surah"]]["nameAr"]
						+': '
						+toFa(quranSimpleEnhanced[i]["ayah"])
						+')'
					+'</a>'
				);
			}
		}
	}else if(enSearchWhere=="mojtabavi"){
		translationShown="mojtabavi";
		for(var i in quranSimpleEnhanced){
			string=faMojtabavi[i]["verse"];
			str=string.replace(/[ًٌٍَُِّْء]+/g, "").replace(/[ئيى]+/g, "ی").replace(/[اآأإ\u0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه").replace(/[ك]+/g,"ک");	// \u0670 :الف مقصوره!
			
			if(eval(searchConditions)){
				counter++;
				
				// to highlight the matching phrases in colors
				string=highlightSearchResults(string,query);
				
				searchResultsArray.push(
					'<br>'
					+'<span class="verseTranslationContent"> '
						+toFa(counter)+'. '+string
					+'</span>'
					+'<a href="javascript: linkFromSearchResults('+quranSimpleEnhanced[i]["surah"]+','+quranSimpleEnhanced[i]["ayah"]+');" style="color:crimson; text-decoration:none;">'
						+' ('
						+surahInfo[quranSimpleEnhanced[i]["surah"]]["nameAr"]
						+': '
						+toFa(quranSimpleEnhanced[i]["ayah"])
						+')'
					+'</a>'
				);
			}
		}
	}else if(enSearchWhere=="sahih"){
		translationShown="sahih";
		for(var i in quranSimpleEnhanced){
			string=enSahih[i]["verse"];
			str=string.toLowerCase();
			
			if(eval(searchConditions)){
				counter++;
				
				// to highlight the matching phrases in colors
				string=highlightSearchResults(string,query);
				
				searchResultsArray.push(
					'<div style="padding:5px; text-align:left;" lang="en" dir="ltr">'
						//'<br>'
						+'<span class="verseTranslationContent"> '
							+counter+'. '+string
						+'</span>'									
						+'<a href="javascript: linkFromSearchResults('+quranSimpleEnhanced[i]["surah"]+','+quranSimpleEnhanced[i]["ayah"]+');" style="color:crimson; text-decoration:none;">'
							+' ('
							+surahInfo[quranSimpleEnhanced[i]["surah"]]["nameAr"]
							+':'
							+quranSimpleEnhanced[i]["ayah"]
							+')'
						+'</a>'
					+'</div>'
				);
			}
		}
	}else if(enSearchWhere=="yusufali"){
		translationShown="yusufali";
		for(var i in quranSimpleEnhanced){
			string=enYusufali[i]["verse"];
			str=string.toLowerCase();
			
			if(eval(searchConditions)){
				counter++;
				
				// to highlight the matching phrases in colors
				string=highlightSearchResults(string,query);
				
				searchResultsArray.push(
					'<div style="padding:5px; text-align:left;" lang="en" dir="ltr">'
						//'<br>'
						+'<span class="verseTranslationContent"> '
							+counter+'. '+string
						+'</span>'									
						+'<a href="javascript: linkFromSearchResults('+quranSimpleEnhanced[i]["surah"]+','+quranSimpleEnhanced[i]["ayah"]+');" style="color:crimson; text-decoration:none;">'
							+' ('
							+surahInfo[quranSimpleEnhanced[i]["surah"]]["nameAr"]
							+':'
							+quranSimpleEnhanced[i]["ayah"]
							+')'
						+'</a>'
					+'</div>'
				);
			}
		}
	}
	
	
	document.getElementById("searchResultNumberFound").innerHTML=
		'<p style="text-shadow:1px 1px 1px black;">'
			+'نتایج جستجوی « '+query+' » در « '+faSearchWhere+' » : '
			+'<span style="color:orange"> (تعداد یافته‌ها: '
				+'<span style="color:red">'+toFa(counter)+'</span>'
			+')</span>'
		+'</p>'
	
	changePage(1);
	
	// inorder to show nothing extra if there is no results found!
	if(counter==0){
		document.getElementById("searchHeader").outerHTML="";
		document.getElementById("listingTable").outerHTML="";
		document.getElementById("searchFooter").outerHTML="";
		document.getElementById("goToPageMaster").outerHTML="";
	}
	if(counter<=2*records_per_page){
		document.getElementById("goToPageMaster").outerHTML="";
	}
}
function highlightSearchResults(string,query){
	var stringArray=string.split(/\s+/g); //an array that contains the "found" (approved with respect to the searchConditions) verse or its translation word by word
	var queryHighlight=query.split(/[\s+\|(+!)]+/);
	var highlightColorList=["Yellow", "LawnGreen", "DeepPink", "Aqua", "DarkOrange", "DodgerBlue", "Olive", "Crimson", "OrangeRed", "DarkOrchid"];
	
	for(var j in stringArray){
		for(var k in queryHighlight){
			if(stringArray[j].toLowerCase().replace(/[ًٌٍَُِّْء]+/g, "").replace(/[ئيى]+/g, "ی").replace(/[اآأإ\u0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه").replace(/[ك]+/g,"ک").toLowerCase().indexOf( queryHighlight[k].replace(/[ًٌٍَُِّْء]+/g, "").replace(/[ئيى]+/g, "ی").replace(/[اآأإ\u0670]+/g, "ا").replace(/[ؤ]+/g, "و").replace(/[ة]+/g, "ه").replace(/[ك]+/g,"ک").toLowerCase() )!=-1){
				stringArray[j]="<span style='color:"+highlightColorList[k]+"; text-shadow:1px 1px 1px black;'>"+stringArray[j]+"</span>";
			}
		}
	}
	return string=stringArray.join().replace(/,/g," ");
}
function linkFromSearchResults(surah,verse){
	surahNumber=surah;
	inputSurahName(surahNumber);
	verseNumber=verse;
	inputVerseNumber(verseNumber);
    window.location.href="#";
}




/* ---------------------------------------------------------- */
/* script for pagination of the search results */


/* this file uses and is inspired by "http://stackoverflow.com/questions/25434813/simple-pagination-in-javascript" and "https://www.script-tutorials.com/how-to-create-easy-pagination-with-jquery/" */
var current_page = 1;
var records_per_page = 10;

function prevPage(){
	if (current_page > 1){
		current_page--;
		changePage(current_page);
	}
}
function nextPage(){
	if (current_page < numPages()){
		current_page++;
		changePage(current_page);
	}
}

function changePage(page){
	// Validate page
	if (page < 1) page = 1;
	if (page > numPages()) page = numPages();    
	current_page=page;
	document.getElementById("listingTable").innerHTML = "";
	
	for (var i = (page-1) * records_per_page; i < (page * records_per_page) && i < searchResultsArray.length; i++){
		document.getElementById("listingTable").innerHTML+=searchResultsArray[i]+"<br>";
	}
	
	document.getElementById("page").innerHTML = toFa(page)+" از "+toFa(numPages());
	
	if (page == 1) {document.getElementById("btn_prev").style.display = "none";}
	else{document.getElementById("btn_prev").style.display = "";}
	if (page == numPages()){document.getElementById("btn_next").style.display = "none";}
	else{document.getElementById("btn_next").style.display = "";}
	
	document.getElementById("searchFooter").innerHTML=document.getElementById("searchHeader").innerHTML;
}
function numPages(){
	return Math.ceil(searchResultsArray.length / records_per_page);
}




//================ DEFINE THE DICTIONARY POPUP ACTIONS ================//




function changeDict(dict){
	//var dict=document.getElementById("whichDict").value;
	lastDictSelected=dict;
	if(dict=="majmaulBahrainDict"){
		document.getElementById("glossariesShown").innerHTML=majmaulBahrainDict[lastAlphabetSelected];
	}else if(dict=="nathreTubaDict"){
		document.getElementById("glossariesShown").innerHTML=nathreTubaDict[lastAlphabetSelected];
	}
}
function selectAlphabet(alphabet){
	lastAlphabetSelected=alphabet;
	//changeDict("majmaulBahrainDict");
	changeDict(lastDictSelected);
}
changeDict("majmaulBahrainDict");
document.getElementById("whichDict").value="majmaulBahrainDict";
document.getElementById("alphabetList").value="أ";





//================== THE PAGE INITIALIZATION CODE ==================//



(function() {
	showSurah();
})();
/*
window.onload = function(){
	showSurah();
}
*/
